/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.5.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: Personal
-- ------------------------------------------------------
-- Server version	11.5.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Dumping routines for database 'Personal'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_IsHoliday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_IsHoliday`(date DATE) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
    DECLARE year INT DEFAULT YEAR(date);
    DECLARE month INT DEFAULT MONTH(date);
    DECLARE day INT DEFAULT DAY(date);
    DECLARE dayName VARCHAR(12) DEFAULT DAYNAME(date);
    DECLARE nthWeekDay INT DEFAULT CEIL(DAY(date) / 7);
    DECLARE isThursday BOOLEAN DEFAULT (dayName = 'Thursday');
    DECLARE isFriday BOOLEAN DEFAULT (dayName = 'Friday');
    DECLARE isSaturday BOOLEAN DEFAULT (dayName = 'Saturday');
    DECLARE isSunday BOOLEAN DEFAULT (dayName = 'Sunday');
    DECLARE isMonday BOOLEAN DEFAULT (dayName = 'Monday');
    DECLARE isWeekend BOOLEAN DEFAULT (isSaturday OR isSunday);
    
    -- New Year's Day
    IF (month = 12 AND day = 31 AND isFriday) THEN RETURN TRUE; END IF;
    IF (month = 1 AND day = 1 AND NOT isWeekend) THEN RETURN TRUE; END IF;
    IF (month = 1 AND day = 2 AND isMonday) THEN RETURN TRUE; END IF;
    
    -- Martin Luther King Jr. Day (3rd Monday in January)
    IF (month = 1 AND isMonday AND nthWeekDay = 3) THEN RETURN TRUE; END IF;
    
    -- Presidents' Day (3rd Monday in February)
    IF (month = 2 AND isMonday AND nthWeekDay = 3) THEN RETURN TRUE; END IF;
    
    -- Memorial Day (last Monday in May)
    IF (month = 5 AND isMonday AND MONTH(DATE_ADD(date, INTERVAL 7 DAY)) = 6) THEN RETURN TRUE; END IF;
   
    -- Juneteenth (June 19th)
    IF (month = 6 AND day = 19) THEN RETURN TRUE; END IF;
    
    -- Independence Day (July 4)
    IF (month = 7 AND day = 3 AND isFriday) THEN RETURN TRUE; END IF;
    IF (month = 7 AND day = 4 AND NOT isWeekend) THEN RETURN TRUE; END IF;
    IF (month = 7 AND day = 5 AND isMonday) THEN RETURN TRUE; END IF;
    
    -- Labor Day (1st Monday in September)
    IF (month = 9 AND isMonday AND nthWeekDay = 1) THEN RETURN TRUE; END IF;
    
    -- Columbus Day (2nd Monday in October)
    IF (month = 10 AND isMonday AND nthWeekDay = 2) THEN RETURN TRUE; END IF;
    
    -- Veterans Day (November 11)
    IF (month = 11 AND day = 10 AND isFriday) THEN RETURN TRUE; END IF;
    IF (month = 11 AND day = 11 AND NOT isWeekend) THEN RETURN TRUE; END IF;
    IF (month = 11 AND day = 12 AND isMonday) THEN RETURN TRUE; END IF;
    
    -- Thanksgiving Day (4th Thursday in November)
    IF (month = 11 AND isThursday AND nthWeekDay = 4) THEN RETURN TRUE; END IF;
    
    -- Christmas Day (December 25)
    IF (month = 12 AND day = 24 AND isFriday) THEN RETURN TRUE; END IF;
    IF (month = 12 AND day = 25 AND NOT isWeekend) THEN RETURN TRUE; END IF;
    IF (month = 12 AND day = 26 AND isMonday) THEN RETURN TRUE; END IF;

    RETURN FALSE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddAsset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_AddAsset`(
	IN id VARCHAR(50), in `rank` int(11), IN symbol CHAR(3), IN `name` VARCHAR(100), 
	IN supply decimal(30,18), IN maxSupply decimal(30,18), IN marketCapUsd decimal(30,18),
	IN volumnUsd24Hr decimal(30,18), IN priceUsd decimal(30,18), IN changePercent24Hr decimal(20,18),
	IN vwap24Hr decimal(30,18)
	)
BEGIN
	INSERT INTO ExchangeRates (Id, `Rank`, Symbol, Name, Supply, MaxSupply, MarketCapUsd, VolumeUsd24Hr, PriceUsd,
		ChangePercent24Hr, Vwap24Hr)
	VAlUES (id, `rank`, symbol, `name`, supply, maxSupply, marketCapUsd, volumeUsd24Hr, priceUsd,
		changePercent24Hr, vwap24Hr)
	ON DUPLICATE KEY update 
		`Rank` = `rank`
		, Symbol = symbol
		, `Name` = `name`
		, Supply = supply
		, MaxSupply = maxSupply
		, MarketCapUsd = marketCapUsd
		, VolumeUsd24Hr = volumeUsd24Hr
		, PriceUsd = priceUsd
		, ChangePercent24Hr = changePercent24Hr
		, Vwap24Hr = vwap24Hr;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddCryptoIndicator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `usp_AddCryptoIndicator`(
	IN symbol varchar(5), IN exchangeName varchar(40)
	, IN indicatorSymbol varchar(20), IN intervalType varchar(5)
	, IN title varchar(40), IN value double, IN recommendation int
	, IN actionBasis varchar(40), IN indicatorTimeStamp int
)
BEGIN
	INSERT INTO CryptoIndcators 
	(Symbol, ExchangeId, IndicatorSymbol, IntervalType, Title, Recommendation
	, ActionBasis, IndicatorTimeStamp)
	VALUES(symbol
	, (SELECT Id From CryptoExchanges WHERE Name = exchangeName LIMIT 1)
	, indicatorSymbol, intervalType, title, value, recommendation
	, actionBasis, FROM_UNIXTIME(indicatorTimeStamp)
	);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddCryptoPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `usp_AddCryptoPrice`(
	IN symbol varchar(5), IN exchangeName varchar(40)
	, IN price double, IN prevClosePrice double, IN openPrice double
	, IN lowPrice double, IN highPrice double, IN changeAmount double
	, IN changePercent double, IN priceTimeStamp int
	, IN openTime int
	)
BEGIN
	INSERT INTO CryptoPrice 
		(Symbol, ExchangeId, Price, PrevClosePrice, OpenPrice
		, LowPrice, HighPrice, ChangeAmount, ChangePercent
		, PriceTimeStamp, OpenTime)
	VALUES (symbol
		,(SELECT Id FROM CryptoExchanges WHERE Name = exchangeName LIMIT 1)
		, price, prevClosePrice, openPrice, lowPrice, highPrice
		, changeAmount, changePercent, FROM_UNIXTIME(priceTimeStamp)
		, FROM_UNIXTIME(opentime)
	);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddCryptoPriceChange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `usp_AddCryptoPriceChange`(
	IN symbol varchar(5), IN exchangeName varchar(40)
	, IN 5min double, IN 15min double, IN hour double
	, IN day double, IN week double, IN month double
	, IN 6month double, IN year double, IN pricetimestamp int
)
BEGIN
	INSERT INTO CryptoPriceChanges 
	(Symbol, ExchangeId, 5Minute, 15Minute, Hour, Day, Week
	, Month, 6Month, Year, PriceTimeStamp)
	VALUES(symbol
	, (SELECT Id From CryptoExchanges WHERE Name = exchangeName LIMIT 1)
	, 5min, 15min, hour, day, week, month, 6month, year 
	, FROM_UNIXTIME(pricetimestamp)
	);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddExchangeRate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_AddExchangeRate`(
	IN symbol CHAR(3), IN baseSymbol CHAR(3), IN rate float, IN ratedate date)
BEGIN
	INSERT INTO ExchangeRates (Symbol, BaseSymbol, Rate, RateDate)
	VAlUES (symbol, baseSymbol, rate, ratedate)
	ON DUPLICATE KEY UPDATE 
	Rate = rate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddMetalPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_AddMetalPrice`(
	IN metal varchar(20),
	IN currency char(3),
	IN price double, 
	IN prev_price double,
	IN ratedate date,
	IN unixtime timestamp,
	IN chg double, 
	IN chg_pct double,
	IN price_gram_24k double,
	IN price_gram_22k double,
	IN price_gram_21k double,
    IN price_gram_20k double,
    IN price_gram_18k double
)
BEGIN
	INSERT INTO MetalPrices 
		(Metal, Currency, Price, PrevPriceClose, RateDate, `Timestamp`, Chg, ChgPct, price_gram_24k, price_gram_22k, price_gram_21k, price_gram_20k, price_gram_18k)
		VALUES (metal, currency, price, prev_price, ratedate, unixtime, chg, chg_pct, price_gram_24k, price_gram_22k, price_gram_21k, price_gram_20k, price_gram_18k
)
	ON DUPLICATE KEY update
		Metal = metal
		, Currency = currency
		, Price = price
		, PrevPriceClose = Prev_Price 
		, Chg = chg
		, ChgPct = chg_pct
		, Price_Gram_24k = price_gram_24k
		, Price_Gram_22k = price_gram_22k
		, Price_Gram_21k = price_gram_21k
		, Price_Gram_20k = price_gram_20k
		, Price_Gram_18k = price_gram_18k;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_AddStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `usp_AddStock`(IN symbol CHAR(5), IN currentPrice double, IN priceChange double,
		percentChange double, high double, low double, openPrice double,
		previousClose double, priceTimestamp DateTime)
BEGIN
	INSERT INTO Stocks (Symbol, CurrentPrice, PriceChange, PercentChange,
		High, Low, OpenPrice, PreviousClose, PriceTimestamp)
	VAlUES (symbol, currentPrice, priceChange, percentChange,
		high, low, openPrice, previousClose, priceTimestamp)
	ON DUPLICATE KEY UPDATE 
		CurrentPrice = currentPrice
		, PriceChange = priceChange
		, High = high
		, Low = low
		, OpenPrice = OpenPrice
		, PreviousClose = previousClose
		, PriceTimestamp = priceTimestamp;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetAllExchangeRates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetAllExchangeRates`()
BEGIN
    SELECT Symbol, Rate, RateDate
    FROM ExchangeRates
    ORDER BY RateDate DESC, Symbol ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetExchangeByYearSymbol` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetExchangeByYearSymbol`(
	IN year int, IN symbol char(3)
	)
BEGIN
SELECT JSON_ARRAYAGG(JSON_OBJECT('Year', Year, 'Month', Month, 'Symbol', Symbol, 
	'Avg', Avg, 'Low', Low, 'High', High)) 
FROM vw_ExchangeRatesByMonthLowAvgHigh 
WHERE Symbol = symbol AND Year = (SELECT IFNULL(year, YEAR(CURRENT_DATE())));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetExchangeMissing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetExchangeMissing`(
	IN startDate varchar(10),
	IN endDate varchar(10),	
    IN symbol varchar(3)
)
BEGIN
WITH Calendar AS (
    SELECT
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY AS RateDate
    FROM
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
    CROSS JOIN
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b
    CROSS JOIN
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) c
    WHERE
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY >= startDate
    AND
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY <= endDate
)
SELECT
    c.RateDate
FROM
    Calendar c
LEFT JOIN
    ExchangeRates er ON c.RateDate = er.RateDate
    AND er.Symbol = symbol
WHERE
    WEEKDAY(c.RateDate) < 5               -- Only weekdays
    AND fn_IsHoliday(c.RateDate) = FALSE  -- Not a U.S. holiday
    AND er.RateDate IS NULL;              -- No data in ExchangeRates
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetExchangeRates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetExchangeRates`(
	IN startDate varchar(10),
	IN endDate varchar(10),
	IN symbols varchar(15),
	IN baseCurrency varchar(3)
)
BEGIN
	SELECT 
		Symbol
		, Rate 
		, RateDate
	FROM ExchangeRates
	WHERE RateDate >= startDate
	AND RateDate <= endDate
	AND FIND_IN_SET(Symbol, symbols) > 0
	AND BaseSymbol = baseCurrency;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetExchangeRatesWeek` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetExchangeRatesWeek`(
	IN sym char(3)
)
BEGIN
	SELECT * FROM vw_ExchangeRatesWeek WHERE Symbol COLLATE utf8mb4_general_ci = sym;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetLast5Gold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetLast5Gold`(IN yr char(4))
BEGIN
SELECT 
	DAYOFWEEK(gp.RateDate) AS 'DayNumber'
	, gp.Price 
	, (SELECT ROUND(ROUND(er.Rate,2) * gp.Price,2) FROM ExchangeRates er 
		WHERE er.RateDate <= gp.RateDate AND Symbol = 'TRY' 
		ORDER BY er.RateDate DESC LIMIT 1) AS TRYPrice
	, gp.PrevPriceClose 
	, gp.Chg 
	, gp.ChgPct 
	, gp.RateDate
FROM GoldPrices gp
WHERE YEAR(gp.RateDate) = Yr
	AND WEEK(gp.RateDate) = WEEK(CURRENT_DATE()) 
ORDER By gp.RateDate DESC
LIMIT 5;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetLast5Rates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetLast5Rates`(
	IN sym char(3)
	, IN yr char(4)
)
BEGIN
	SELECT Symbol, Rate, RateDate
	FROM ExchangeRates
	WHERE Symbol = sym 
		AND YEAR(RateDate) = yr
		AND WEEK(RateDate) = WEEK(CURRENT_DATE()) 
	ORDER BY RateDate DESC
	LIMIT 5;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetMetalMissing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetMetalMissing`(
	IN startDate varchar(10),
	IN endDate varchar(10),	
    IN metalName varchar(15)
)
BEGIN
WITH Calendar AS (
    SELECT
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY AS RateDate
    FROM
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
    CROSS JOIN
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b
    CROSS JOIN
        (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
         UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) c
    WHERE
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY >= startDate
    AND
        CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY <= endDate
)
SELECT
    c.RateDate
FROM
    Calendar c
LEFT JOIN
    MetalPrices er ON c.RateDate = er.RateDate AND er.Metal = metalName
WHERE
    WEEKDAY(c.RateDate) < 5             	-- Only weekdays
    AND fn_IsHoliday(c.RateDate) = false	-- Not a U.S. holiday
    AND er.RateDate IS NULL;              	-- No data in MetalPrices
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetMetalPrices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetMetalPrices`(
	IN startDate varchar(10),
	IN endDate varchar(10),
	IN metalName varchar(15),
	IN baseCurrency varchar(3)
)
BEGIN
	SELECT 
		Metal
		, Currency 
		, Price 
		, PrevPriceClose 
		, RateDate 
		, `Timestamp`
		, Chg
		, ChgPct 
		, Price_Gram_24k 
		, Price_Gram_22k 
		, Price_Gram_21k 
		, Price_Gram_20k 
		, Price_Gram_18k 
	FROM MetalPrices
	WHERE RateDate >= startDate
	AND RateDate <= endDate
	AND FIND_IN_SET(Metal, metalName) > 0
	AND Currency = baseCurrency;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetRatesByYear` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetRatesByYear`(IN sym char(3), 
	IN yr char(4))
BEGIN
	SELECT Symbol, Rate, RateDate 
	FROM ExchangeRates 
	WHERE Symbol = sym AND YEAR(RateDate) = yr
	ORDER BY RateDate DESC, Symbol ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_GetRatesByYearMonth` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_GetRatesByYearMonth`(
	IN sym char(3),
	IN yr char(4), IN mnth char(2))
BEGIN
	SELECT Symbol, Rate, RateDate 
	FROM ExchangeRates 
	WHERE Symbol = sym AND YEAR(RateDate) = yr 
		AND MONTH(RateDate) = mnth
	ORDER BY RateDate DESC, Symbol ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_vw_ExchangeRatesByMonthLowAvgHigh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_vw_ExchangeRatesByMonthLowAvgHigh`(
	IN sym char(3)
	, IN yr int
	)
BEGIN
	SELECT * FROM vw_ExchangeRatesByMonthLowAvgHigh 
	WHERE Symbol COLLATE utf8mb4_general_ci = sym
	AND Year = (SELECT IFNULL(yr, YEAR(CURRENT_DATE())));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_vw_ExchangeRatesByQuarterLowAvgHigh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_vw_ExchangeRatesByQuarterLowAvgHigh`(
	IN sym char(3)
	, IN yr int
	)
BEGIN
	SELECT * FROM vw_ExchangeRatesByQuarterLowAvgHigh 
	WHERE Symbol COLLATE utf8mb4_general_ci = sym
	AND Year = (SELECT IFNULL(yr, YEAR(CURRENT_DATE())));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_vw_ExchangeRatesByYearLowAvgHigh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_vw_ExchangeRatesByYearLowAvgHigh`(
	IN sym char(3)
	)
BEGIN
	SELECT * FROM vw_ExchangeRatesByYearLowAvgHigh 
	WHERE Symbol COLLATE utf8mb4_general_ci = sym;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `metalprices`
--

DROP TABLE IF EXISTS `metalprices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metalprices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Metal` varchar(20) NOT NULL,
  `Currency` char(3) NOT NULL,
  `Price` double NOT NULL,
  `PrevPriceClose` double NOT NULL,
  `RateDate` date NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT from_unixtime(unix_timestamp(concat(`RateDate`,' 00:00:00'))),
  `Chg` double NOT NULL,
  `ChgPct` double NOT NULL,
  `AddDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp(),
  `Price_Gram_24k` double NOT NULL,
  `Price_Gram_22k` double NOT NULL,
  `Price_Gram_21k` double NOT NULL,
  `Price_Gram_20k` double NOT NULL,
  `Price_Gram_18k` double NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `MetalPrices_UN` (`Metal`,`Currency`,`RateDate`)
) ENGINE=InnoDB AUTO_INCREMENT=3741 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metalprices`
--

LOCK TABLES `metalprices` WRITE;
/*!40000 ALTER TABLE `metalprices` DISABLE KEYS */;
INSERT INTO `metalprices` VALUES
(1,'XAU','USD',1797.15,1808.15,'2021-07-27','2021-07-27 00:00:00',-11,-0.6121,'2021-07-29 18:46:07','2023-06-27 21:33:02',57.7797,52.9647,50.5572,48.1498,43.3348),
(2,'XAU','USD',1815.3,1803.25,'2021-07-20','2021-07-20 00:00:00',12.05,0.6638,'2021-07-29 18:49:06','2023-06-27 21:33:02',58.3633,53.4996,51.0678,48.636,43.7724),
(3,'XAU','USD',1805.9,1815.3,'2021-07-21','2021-07-21 00:00:00',-9.4,-0.5205,'2021-07-29 18:50:29','2023-06-27 21:33:02',58.061,53.2226,50.8034,48.3842,43.5458),
(4,'XAU','USD',1797.4,1805.9,'2021-07-22','2021-07-22 00:00:00',-8.5,-0.4729,'2021-07-29 18:50:42','2023-06-27 21:33:02',57.7878,52.9721,50.5643,48.1565,43.3408),
(5,'XAU','USD',1803.05,1797.4,'2021-07-23','2021-07-23 00:00:00',5.65,0.3134,'2021-07-29 18:50:57','2023-06-27 21:33:02',57.9694,53.1386,50.7232,48.3078,43.4771),
(8,'XAU','USD',1808.15,1803.05,'2021-07-26','2021-07-26 00:00:00',5.1,0.2821,'2021-07-29 18:52:24','2023-06-27 21:33:02',58.1334,53.2889,50.8667,48.4445,43.6),
(9,'XAU','USD',1803.25,1822,'2021-07-19','2021-07-19 00:00:00',-18.75,-1.0398,'2021-07-29 19:02:37','2023-06-27 21:33:02',57.9758,53.1445,50.7289,48.3132,43.4819),
(12,'XAU','USD',1822,1832,'2021-07-16','2021-07-16 00:00:00',-10,-0.5488,'2021-07-29 19:03:21','2023-06-27 21:33:02',58.5787,53.6971,51.2563,48.8156,43.934),
(13,'XAU','USD',1832,1813.05,'2021-07-15','2021-07-15 00:00:00',18.95,1.0344,'2021-07-29 19:03:35','2023-06-27 21:33:02',58.9002,53.9918,51.5376,49.0835,44.1751),
(14,'XAU','USD',1813.05,1807.85,'2021-07-14','2021-07-14 00:00:00',5.2,0.2868,'2021-07-29 19:03:49','2023-06-27 21:33:02',58.2909,53.4333,51.0045,48.5758,43.7182),
(15,'XAU','USD',1807.85,1802.95,'2021-07-13','2021-07-13 00:00:00',4.9,0.271,'2021-07-29 19:04:02','2023-06-27 21:33:02',58.1237,53.2801,50.8583,48.4364,43.5928),
(16,'XAU','USD',1802.95,1803.4,'2021-07-12','2021-07-12 00:00:00',-0.45,-0.025,'2021-07-29 19:04:15','2023-06-27 21:33:02',57.9662,53.1357,50.7204,48.3052,43.4746),
(19,'XAU','USD',1803.4,1810.25,'2021-07-09','2021-07-09 00:00:00',-6.85,-0.3798,'2021-07-29 19:05:24','2023-06-27 21:33:02',57.9807,53.1489,50.7331,48.3172,43.4855),
(20,'XAU','USD',1810.25,1804.25,'2021-07-08','2021-07-08 00:00:00',6,0.3314,'2021-07-29 19:05:40','2023-06-27 21:33:02',58.2009,53.3508,50.9258,48.5007,43.6507),
(21,'XAU','USD',1804.25,1807.8,'2021-07-07','2021-07-07 00:00:00',-3.55,-0.1968,'2021-07-29 19:05:57','2023-06-27 21:33:02',58.008,53.174,50.757,48.34,43.506),
(22,'XAU','USD',1807.8,1790.95,'2021-07-06','2021-07-06 00:00:00',16.85,0.9321,'2021-07-29 19:06:15','2023-06-27 21:33:02',58.1221,53.2786,50.8569,48.4351,43.5916),
(23,'XAU','USD',1790.95,1783.5,'2021-07-05','2021-07-05 00:00:00',7.45,0.416,'2021-07-29 19:06:46','2023-06-27 21:33:02',0,0,0,0,0),
(26,'XAU','USD',1783.5,1774,'2021-07-02','2021-07-02 00:00:00',9.5,0.5327,'2021-07-29 19:07:29','2023-06-27 21:33:02',57.3409,52.5625,50.1732,47.784,43.0056),
(27,'XAU','USD',1774,1757.8,'2021-07-01','2021-07-01 00:00:00',16.2,0.9132,'2021-07-29 19:07:46','2023-06-27 21:33:02',57.0354,52.2825,49.906,47.5295,42.7766),
(28,'XAU','USD',1757.8,1769.6,'2021-06-30','2021-06-30 00:00:00',-11.8,-0.6713,'2021-07-29 19:08:22','2023-06-27 21:33:02',56.5146,51.805,49.4503,47.0955,42.3859),
(29,'XAU','USD',1769.6,1774.25,'2021-06-29','2021-06-29 00:00:00',-4.65,-0.2628,'2021-07-29 19:08:38','2023-06-27 21:33:02',56.894,52.1528,49.7822,47.4116,42.6705),
(30,'XAU','USD',1774.25,1783.25,'2021-06-28','2021-06-28 00:00:00',-9,-0.5073,'2021-07-29 19:08:56','2023-06-27 21:33:02',57.0435,52.2898,49.913,47.5362,42.7826),
(33,'XAU','USD',1783.25,1780.2,'2021-06-25','2021-06-25 00:00:00',3.05,0.171,'2021-07-29 19:10:07','2023-06-27 21:33:02',57.3328,52.5551,50.1662,47.7773,42.9996),
(34,'XAU','USD',1780.2,1782.9,'2021-06-24','2021-06-24 00:00:00',-2.7,-0.1517,'2021-07-29 19:10:23','2023-06-27 21:33:02',57.2348,52.4652,50.0804,47.6956,42.9261),
(35,'XAU','USD',1782.9,1779.1,'2021-06-23','2021-06-23 00:00:00',3.8,0.2131,'2021-07-29 19:10:38','2023-06-27 21:33:02',57.3216,52.5448,50.1564,47.768,42.9912),
(36,'XAU','USD',1779.1,1782.45,'2021-06-22','2021-06-22 00:00:00',-3.35,-0.1883,'2021-07-29 19:10:51','2023-06-27 21:33:02',57.1994,52.4328,50.0495,47.6662,42.8995),
(37,'XAU','USD',1782.45,1792.35,'2021-06-21','2021-06-21 00:00:00',-9.9,-0.5554,'2021-07-29 19:11:03','2023-06-27 21:33:02',57.3071,52.5315,50.1437,47.7559,42.9803),
(40,'XAU','USD',1792.35,1806.75,'2021-06-18','2021-06-18 00:00:00',-14.4,-0.8034,'2021-07-29 19:11:57','2023-06-27 21:33:02',0,0,0,0,0),
(41,'XAU','USD',1806.75,1858.1,'2021-06-17','2021-06-17 00:00:00',-51.35,-2.8421,'2021-07-29 19:12:08','2023-06-27 21:33:02',58.0884,53.2477,50.8273,48.407,43.5663),
(42,'XAU','USD',1858.1,1863.85,'2021-06-16','2021-06-16 00:00:00',-5.75,-0.3095,'2021-07-29 19:12:18','2023-06-27 21:33:02',59.7393,54.761,52.2719,49.7828,44.8045),
(43,'XAU','USD',1863.85,1859.75,'2021-06-15','2021-06-15 00:00:00',4.1,0.22,'2021-07-29 19:12:29','2023-06-27 21:33:02',59.9242,54.9305,52.4336,49.9368,44.9431),
(44,'XAU','USD',1859.75,1891.95,'2021-06-14','2021-06-14 00:00:00',-32.2,-1.7314,'2021-07-29 19:12:39','2023-06-27 21:33:02',59.7924,54.8097,52.3183,49.827,44.8443),
(47,'XAU','USD',1891.95,1882,'2021-06-11','2021-06-11 00:00:00',9.95,0.5259,'2021-07-29 19:13:10','2023-06-27 21:33:02',60.8276,55.7586,53.2242,50.6897,45.6207),
(48,'XAU','USD',1882,1890.45,'2021-06-10','2021-06-10 00:00:00',-8.45,-0.449,'2021-07-29 19:13:17','2023-06-27 21:33:02',60.5077,55.4654,52.9442,50.4231,45.3808),
(49,'XAU','USD',1890.45,1892.05,'2021-06-09','2021-06-09 00:00:00',-1.6,-0.0846,'2021-07-29 19:13:26','2023-06-27 21:33:02',60.7794,55.7144,53.182,50.6495,45.5845),
(50,'XAU','USD',1892.05,1882.05,'2021-06-08','2021-06-08 00:00:00',10,0.5285,'2021-07-29 19:13:34','2023-06-27 21:33:02',60.8308,55.7616,53.227,50.6924,45.6231),
(51,'XAU','USD',1882.05,1869.55,'2021-06-07','2021-06-07 00:00:00',12.5,0.6642,'2021-07-29 19:13:42','2023-06-27 21:33:02',60.5093,55.4669,52.9456,50.4244,45.382),
(54,'XAU','USD',1869.55,1892.15,'2021-06-04','2021-06-04 00:00:00',-22.6,-1.2088,'2021-07-29 19:14:04','2023-06-27 21:33:02',60.1074,55.0985,52.594,50.0895,45.0806),
(55,'XAU','USD',1892.15,1895.9,'2021-06-03','2021-06-03 00:00:00',-3.75,-0.1982,'2021-07-29 19:14:10','2023-06-27 21:33:02',60.834,55.7645,53.2298,50.695,45.6255),
(56,'XAU','USD',1895.9,1907.7,'2021-06-02','2021-06-02 00:00:00',-11.8,-0.6224,'2021-07-29 19:14:17','2023-06-27 21:33:02',60.9546,55.8751,53.3353,50.7955,45.716),
(57,'XAU','USD',1907.7,1892.45,'2021-06-01','2021-06-01 00:00:00',15.25,0.7994,'2021-07-29 19:14:24','2023-06-27 21:33:02',61.334,56.2228,53.6672,51.1116,46.0005),
(60,'XAU','USD',1892.45,1895.05,'2021-05-28','2021-05-28 00:00:00',-2.6,-0.1374,'2021-07-29 19:55:41','2023-06-27 21:33:02',60.8437,55.7734,53.2382,50.7031,45.6328),
(61,'XAU','USD',1895.05,1904.3,'2021-05-27','2021-05-27 00:00:00',-9.25,-0.4881,'2021-07-29 19:55:41','2023-06-27 21:33:02',60.9273,55.85,53.3114,50.7727,45.6955),
(62,'XAU','USD',1904.3,1882.8,'2021-05-26','2021-05-26 00:00:00',21.5,1.129,'2021-07-29 19:55:42','2023-06-27 21:33:02',61.2247,56.1226,53.5716,51.0206,45.9185),
(63,'XAU','USD',1882.8,1876.85,'2021-05-25','2021-05-25 00:00:00',5.95,0.316,'2021-07-29 19:55:42','2023-06-27 21:33:02',60.5334,55.489,52.9667,50.4445,45.4001),
(64,'XAU','USD',1876.85,1877.65,'2021-05-24','2021-05-24 00:00:00',-0.8,-0.0426,'2021-07-29 19:55:43','2023-06-27 21:33:02',60.3421,55.3136,52.7994,50.2851,45.2566),
(67,'XAU','USD',1877.65,1869.35,'2021-05-21','2021-05-21 00:00:00',8.3,0.442,'2021-07-29 19:55:44','2023-06-27 21:33:02',60.3678,55.3372,52.8219,50.3065,45.2759),
(68,'XAU','USD',1869.35,1860,'2021-05-20','2021-05-20 00:00:00',9.35,0.5002,'2021-07-29 19:55:45','2023-06-27 21:33:02',60.101,55.0926,52.5884,50.0842,45.0757),
(69,'XAU','USD',1860,1867.4,'2021-05-19','2021-05-19 00:00:00',-7.4,-0.3978,'2021-07-29 19:55:45','2023-06-27 21:33:02',59.8004,54.817,52.3253,49.8337,44.8503),
(70,'XAU','USD',1867.4,1848.45,'2021-05-18','2021-05-18 00:00:00',18.95,1.0148,'2021-07-29 19:55:46','2023-06-27 21:33:02',60.0383,55.0351,52.5335,50.0319,45.0287),
(71,'XAU','USD',1848.45,1833.5,'2021-05-17','2021-05-17 00:00:00',14.95,0.8088,'2021-07-29 19:55:47','2023-06-27 21:33:02',59.429,54.4766,52.0004,49.5242,44.5718),
(74,'XAU','USD',1833.5,1814.3,'2021-05-14','2021-05-14 00:00:00',19.2,1.0472,'2021-07-29 19:55:48','2023-06-27 21:33:02',58.9484,54.036,51.5798,49.1237,44.2113),
(75,'XAU','USD',1814.3,1833.6,'2021-05-13','2021-05-13 00:00:00',-19.3,-1.0638,'2021-07-29 19:55:49','2023-06-27 21:33:02',58.3311,53.4702,51.0397,48.6092,43.7483),
(76,'XAU','USD',1833.6,1837.15,'2021-05-12','2021-05-12 00:00:00',-3.55,-0.1936,'2021-07-29 19:55:50','2023-06-27 21:33:02',58.9516,54.039,51.5827,49.1263,44.2137),
(77,'XAU','USD',1837.15,1834.15,'2021-05-11','2021-05-11 00:00:00',3,0.1633,'2021-07-29 19:55:50','2023-06-27 21:33:02',59.0657,54.1436,51.6825,49.2215,44.2993),
(78,'XAU','USD',1834.15,1820.5,'2021-05-10','2021-05-10 00:00:00',13.65,0.7442,'2021-07-29 19:55:51','2023-06-27 21:33:02',58.9693,54.0552,51.5981,49.1411,44.227),
(81,'XAU','USD',1820.5,1793.15,'2021-05-07','2021-05-07 00:00:00',27.35,1.5023,'2021-07-29 19:55:52','2023-06-27 21:33:02',58.5304,53.6529,51.2141,48.7754,43.8978),
(82,'XAU','USD',1793.15,1778.05,'2021-05-06','2021-05-06 00:00:00',15.1,0.8421,'2021-07-29 19:55:53','2023-06-27 21:33:02',57.6511,52.8469,50.4447,48.0426,43.2383),
(83,'XAU','USD',1778.05,1784.95,'2021-05-05','2021-05-05 00:00:00',-6.9,-0.3881,'2021-07-29 19:55:53','2023-06-27 21:33:02',57.1656,52.4018,50.0199,47.638,42.8742),
(84,'XAU','USD',1784.95,1768.8,'2021-05-04','2021-05-04 00:00:00',16.15,0.9048,'2021-07-29 19:55:54','2023-06-27 21:33:02',57.3875,52.6052,50.214,47.8229,43.0406),
(85,'XAU','USD',1768.8,1768.8,'2021-05-03','2021-05-03 00:00:00',0,0,'2021-07-29 19:55:54','2023-06-27 21:33:02',56.8682,52.1292,49.7597,47.3902,42.6512),
(88,'XAU','USD',1768.8,1774.65,'2021-04-30','2021-04-30 00:00:00',-5.85,-0.3307,'2021-07-29 19:55:56','2023-06-27 21:33:02',56.8682,52.1292,49.7597,47.3902,42.6512),
(89,'XAU','USD',1774.65,1764.15,'2021-04-29','2021-04-29 00:00:00',10.5,0.5917,'2021-07-29 19:55:57','2023-06-27 21:33:02',57.0563,52.3016,49.9243,47.5469,42.7922),
(90,'XAU','USD',1764.15,1780.9,'2021-04-28','2021-04-28 00:00:00',-16.75,-0.9495,'2021-07-29 19:55:57','2023-06-27 21:33:02',56.7187,51.9922,49.6289,47.2656,42.5391),
(91,'XAU','USD',1780.9,1779.65,'2021-04-27','2021-04-27 00:00:00',1.25,0.0702,'2021-07-29 19:55:58','2023-06-27 21:33:02',57.2573,52.4858,50.1001,47.7144,42.9429),
(92,'XAU','USD',1779.65,1785.3,'2021-04-26','2021-04-26 00:00:00',-5.65,-0.3175,'2021-07-29 19:55:58','2023-06-27 21:33:02',0,0,0,0,0),
(95,'XAU','USD',1785.3,1785.65,'2021-04-23','2021-04-23 00:00:00',-0.35,-0.0196,'2021-07-29 19:56:00','2023-06-27 21:33:02',57.3987,52.6155,50.2239,47.8323,43.049),
(96,'XAU','USD',1785.65,1781.05,'2021-04-22','2021-04-22 00:00:00',4.6,0.2576,'2021-07-29 19:56:01','2023-06-27 21:33:02',57.41,52.6258,50.2337,47.8417,43.0575),
(97,'XAU','USD',1781.05,1765.5,'2021-04-21','2021-04-21 00:00:00',15.55,0.8731,'2021-07-29 19:56:01','2023-06-27 21:33:02',57.2621,52.4902,50.1043,47.7184,42.9466),
(98,'XAU','USD',1765.5,1788.4,'2021-04-20','2021-04-20 00:00:00',-22.9,-1.2971,'2021-07-29 19:56:02','2023-06-27 21:33:02',56.7621,52.032,49.6669,47.3018,42.5716),
(99,'XAU','USD',1788.4,1766.45,'2021-04-19','2021-04-19 00:00:00',21.95,1.2274,'2021-07-29 19:56:02','2023-06-27 21:33:02',57.4984,52.7069,50.3111,47.9153,43.1238),
(102,'XAU','USD',1766.45,1748,'2021-04-16','2021-04-16 00:00:00',18.45,1.0445,'2021-07-29 19:56:04','2023-06-27 21:33:02',56.7927,52.06,49.6936,47.3272,42.5945),
(103,'XAU','USD',1748,1743.3,'2021-04-15','2021-04-15 00:00:00',4.7,0.2689,'2021-07-29 19:56:05','2023-06-27 21:33:02',56.1995,51.5162,49.1746,46.8329,42.1496),
(104,'XAU','USD',1743.3,1728.1,'2021-04-14','2021-04-14 00:00:00',15.2,0.8719,'2021-07-29 19:56:05','2023-06-27 21:33:02',56.0484,51.3777,49.0423,46.707,42.0363),
(105,'XAU','USD',1728.1,1741.55,'2021-04-13','2021-04-13 00:00:00',-13.45,-0.7783,'2021-07-29 19:56:06','2023-06-27 21:33:02',55.5597,50.9297,48.6147,46.2998,41.6698),
(106,'XAU','USD',1741.55,1747.95,'2021-04-12','2021-04-12 00:00:00',-6.4,-0.3675,'2021-07-29 19:56:07','2023-06-27 21:33:02',55.9921,51.3261,48.9931,46.6601,41.9941),
(109,'XAU','USD',1747.95,1743.7,'2021-04-09','2021-04-09 00:00:00',4.25,0.2431,'2021-07-29 19:56:09','2023-06-27 21:33:02',56.1979,51.5147,49.1732,46.8316,42.1484),
(110,'XAU','USD',1743.7,1736,'2021-04-08','2021-04-08 00:00:00',7.7,0.4416,'2021-07-29 19:56:09','2023-06-27 21:33:02',56.0613,51.3895,49.0536,46.7177,42.0459),
(111,'XAU','USD',1736,1731.05,'2021-04-07','2021-04-07 00:00:00',4.95,0.2851,'2021-07-29 19:56:10','2023-06-27 21:33:02',55.8137,51.1626,48.837,46.5114,41.8603),
(112,'XAU','USD',1731.05,1715.85,'2021-04-06','2021-04-06 00:00:00',15.2,0.8781,'2021-07-29 19:56:11','2023-06-27 21:33:02',55.6545,51.0167,48.6977,46.3788,41.7409),
(113,'XAU','USD',1715.85,1715.85,'2021-04-05','2021-04-05 00:00:00',0,0,'2021-07-29 19:56:11','2023-06-27 21:33:02',55.1659,50.5687,48.2701,45.9715,41.3744),
(116,'XAU','USD',1715.85,1715.85,'2021-04-02','2021-04-02 00:00:00',0,0,'2021-07-29 19:56:13','2023-06-27 21:33:02',55.1659,50.5687,48.2701,45.9715,41.3744),
(117,'XAU','USD',1715.85,1685.35,'2021-04-01','2021-04-01 00:00:00',30.5,1.7775,'2021-07-29 19:56:14','2023-06-27 21:33:02',55.1659,50.5687,48.2701,45.9715,41.3744),
(118,'XAU','USD',1685.35,1696.7,'2021-03-31','2021-03-31 00:00:00',-11.35,-0.6735,'2021-07-29 19:56:14','2023-06-27 21:33:02',54.1853,49.6698,47.4121,45.1544,40.6389),
(119,'XAU','USD',1696.7,1723.95,'2021-03-30','2021-03-30 00:00:00',-27.25,-1.6061,'2021-07-29 19:56:15','2023-06-27 21:33:02',54.5502,50.0043,47.7314,45.4585,40.9126),
(120,'XAU','USD',1723.95,1727.85,'2021-03-29','2021-03-29 00:00:00',-3.9,-0.2262,'2021-07-29 19:56:16','2023-06-27 21:33:02',55.4263,50.8074,48.498,46.1886,41.5697),
(123,'XAU','USD',1727.85,1729.2,'2021-03-26','2021-03-26 00:00:00',-1.35,-0.0781,'2021-07-29 19:56:18','2023-06-27 21:33:02',55.5517,50.9224,48.6077,46.2931,41.6638),
(124,'XAU','USD',1729.2,1734.05,'2021-03-25','2021-03-25 00:00:00',-4.85,-0.2805,'2021-07-29 19:56:18','2023-06-27 21:33:02',55.5951,50.9621,48.6457,46.3292,41.6963),
(125,'XAU','USD',1734.05,1739.25,'2021-03-24','2021-03-24 00:00:00',-5.2,-0.2999,'2021-07-29 19:56:19','2023-06-27 21:33:02',55.751,51.1051,48.7821,46.4592,41.8133),
(126,'XAU','USD',1739.25,1733.4,'2021-03-23','2021-03-23 00:00:00',5.85,0.3364,'2021-07-29 19:56:19','2023-06-27 21:33:02',55.9182,51.2583,48.9284,46.5985,41.9386),
(127,'XAU','USD',1733.4,1737.2,'2021-03-22','2021-03-22 00:00:00',-3.8,-0.2192,'2021-07-29 19:56:20','2023-06-27 21:33:02',55.7301,51.0859,48.7638,46.4418,41.7976),
(130,'XAU','USD',1737.2,1734.1,'2021-03-19','2021-03-19 00:00:00',3.1,0.1784,'2021-07-29 19:56:22','2023-06-27 21:33:02',55.8523,51.1979,48.8707,46.5436,41.8892),
(131,'XAU','USD',1734.1,1736.95,'2021-03-18','2021-03-18 00:00:00',-2.85,-0.1644,'2021-07-29 19:56:23','2023-06-27 21:33:02',55.7526,51.1066,48.7835,46.4605,41.8145),
(132,'XAU','USD',1736.95,1732.3,'2021-03-17','2021-03-17 00:00:00',4.65,0.2677,'2021-07-29 19:56:23','2023-06-27 21:33:02',55.8442,51.1906,48.8637,46.5369,41.8832),
(133,'XAU','USD',1732.3,1727.9,'2021-03-16','2021-03-16 00:00:00',4.4,0.254,'2021-07-29 19:56:24','2023-06-27 21:33:02',55.6947,51.0535,48.7329,46.4123,41.7711),
(134,'XAU','USD',1727.9,1703.85,'2021-03-15','2021-03-15 00:00:00',24.05,1.3919,'2021-07-29 19:56:24','2023-06-27 21:33:02',55.5533,50.9238,48.6091,46.2944,41.665),
(137,'XAU','USD',1703.85,1736.35,'2021-03-12','2021-03-12 00:00:00',-32.5,-1.9074,'2021-07-29 19:56:26','2023-06-27 21:33:02',54.78,50.215,47.9325,45.65,41.085),
(138,'XAU','USD',1736.35,1711.5,'2021-03-11','2021-03-11 00:00:00',24.85,1.4312,'2021-07-29 19:56:26','2023-06-27 21:33:02',55.8249,51.1729,48.8468,46.5208,41.8687),
(139,'XAU','USD',1711.5,1702.85,'2021-03-10','2021-03-10 00:00:00',8.65,0.5054,'2021-07-29 19:56:27','2023-06-27 21:33:02',55.026,50.4405,48.1478,45.855,41.2695),
(140,'XAU','USD',1702.85,1694.45,'2021-03-09','2021-03-09 00:00:00',8.4,0.4933,'2021-07-29 19:56:28','2023-06-27 21:33:02',54.7479,50.1856,47.9044,45.6232,41.0609),
(141,'XAU','USD',1694.45,1696.05,'2021-03-08','2021-03-08 00:00:00',-1.6,-0.0944,'2021-07-29 19:56:28','2023-06-27 21:33:02',54.4778,49.938,47.6681,45.3982,40.8584),
(144,'XAU','USD',1696.05,1710.05,'2021-03-05','2021-03-05 00:00:00',-14,-0.8254,'2021-07-29 19:56:30','2023-06-27 21:33:02',54.5293,49.9852,47.7131,45.4411,40.897),
(145,'XAU','USD',1710.05,1727.05,'2021-03-04','2021-03-04 00:00:00',-17,-0.9941,'2021-07-29 19:56:31','2023-06-27 21:33:02',54.9794,50.3978,48.107,45.8162,41.2345),
(146,'XAU','USD',1727.05,1728.5,'2021-03-03','2021-03-03 00:00:00',-1.45,-0.084,'2021-07-29 19:56:31','2023-06-27 21:33:02',55.5259,50.8988,48.5852,46.2716,41.6445),
(147,'XAU','USD',1728.5,1746.95,'2021-03-02','2021-03-02 00:00:00',-18.45,-1.0674,'2021-07-29 19:56:32','2023-06-27 21:33:02',55.5726,50.9415,48.626,46.3105,41.6794),
(148,'XAU','USD',1746.95,1765.1,'2021-03-01','2021-03-01 00:00:00',-18.15,-1.039,'2021-07-29 19:56:33','2023-06-27 21:33:02',56.1657,51.4853,49.145,46.8048,42.1243),
(151,'XAU','USD',1765.1,1792.1,'2021-02-26','2021-02-26 00:00:00',-27,-1.5297,'2021-07-29 19:56:36','2023-06-27 21:33:02',56.7493,52.0202,49.6556,47.2911,42.562),
(152,'XAU','USD',1792.1,1807.25,'2021-02-25','2021-02-25 00:00:00',-15.15,-0.8454,'2021-07-29 19:56:37','2023-06-27 21:33:02',57.6174,52.8159,50.4152,48.0145,43.213),
(153,'XAU','USD',1807.25,1809.5,'2021-02-24','2021-02-24 00:00:00',-2.25,-0.1245,'2021-07-29 19:56:38','2023-06-27 21:33:02',58.1044,53.2624,50.8414,48.4204,43.5783),
(154,'XAU','USD',1809.5,1798.8,'2021-02-23','2021-02-23 00:00:00',10.7,0.5913,'2021-07-29 19:56:38','2023-06-27 21:33:02',58.1768,53.3287,50.9047,48.4806,43.6326),
(155,'XAU','USD',1798.8,1773.75,'2021-02-22','2021-02-22 00:00:00',25.05,1.3926,'2021-07-29 19:56:39','2023-06-27 21:33:02',57.8328,53.0134,50.6037,48.194,43.3746),
(158,'XAU','USD',1773.75,1782.8,'2021-02-19','2021-02-19 00:00:00',-9.05,-0.5102,'2021-07-29 19:56:41','2023-06-27 21:33:02',57.0274,52.2751,49.899,47.5228,42.7705),
(159,'XAU','USD',1782.8,1788.85,'2021-02-18','2021-02-18 00:00:00',-6.05,-0.3394,'2021-07-29 19:56:41','2023-06-27 21:33:02',57.3184,52.5418,50.1536,47.7653,42.9888),
(160,'XAU','USD',1788.85,1823.45,'2021-02-17','2021-02-17 00:00:00',-34.6,-1.9342,'2021-07-29 19:56:42','2023-06-27 21:33:02',57.5129,52.7201,50.3238,47.9274,43.1346),
(161,'XAU','USD',1823.45,1817.45,'2021-02-16','2021-02-16 00:00:00',6,0.329,'2021-07-29 19:56:42','2023-06-27 21:33:02',58.6253,53.7398,51.2971,48.8544,43.969),
(162,'XAU','USD',1817.45,1818,'2021-02-15','2021-02-15 00:00:00',-0.55,-0.0303,'2021-07-29 19:56:43','2023-06-27 21:33:02',0,0,0,0,0),
(165,'XAU','USD',1818,1841.7,'2021-02-12','2021-02-12 00:00:00',-23.7,-1.3036,'2021-07-29 19:56:45','2023-06-27 21:33:02',58.4501,53.5792,51.1438,48.7084,43.8375),
(166,'XAU','USD',1841.7,1843.45,'2021-02-11','2021-02-11 00:00:00',-1.75,-0.095,'2021-07-29 19:56:46','2023-06-27 21:33:02',59.212,54.2777,51.8105,49.3434,44.409),
(167,'XAU','USD',1843.45,1846.55,'2021-02-10','2021-02-10 00:00:00',-3.1,-0.1682,'2021-07-29 19:56:47','2023-06-27 21:33:02',59.2683,54.3293,51.8598,49.3902,44.4512),
(168,'XAU','USD',1846.55,1811.65,'2021-02-09','2021-02-09 00:00:00',34.9,1.89,'2021-07-29 19:56:47','2023-06-27 21:33:02',59.368,54.4206,51.947,49.4733,44.526),
(169,'XAU','USD',1811.65,1808.55,'2021-02-08','2021-02-08 00:00:00',3.1,0.1711,'2021-07-29 19:56:48','2023-06-27 21:33:02',58.2459,53.3921,50.9652,48.5383,43.6844),
(172,'XAU','USD',1808.55,1811.55,'2021-02-05','2021-02-05 00:00:00',-3,-0.1659,'2021-07-29 19:56:50','2023-06-27 21:33:02',58.1462,53.3007,50.878,48.4552,43.6097),
(173,'XAU','USD',1811.55,1834.7,'2021-02-04','2021-02-04 00:00:00',-23.15,-1.2779,'2021-07-29 19:56:51','2023-06-27 21:33:02',58.2427,53.3891,50.9623,48.5356,43.682),
(174,'XAU','USD',1834.7,1847.1,'2021-02-03','2021-02-03 00:00:00',-12.4,-0.6759,'2021-07-29 19:56:51','2023-06-27 21:33:02',58.987,54.0714,51.6136,49.1558,44.2402),
(175,'XAU','USD',1847.1,1857.8,'2021-02-02','2021-02-02 00:00:00',-10.7,-0.5793,'2021-07-29 19:56:52','2023-06-27 21:33:02',59.3856,54.4368,51.9624,49.488,44.5392),
(176,'XAU','USD',1857.8,1852.7,'2021-02-01','2021-02-01 00:00:00',5.1,0.2745,'2021-07-29 19:56:52','2023-06-27 21:33:02',59.7297,54.7522,52.2634,49.7747,44.7972),
(179,'XAU','USD',1852.7,1839.65,'2021-01-29','2021-01-29 00:00:00',13.05,0.7044,'2021-07-29 19:56:54','2023-06-27 21:33:02',59.5657,54.6019,52.12,49.6381,44.6743),
(180,'XAU','USD',1839.65,1846.4,'2021-01-28','2021-01-28 00:00:00',-6.75,-0.3669,'2021-07-29 19:56:55','2023-06-27 21:33:02',59.1461,54.2173,51.7529,49.2884,44.3596),
(181,'XAU','USD',1846.4,1853.2,'2021-01-27','2021-01-27 00:00:00',-6.8,-0.3683,'2021-07-29 19:56:55','2023-06-27 21:33:02',59.3631,54.4162,51.9427,49.4693,44.5224),
(182,'XAU','USD',1853.2,1855.6,'2021-01-26','2021-01-26 00:00:00',-2.4,-0.1295,'2021-07-29 19:56:56','2023-06-27 21:33:02',59.5818,54.6166,52.134,49.6515,44.6863),
(183,'XAU','USD',1855.6,1853.6,'2021-01-25','2021-01-25 00:00:00',2,0.1078,'2021-07-29 19:56:56','2023-06-27 21:33:02',59.6589,54.6873,52.2016,49.7158,44.7442),
(186,'XAU','USD',1853.6,1867.65,'2021-01-22','2021-01-22 00:00:00',-14.05,-0.758,'2021-07-29 19:56:58','2023-06-27 21:33:02',59.5946,54.6284,52.1453,49.6622,44.696),
(187,'XAU','USD',1867.65,1854.6,'2021-01-21','2021-01-21 00:00:00',13.05,0.6987,'2021-07-29 19:56:59','2023-06-27 21:33:02',60.0463,55.0425,52.5405,50.0386,45.0348),
(188,'XAU','USD',1854.6,1843.1,'2021-01-20','2021-01-20 00:00:00',11.5,0.6201,'2021-07-29 19:56:59','2023-06-27 21:33:02',59.6268,54.6579,52.1734,49.689,44.7201),
(189,'XAU','USD',1843.1,1833.95,'2021-01-19','2021-01-19 00:00:00',9.15,0.4964,'2021-07-29 19:57:00','2023-06-27 21:33:02',59.257,54.319,51.8499,49.3809,44.4428),
(190,'XAU','USD',1833.95,1853.85,'2021-01-18','2021-01-18 00:00:00',-19.9,-1.0851,'2021-07-29 19:57:00','2023-06-27 21:33:02',0,0,0,0,0),
(193,'XAU','USD',1853.85,1840.25,'2021-01-15','2021-01-15 00:00:00',13.6,0.7336,'2021-07-29 19:57:02','2023-06-27 21:33:02',59.6027,54.6358,52.1523,49.6689,44.702),
(194,'XAU','USD',1840.25,1852.4,'2021-01-14','2021-01-14 00:00:00',-12.15,-0.6602,'2021-07-29 19:57:03','2023-06-27 21:33:02',59.1654,54.235,51.7697,49.3045,44.3741),
(195,'XAU','USD',1852.4,1861.85,'2021-01-13','2021-01-13 00:00:00',-9.45,-0.5101,'2021-07-29 19:57:04','2023-06-27 21:33:02',59.556,54.593,52.1115,49.63,44.667),
(196,'XAU','USD',1861.85,1847.8,'2021-01-12','2021-01-12 00:00:00',14.05,0.7546,'2021-07-29 19:57:05','2023-06-27 21:33:02',59.8599,54.8715,52.3774,49.8832,44.8949),
(197,'XAU','USD',1847.8,1891.3,'2021-01-11','2021-01-11 00:00:00',-43.5,-2.3542,'2021-07-29 19:57:05','2023-06-27 21:33:02',59.4081,54.4575,51.9821,49.5068,44.5561),
(200,'XAU','USD',1891.3,1911.05,'2021-01-08','2021-01-08 00:00:00',-19.75,-1.0443,'2021-07-29 19:57:07','2023-06-27 21:33:02',60.8067,55.7395,53.2059,50.6723,45.605),
(201,'XAU','USD',1911.05,1957.2,'2021-01-07','2021-01-07 00:00:00',-46.15,-2.4149,'2021-07-29 19:57:08','2023-06-27 21:33:02',61.4417,56.3215,53.7615,51.2014,46.0813),
(202,'XAU','USD',1957.2,1946.55,'2021-01-06','2021-01-06 00:00:00',10.65,0.5441,'2021-07-29 19:57:09','2023-06-27 21:33:02',62.9254,57.6817,55.0598,52.4379,47.1941),
(203,'XAU','USD',1946.55,1930.8,'2021-01-05','2021-01-05 00:00:00',15.75,0.8091,'2021-07-29 19:57:09','2023-06-27 21:33:02',62.583,57.3678,54.7602,52.1525,46.9373),
(204,'XAU','USD',1930.8,1891.1,'2021-01-04','2021-01-04 00:00:00',39.7,2.0561,'2021-07-29 19:57:10','2023-06-27 21:33:02',62.0767,56.9036,54.3171,51.7306,46.5575),
(208,'XAU','USD',1891.1,1877.55,'2020-12-31','2020-12-31 00:00:00',13.55,0.7165,'2021-07-29 19:57:12','2023-06-27 21:33:02',0,0,0,0,0),
(209,'XAU','USD',1877.55,1873.9,'2020-12-30','2020-12-30 00:00:00',3.65,0.1944,'2021-07-29 19:57:13','2023-06-27 21:33:02',0,0,0,0,0),
(210,'XAU','USD',1873.9,1872.55,'2020-12-29','2020-12-29 00:00:00',1.35,0.072,'2021-07-29 19:57:14','2023-06-27 21:33:02',0,0,0,0,0),
(211,'XAU','USD',1872.55,1872.55,'2020-12-28','2020-12-28 00:00:00',0,0,'2021-07-29 19:57:14','2023-06-27 21:33:02',0,0,0,0,0),
(214,'XAU','USD',1872.55,1872.55,'2020-12-25','2020-12-25 00:00:00',0,0,'2021-07-29 19:57:16','2023-06-27 21:33:02',0,0,0,0,0),
(215,'XAU','USD',1872.55,1867.1,'2020-12-24','2020-12-24 00:00:00',5.45,0.291,'2021-07-29 19:57:17','2023-06-27 21:33:02',0,0,0,0,0),
(216,'XAU','USD',1867.1,1873.3,'2020-12-23','2020-12-23 00:00:00',-6.2,-0.3321,'2021-07-29 19:57:17','2023-06-27 21:33:02',0,0,0,0,0),
(217,'XAU','USD',1873.3,1869.25,'2020-12-22','2020-12-22 00:00:00',4.05,0.2162,'2021-07-29 19:57:18','2023-06-27 21:33:02',0,0,0,0,0),
(218,'XAU','USD',1869.25,1878.95,'2020-12-21','2020-12-21 00:00:00',-9.7,-0.5189,'2021-07-29 19:57:18','2023-06-27 21:33:02',0,0,0,0,0),
(221,'XAU','USD',1878.95,1871.95,'2020-12-18','2020-12-18 00:00:00',7,0.3725,'2021-07-29 19:57:21','2023-06-27 21:33:02',0,0,0,0,0),
(222,'XAU','USD',1871.95,1861.35,'2020-12-17','2020-12-17 00:00:00',10.6,0.5663,'2021-07-29 19:57:21','2023-06-27 21:33:02',0,0,0,0,0),
(223,'XAU','USD',1861.35,1844.3,'2020-12-16','2020-12-16 00:00:00',17.05,0.916,'2021-07-29 19:57:22','2023-06-27 21:33:02',0,0,0,0,0),
(224,'XAU','USD',1844.3,1820.25,'2020-12-15','2020-12-15 00:00:00',24.05,1.304,'2021-07-29 19:57:22','2023-06-27 21:33:02',0,0,0,0,0),
(225,'XAU','USD',1820.25,1833.65,'2020-12-14','2020-12-14 00:00:00',-13.4,-0.7362,'2021-07-29 19:57:23','2023-06-27 21:33:02',0,0,0,0,0),
(228,'XAU','USD',1833.65,1834.2,'2020-12-11','2020-12-11 00:00:00',-0.55,-0.03,'2021-07-29 19:57:25','2023-06-27 21:33:02',0,0,0,0,0),
(229,'XAU','USD',1834.2,1859.8,'2020-12-10','2020-12-10 00:00:00',-25.6,-1.3957,'2021-07-29 19:57:26','2023-06-27 21:33:02',0,0,0,0,0),
(230,'XAU','USD',1859.8,1864.5,'2020-12-09','2020-12-09 00:00:00',-4.7,-0.2527,'2021-07-29 19:57:27','2023-06-27 21:33:02',0,0,0,0,0),
(231,'XAU','USD',1864.5,1832.8,'2020-12-08','2020-12-08 00:00:00',31.7,1.7002,'2021-07-29 19:57:27','2023-06-27 21:33:02',0,0,0,0,0),
(232,'XAU','USD',1832.8,1839.3,'2020-12-07','2020-12-07 00:00:00',-6.5,-0.3546,'2021-07-29 19:57:28','2023-06-27 21:33:02',0,0,0,0,0),
(235,'XAU','USD',1839.3,1834.8,'2020-12-04','2020-12-04 00:00:00',4.5,0.2447,'2021-07-29 19:57:30','2023-06-27 21:33:02',0,0,0,0,0),
(236,'XAU','USD',1834.8,1832.95,'2020-12-03','2020-12-03 00:00:00',1.85,0.1008,'2021-07-29 19:57:30','2023-06-27 21:33:02',0,0,0,0,0),
(237,'XAU','USD',1832.95,1796.2,'2020-12-02','2020-12-02 00:00:00',36.75,2.005,'2021-07-29 19:57:31','2023-06-27 21:33:02',0,0,0,0,0),
(238,'XAU','USD',1796.2,1771.95,'2020-12-01','2020-12-01 00:00:00',24.25,1.3501,'2021-07-29 19:57:32','2023-06-27 21:33:02',0,0,0,0,0),
(239,'XAU','USD',1771.95,1808.05,'2020-11-30','2020-11-30 00:00:00',-36.1,-2.0373,'2021-07-29 19:57:32','2023-06-27 21:33:02',0,0,0,0,0),
(242,'XAU','USD',1808.05,1814.85,'2020-11-27','2020-11-27 00:00:00',-6.8,-0.3761,'2021-07-29 19:57:34','2023-06-27 21:33:02',0,0,0,0,0),
(243,'XAU','USD',1814.85,1808.55,'2020-11-26','2020-11-26 00:00:00',6.3,0.3471,'2021-07-29 19:57:34','2023-06-27 21:33:02',0,0,0,0,0),
(244,'XAU','USD',1808.55,1818.1,'2020-11-25','2020-11-25 00:00:00',-9.55,-0.528,'2021-07-29 19:57:35','2023-06-27 21:33:02',0,0,0,0,0),
(245,'XAU','USD',1818.1,1863.8,'2020-11-24','2020-11-24 00:00:00',-45.7,-2.5136,'2021-07-29 19:57:36','2023-06-27 21:33:02',0,0,0,0,0),
(246,'XAU','USD',1863.8,1867,'2020-11-23','2020-11-23 00:00:00',-3.2,-0.1717,'2021-07-29 19:57:36','2023-06-27 21:33:02',0,0,0,0,0),
(249,'XAU','USD',1867,1857.4,'2020-11-20','2020-11-20 00:00:00',9.6,0.5142,'2021-07-29 19:57:38','2023-06-27 21:33:02',0,0,0,0,0),
(250,'XAU','USD',1857.4,1877.2,'2020-11-19','2020-11-19 00:00:00',-19.8,-1.066,'2021-07-29 19:57:39','2023-06-27 21:33:02',0,0,0,0,0),
(251,'XAU','USD',1877.2,1885.4,'2020-11-18','2020-11-18 00:00:00',-8.2,-0.4368,'2021-07-29 19:57:40','2023-06-27 21:33:02',0,0,0,0,0),
(252,'XAU','USD',1885.4,1892.6,'2020-11-17','2020-11-17 00:00:00',-7.2,-0.3819,'2021-07-29 19:57:40','2023-06-27 21:33:02',0,0,0,0,0),
(253,'XAU','USD',1892.6,1878.2,'2020-11-16','2020-11-16 00:00:00',14.4,0.7609,'2021-07-29 19:57:41','2023-06-27 21:33:02',0,0,0,0,0),
(256,'XAU','USD',1878.2,1868,'2020-11-13','2020-11-13 00:00:00',10.2,0.5431,'2021-07-29 19:57:42','2023-06-27 21:33:02',0,0,0,0,0),
(257,'XAU','USD',1868,1876.2,'2020-11-12','2020-11-12 00:00:00',-8.2,-0.439,'2021-07-29 19:57:43','2023-06-27 21:33:02',0,0,0,0,0),
(258,'XAU','USD',1876.2,1874.9,'2020-11-11','2020-11-11 00:00:00',1.3,0.0693,'2021-07-29 19:57:44','2023-06-27 21:33:02',0,0,0,0,0),
(259,'XAU','USD',1874.9,1957.45,'2020-11-10','2020-11-10 00:00:00',-82.55,-4.4029,'2021-07-29 19:57:44','2023-06-27 21:33:02',0,0,0,0,0),
(260,'XAU','USD',1957.45,1947.95,'2020-11-09','2020-11-09 00:00:00',9.5,0.4853,'2021-07-29 19:57:45','2023-06-27 21:33:02',0,0,0,0,0),
(263,'XAU','USD',1947.95,1916.8,'2020-11-06','2020-11-06 00:00:00',31.15,1.5991,'2021-07-29 19:57:46','2023-06-27 21:33:02',0,0,0,0,0),
(264,'XAU','USD',1916.8,1899.85,'2020-11-05','2020-11-05 00:00:00',16.95,0.8843,'2021-07-29 19:57:47','2023-06-27 21:33:02',0,0,0,0,0),
(265,'XAU','USD',1899.85,1899.85,'2020-11-04','2020-11-04 00:00:00',0,0,'2021-07-29 19:57:48','2023-06-27 21:33:02',0,0,0,0,0),
(266,'XAU','USD',1899.85,1886.75,'2020-11-03','2020-11-03 00:00:00',13.1,0.6895,'2021-07-29 19:57:48','2023-06-27 21:33:02',0,0,0,0,0),
(267,'XAU','USD',1886.75,1875.8,'2020-11-02','2020-11-02 00:00:00',10.95,0.5804,'2021-07-29 19:57:49','2023-06-27 21:33:02',0,0,0,0,0),
(269,'XAU','USD',1799.3,1797.15,'2021-07-28','2021-07-28 00:00:00',2.15,0.1195,'2021-07-29 20:55:09','2023-06-27 21:33:02',57.8488,53.0281,50.6177,48.2074,43.3866),
(276,'XAU','USD',1819.45,1799.3,'2021-07-29','2021-07-29 00:00:00',20.15,1.1075,'2021-07-30 14:52:30','2023-06-27 21:33:02',58.4967,53.622,51.1846,48.7472,43.8725),
(290,'XAU','USD',1828.25,1819.45,'2021-07-30','2021-07-30 00:00:00',8.8,0.4813,'2021-07-31 07:00:04','2023-06-27 21:33:02',58.7796,53.8813,51.4322,48.983,44.0847),
(292,'XAU','USD',1972.25,1972.95,'2020-08-04','2020-08-04 00:00:00',-0.7,-0.0355,'2021-08-01 08:30:35','2023-06-27 21:33:02',0,0,0,0,0),
(293,'XAU','USD',1972.95,1952.2,'2020-08-03','2020-08-03 00:00:00',20.75,1.0517,'2021-08-01 08:30:36','2023-06-27 21:33:02',0,0,0,0,0),
(294,'XAU','USD',1952.2,1952.2,'2020-07-31','2020-07-31 00:00:00',0,0,'2021-08-01 08:30:36','2023-06-27 21:33:02',0,0,0,0,0),
(295,'XAU','USD',1952.2,1954.35,'2020-07-30','2020-07-30 00:00:00',-2.15,-0.1101,'2021-08-01 08:30:37','2023-06-27 21:33:02',0,0,0,0,0),
(296,'XAU','USD',1954.35,1931.65,'2020-07-29','2020-07-29 00:00:00',22.7,1.1615,'2021-08-01 08:30:38','2023-06-27 21:33:02',0,0,0,0,0),
(297,'XAU','USD',1931.65,1940.55,'2020-07-28','2020-07-28 00:00:00',-8.9,-0.4607,'2021-08-01 08:30:38','2023-06-27 21:33:02',0,0,0,0,0),
(298,'XAU','USD',1940.55,1893.85,'2020-07-27','2020-07-27 00:00:00',46.7,2.4065,'2021-08-01 08:30:39','2023-06-27 21:33:02',0,0,0,0,0),
(299,'XAU','USD',1893.85,1882.35,'2020-07-24','2020-07-24 00:00:00',11.5,0.6072,'2021-08-01 08:30:39','2023-06-27 21:33:02',0,0,0,0,0),
(300,'XAU','USD',1882.35,1851,'2020-07-23','2020-07-23 00:00:00',31.35,1.6655,'2021-08-01 08:30:40','2023-06-27 21:33:02',0,0,0,0,0),
(301,'XAU','USD',1851,1823.2,'2020-07-22','2020-07-22 00:00:00',27.8,1.5019,'2021-08-01 08:30:41','2023-06-27 21:33:02',0,0,0,0,0),
(302,'XAU','USD',1823.2,1810.3,'2020-07-21','2020-07-21 00:00:00',12.9,0.7075,'2021-08-01 08:30:41','2023-06-27 21:33:02',0,0,0,0,0),
(303,'XAU','USD',1810.3,1802.9,'2020-07-20','2020-07-20 00:00:00',7.4,0.4088,'2021-08-01 08:30:42','2023-06-27 21:33:02',0,0,0,0,0),
(304,'XAU','USD',1802.9,1804.6,'2020-07-17','2020-07-17 00:00:00',-1.7,-0.0943,'2021-08-01 08:30:42','2023-06-27 21:33:02',0,0,0,0,0),
(305,'XAU','USD',1804.6,1809.3,'2020-07-16','2020-07-16 00:00:00',-4.7,-0.2604,'2021-08-01 08:30:43','2023-06-27 21:33:02',0,0,0,0,0),
(306,'XAU','USD',1809.3,1798.2,'2020-07-15','2020-07-15 00:00:00',11.1,0.6135,'2021-08-01 08:30:44','2023-06-27 21:33:02',0,0,0,0,0),
(307,'XAU','USD',1798.2,1808.05,'2020-07-14','2020-07-14 00:00:00',-9.85,-0.5478,'2021-08-01 08:30:44','2023-06-27 21:33:02',0,0,0,0,0),
(308,'XAU','USD',1808.05,1805.75,'2020-07-13','2020-07-13 00:00:00',2.3,0.1272,'2021-08-01 08:30:45','2023-06-27 21:33:02',0,0,0,0,0),
(309,'XAU','USD',1805.75,1812.45,'2020-07-10','2020-07-10 00:00:00',-6.7,-0.371,'2021-08-01 08:30:45','2023-06-27 21:33:02',0,0,0,0,0),
(310,'XAU','USD',1812.45,1799.35,'2020-07-09','2020-07-09 00:00:00',13.1,0.7228,'2021-08-01 08:30:46','2023-06-27 21:33:02',0,0,0,0,0),
(311,'XAU','USD',1799.35,1775.5,'2020-07-08','2020-07-08 00:00:00',23.85,1.3255,'2021-08-01 08:30:46','2023-06-27 21:33:02',0,0,0,0,0),
(312,'XAU','USD',1775.5,1774.4,'2020-07-07','2020-07-07 00:00:00',1.1,0.062,'2021-08-01 08:30:47','2023-06-27 21:33:02',0,0,0,0,0),
(313,'XAU','USD',1774.4,1774.65,'2020-07-06','2020-07-06 00:00:00',-0.25,-0.0141,'2021-08-01 08:30:48','2023-06-27 21:33:02',0,0,0,0,0),
(314,'XAU','USD',1774.65,1771.85,'2020-07-03','2020-07-03 00:00:00',2.8,0.1578,'2021-08-01 08:30:48','2023-06-27 21:33:02',0,0,0,0,0),
(315,'XAU','USD',1771.85,1787.4,'2020-07-02','2020-07-02 00:00:00',-15.55,-0.8776,'2021-08-01 08:30:49','2023-06-27 21:33:02',0,0,0,0,0),
(316,'XAU','USD',1787.4,1770.7,'2020-07-01','2020-07-01 00:00:00',16.7,0.9343,'2021-08-01 08:30:49','2023-06-27 21:33:02',0,0,0,0,0),
(317,'XAU','USD',1770.7,1768.8,'2020-06-30','2020-06-30 00:00:00',1.9,0.1073,'2021-08-01 08:30:50','2023-06-27 21:33:02',0,0,0,0,0),
(318,'XAU','USD',1768.8,1762.1,'2020-06-29','2020-06-29 00:00:00',6.7,0.3788,'2021-08-01 08:30:50','2023-06-27 21:33:02',0,0,0,0,0),
(319,'XAU','USD',1762.1,1758.55,'2020-06-26','2020-06-26 00:00:00',3.55,0.2015,'2021-08-01 08:30:51','2023-06-27 21:33:02',0,0,0,0,0),
(320,'XAU','USD',1758.55,1775.7,'2020-06-25','2020-06-25 00:00:00',-17.15,-0.9752,'2021-08-01 08:30:52','2023-06-27 21:33:02',0,0,0,0,0),
(321,'XAU','USD',1775.7,1756.6,'2020-06-24','2020-06-24 00:00:00',19.1,1.0756,'2021-08-01 08:30:52','2023-06-27 21:33:02',0,0,0,0,0),
(322,'XAU','USD',1756.6,1745.45,'2020-06-23','2020-06-23 00:00:00',11.15,0.6347,'2021-08-01 08:30:53','2023-06-27 21:33:02',0,0,0,0,0),
(323,'XAU','USD',1745.45,1728.55,'2020-06-22','2020-06-22 00:00:00',16.9,0.9682,'2021-08-01 08:30:54','2023-06-27 21:33:02',0,0,0,0,0),
(324,'XAU','USD',1728.55,1732.65,'2020-06-19','2020-06-19 00:00:00',-4.1,-0.2372,'2021-08-01 08:30:54','2023-06-27 21:33:02',0,0,0,0,0),
(325,'XAU','USD',1732.65,1717.3,'2020-06-18','2020-06-18 00:00:00',15.35,0.8859,'2021-08-01 08:30:55','2023-06-27 21:33:02',0,0,0,0,0),
(326,'XAU','USD',1717.3,1728.35,'2020-06-17','2020-06-17 00:00:00',-11.05,-0.6435,'2021-08-01 08:30:55','2023-06-27 21:33:02',0,0,0,0,0),
(327,'XAU','USD',1728.35,1710.4,'2020-06-16','2020-06-16 00:00:00',17.95,1.0386,'2021-08-01 08:30:56','2023-06-27 21:33:02',0,0,0,0,0),
(328,'XAU','USD',1710.4,1735.85,'2020-06-15','2020-06-15 00:00:00',-25.45,-1.488,'2021-08-01 08:30:56','2023-06-27 21:33:02',0,0,0,0,0),
(329,'XAU','USD',1735.85,1731.9,'2020-06-12','2020-06-12 00:00:00',3.95,0.2276,'2021-08-01 08:30:57','2023-06-27 21:33:02',0,0,0,0,0),
(330,'XAU','USD',1731.9,1717.65,'2020-06-11','2020-06-11 00:00:00',14.25,0.8228,'2021-08-01 08:30:58','2023-06-27 21:33:02',0,0,0,0,0),
(331,'XAU','USD',1717.65,1707.5,'2020-06-10','2020-06-10 00:00:00',10.15,0.5909,'2021-08-01 08:30:58','2023-06-27 21:33:02',0,0,0,0,0),
(332,'XAU','USD',1707.5,1692,'2020-06-09','2020-06-09 00:00:00',15.5,0.9078,'2021-08-01 08:30:59','2023-06-27 21:33:02',0,0,0,0,0),
(333,'XAU','USD',1692,1709.55,'2020-06-08','2020-06-08 00:00:00',-17.55,-1.0372,'2021-08-01 08:30:59','2023-06-27 21:33:02',0,0,0,0,0),
(334,'XAU','USD',1709.55,1706.45,'2020-06-05','2020-06-05 00:00:00',3.1,0.1813,'2021-08-01 08:31:00','2023-06-27 21:33:02',0,0,0,0,0),
(335,'XAU','USD',1706.45,1717.6,'2020-06-04','2020-06-04 00:00:00',-11.15,-0.6534,'2021-08-01 08:31:00','2023-06-27 21:33:02',0,0,0,0,0),
(336,'XAU','USD',1717.6,1740.25,'2020-06-03','2020-06-03 00:00:00',-22.65,-1.3187,'2021-08-01 08:31:01','2023-06-27 21:33:02',0,0,0,0,0),
(337,'XAU','USD',1740.25,1734.8,'2020-06-02','2020-06-02 00:00:00',5.45,0.3132,'2021-08-01 08:31:02','2023-06-27 21:33:02',0,0,0,0,0),
(338,'XAU','USD',1734.8,1725.65,'2020-06-01','2020-06-01 00:00:00',9.15,0.5274,'2021-08-01 08:31:02','2023-06-27 21:33:02',0,0,0,0,0),
(339,'XAU','USD',1725.65,1723.3,'2020-05-29','2020-05-29 00:00:00',2.35,0.1362,'2021-08-01 08:31:03','2023-06-27 21:33:02',0,0,0,0,0),
(340,'XAU','USD',1723.3,1705.15,'2020-05-28','2020-05-28 00:00:00',18.15,1.0532,'2021-08-01 08:31:04','2023-06-27 21:33:02',0,0,0,0,0),
(341,'XAU','USD',1705.15,1722.75,'2020-05-27','2020-05-27 00:00:00',-17.6,-1.0322,'2021-08-01 08:31:04','2023-06-27 21:33:02',0,0,0,0,0),
(342,'XAU','USD',1722.75,1732.45,'2020-05-26','2020-05-26 00:00:00',-9.7,-0.5631,'2021-08-01 08:31:05','2023-06-27 21:33:02',0,0,0,0,0),
(343,'XAU','USD',1732.45,1732.45,'2020-05-25','2020-05-25 00:00:00',0,0,'2021-08-01 08:31:05','2023-06-27 21:33:02',0,0,0,0,0),
(344,'XAU','USD',1732.45,1732.8,'2020-05-22','2020-05-22 00:00:00',-0.35,-0.0202,'2021-08-01 08:31:06','2023-06-27 21:33:02',0,0,0,0,0),
(345,'XAU','USD',1732.8,1750.05,'2020-05-21','2020-05-21 00:00:00',-17.25,-0.9955,'2021-08-01 08:31:06','2023-06-27 21:33:02',0,0,0,0,0),
(346,'XAU','USD',1750.05,1735.25,'2020-05-20','2020-05-20 00:00:00',14.8,0.8457,'2021-08-01 08:31:07','2023-06-27 21:33:02',0,0,0,0,0),
(347,'XAU','USD',1735.25,1756.9,'2020-05-19','2020-05-19 00:00:00',-21.65,-1.2477,'2021-08-01 08:31:07','2023-06-27 21:33:02',0,0,0,0,0),
(348,'XAU','USD',1756.9,1734.85,'2020-05-18','2020-05-18 00:00:00',22.05,1.2551,'2021-08-01 08:31:08','2023-06-27 21:33:02',0,0,0,0,0),
(349,'XAU','USD',1734.85,1716.4,'2020-05-15','2020-05-15 00:00:00',18.45,1.0635,'2021-08-01 08:31:09','2023-06-27 21:33:02',0,0,0,0,0),
(350,'XAU','USD',1716.4,1699.85,'2020-05-14','2020-05-14 00:00:00',16.55,0.9642,'2021-08-01 08:31:09','2023-06-27 21:33:02',0,0,0,0,0),
(351,'XAU','USD',1699.85,1703.45,'2020-05-13','2020-05-13 00:00:00',-3.6,-0.2118,'2021-08-01 08:31:10','2023-06-27 21:33:02',0,0,0,0,0),
(352,'XAU','USD',1703.45,1698.8,'2020-05-12','2020-05-12 00:00:00',4.65,0.273,'2021-08-01 08:31:10','2023-06-27 21:33:02',0,0,0,0,0),
(353,'XAU','USD',1698.8,1688.65,'2020-05-11','2020-05-11 00:00:00',10.15,0.5975,'2021-08-01 08:31:11','2023-06-27 21:33:02',0,0,0,0,0),
(354,'XAU','USD',1688.65,1688.65,'2020-05-08','2020-05-08 00:00:00',0,0,'2021-08-01 08:31:11','2023-06-27 21:33:02',0,0,0,0,0),
(355,'XAU','USD',1688.65,1698.9,'2020-05-07','2020-05-07 00:00:00',-10.25,-0.607,'2021-08-01 08:31:12','2023-06-27 21:33:02',0,0,0,0,0),
(356,'XAU','USD',1698.9,1696.3,'2020-05-06','2020-05-06 00:00:00',2.6,0.153,'2021-08-01 08:31:13','2023-06-27 21:33:02',0,0,0,0,0),
(357,'XAU','USD',1875.8,1876.85,'2020-10-30','2020-10-30 00:00:00',-1.05,-0.056,'2021-08-01 08:36:32','2023-06-27 21:33:02',0,0,0,0,0),
(358,'XAU','USD',1876.85,1896.85,'2020-10-29','2020-10-29 00:00:00',-20,-1.0656,'2021-08-01 08:36:32','2023-06-27 21:33:02',0,0,0,0,0),
(359,'XAU','USD',1896.85,1898.9,'2020-10-28','2020-10-28 00:00:00',-2.05,-0.1081,'2021-08-01 08:36:33','2023-06-27 21:33:02',0,0,0,0,0),
(360,'XAU','USD',1898.9,1901.6,'2020-10-27','2020-10-27 00:00:00',-2.7,-0.1422,'2021-08-01 08:36:34','2023-06-27 21:33:02',0,0,0,0,0),
(361,'XAU','USD',1901.6,1910.6,'2020-10-26','2020-10-26 00:00:00',-9,-0.4733,'2021-08-01 08:36:34','2023-06-27 21:33:02',0,0,0,0,0),
(362,'XAU','USD',1910.6,1916.85,'2020-10-23','2020-10-23 00:00:00',-6.25,-0.3271,'2021-08-01 08:36:35','2023-06-27 21:33:02',0,0,0,0,0),
(363,'XAU','USD',1916.85,1918.95,'2020-10-22','2020-10-22 00:00:00',-2.1,-0.1096,'2021-08-01 08:36:36','2023-06-27 21:33:02',0,0,0,0,0),
(364,'XAU','USD',1918.95,1906.35,'2020-10-21','2020-10-21 00:00:00',12.6,0.6566,'2021-08-01 08:36:36','2023-06-27 21:33:02',0,0,0,0,0),
(365,'XAU','USD',1906.35,1910,'2020-10-20','2020-10-20 00:00:00',-3.65,-0.1915,'2021-08-01 08:36:37','2023-06-27 21:33:02',0,0,0,0,0),
(366,'XAU','USD',1910,1908.2,'2020-10-19','2020-10-19 00:00:00',1.8,0.0942,'2021-08-01 08:36:38','2023-06-27 21:33:02',0,0,0,0,0),
(367,'XAU','USD',1908.2,1891.7,'2020-10-16','2020-10-16 00:00:00',16.5,0.8647,'2021-08-01 08:36:38','2023-06-27 21:33:02',0,0,0,0,0),
(368,'XAU','USD',1891.7,1896.45,'2020-10-15','2020-10-15 00:00:00',-4.75,-0.2511,'2021-08-01 08:36:39','2023-06-27 21:33:02',0,0,0,0,0),
(369,'XAU','USD',1896.45,1920.8,'2020-10-14','2020-10-14 00:00:00',-24.35,-1.284,'2021-08-01 08:36:39','2023-06-27 21:33:02',0,0,0,0,0),
(370,'XAU','USD',1920.8,1919.8,'2020-10-13','2020-10-13 00:00:00',1,0.0521,'2021-08-01 08:36:40','2023-06-27 21:33:02',0,0,0,0,0),
(371,'XAU','USD',1919.8,1912.4,'2020-10-12','2020-10-12 00:00:00',7.4,0.3855,'2021-08-01 08:36:40','2023-06-27 21:33:02',0,0,0,0,0),
(372,'XAU','USD',1912.4,1891.35,'2020-10-09','2020-10-09 00:00:00',21.05,1.1007,'2021-08-01 08:36:41','2023-06-27 21:33:02',0,0,0,0,0),
(373,'XAU','USD',1891.35,1888,'2020-10-08','2020-10-08 00:00:00',3.35,0.1771,'2021-08-01 08:36:42','2023-06-27 21:33:02',0,0,0,0,0),
(374,'XAU','USD',1888,1912.5,'2020-10-07','2020-10-07 00:00:00',-24.5,-1.2977,'2021-08-01 08:36:42','2023-06-27 21:33:02',0,0,0,0,0),
(375,'XAU','USD',1912.5,1899.65,'2020-10-06','2020-10-06 00:00:00',12.85,0.6719,'2021-08-01 08:36:43','2023-06-27 21:33:02',0,0,0,0,0),
(376,'XAU','USD',1899.65,1906.4,'2020-10-05','2020-10-05 00:00:00',-6.75,-0.3553,'2021-08-01 08:36:43','2023-06-27 21:33:02',0,0,0,0,0),
(377,'XAU','USD',1906.4,1895.55,'2020-10-02','2020-10-02 00:00:00',10.85,0.5691,'2021-08-01 08:36:44','2023-06-27 21:33:02',0,0,0,0,0),
(378,'XAU','USD',1895.55,1883.4,'2020-10-01','2020-10-01 00:00:00',12.15,0.641,'2021-08-01 08:36:45','2023-06-27 21:33:02',0,0,0,0,0),
(379,'XAU','USD',1883.4,1882.4,'2020-09-30','2020-09-30 00:00:00',1,0.0531,'2021-08-01 08:36:45','2023-06-27 21:33:02',0,0,0,0,0),
(380,'XAU','USD',1882.4,1850.95,'2020-09-29','2020-09-29 00:00:00',31.45,1.6707,'2021-08-01 08:36:46','2023-06-27 21:33:02',0,0,0,0,0),
(381,'XAU','USD',1850.95,1870.05,'2020-09-28','2020-09-28 00:00:00',-19.1,-1.0319,'2021-08-01 08:36:46','2023-06-27 21:33:02',0,0,0,0,0),
(382,'XAU','USD',1870.05,1850.75,'2020-09-25','2020-09-25 00:00:00',19.3,1.0321,'2021-08-01 08:36:47','2023-06-27 21:33:02',0,0,0,0,0),
(383,'XAU','USD',1850.75,1888.1,'2020-09-24','2020-09-24 00:00:00',-37.35,-2.0181,'2021-08-01 08:36:47','2023-06-27 21:33:02',0,0,0,0,0),
(384,'XAU','USD',1888.1,1903.1,'2020-09-23','2020-09-23 00:00:00',-15,-0.7944,'2021-08-01 08:36:48','2023-06-27 21:33:02',0,0,0,0,0),
(385,'XAU','USD',1903.1,1930.9,'2020-09-22','2020-09-22 00:00:00',-27.8,-1.4608,'2021-08-01 08:36:49','2023-06-27 21:33:02',0,0,0,0,0),
(386,'XAU','USD',1930.9,1954.75,'2020-09-21','2020-09-21 00:00:00',-23.85,-1.2352,'2021-08-01 08:36:49','2023-06-27 21:33:02',0,0,0,0,0),
(387,'XAU','USD',1954.75,1936.1,'2020-09-18','2020-09-18 00:00:00',18.65,0.9541,'2021-08-01 08:36:50','2023-06-27 21:33:02',0,0,0,0,0),
(388,'XAU','USD',1936.1,1964.8,'2020-09-17','2020-09-17 00:00:00',-28.7,-1.4824,'2021-08-01 08:36:50','2023-06-27 21:33:02',0,0,0,0,0),
(389,'XAU','USD',1964.8,1963.55,'2020-09-16','2020-09-16 00:00:00',1.25,0.0636,'2021-08-01 08:36:51','2023-06-27 21:33:02',0,0,0,0,0),
(390,'XAU','USD',1963.55,1942.3,'2020-09-15','2020-09-15 00:00:00',21.25,1.0822,'2021-08-01 08:36:51','2023-06-27 21:33:02',0,0,0,0,0),
(391,'XAU','USD',1942.3,1944.5,'2020-09-14','2020-09-14 00:00:00',-2.2,-0.1133,'2021-08-01 08:36:52','2023-06-27 21:33:02',0,0,0,0,0),
(392,'XAU','USD',1944.5,1944.8,'2020-09-11','2020-09-11 00:00:00',-0.3,-0.0154,'2021-08-01 08:36:53','2023-06-27 21:33:02',0,0,0,0,0),
(393,'XAU','USD',1944.8,1928.4,'2020-09-10','2020-09-10 00:00:00',16.4,0.8433,'2021-08-01 08:36:53','2023-06-27 21:33:02',0,0,0,0,0),
(394,'XAU','USD',1928.4,1920.6,'2020-09-09','2020-09-09 00:00:00',7.8,0.4045,'2021-08-01 08:36:54','2023-06-27 21:33:02',0,0,0,0,0),
(395,'XAU','USD',1920.6,1928.4,'2020-09-08','2020-09-08 00:00:00',-7.8,-0.4061,'2021-08-01 08:36:54','2023-06-27 21:33:02',0,0,0,0,0),
(396,'XAU','USD',1928.4,1937.6,'2020-09-07','2020-09-07 00:00:00',-9.2,-0.4771,'2021-08-01 08:36:55','2023-06-27 21:33:02',0,0,0,0,0),
(397,'XAU','USD',1937.6,1934.1,'2020-09-04','2020-09-04 00:00:00',3.5,0.1806,'2021-08-01 08:36:55','2023-06-27 21:33:02',0,0,0,0,0),
(398,'XAU','USD',1934.1,1969,'2020-09-03','2020-09-03 00:00:00',-34.9,-1.8045,'2021-08-01 08:36:56','2023-06-27 21:33:02',0,0,0,0,0),
(399,'XAU','USD',1969,1987.95,'2020-09-02','2020-09-02 00:00:00',-18.95,-0.9624,'2021-08-01 08:36:57','2023-06-27 21:33:02',0,0,0,0,0),
(400,'XAU','USD',1987.95,1955.85,'2020-09-01','2020-09-01 00:00:00',32.1,1.6147,'2021-08-01 08:36:57','2023-06-27 21:33:02',0,0,0,0,0),
(401,'XAU','USD',1955.85,1955.85,'2020-08-31','2020-08-31 00:00:00',0,0,'2021-08-01 08:36:58','2023-06-27 21:33:02',0,0,0,0,0),
(402,'XAU','USD',1955.85,1938.8,'2020-08-28','2020-08-28 00:00:00',17.05,0.8717,'2021-08-01 08:36:58','2023-06-27 21:33:02',0,0,0,0,0),
(403,'XAU','USD',1938.8,1918.5,'2020-08-27','2020-08-27 00:00:00',20.3,1.047,'2021-08-01 08:36:59','2023-06-27 21:33:02',0,0,0,0,0),
(404,'XAU','USD',1918.5,1925.45,'2020-08-26','2020-08-26 00:00:00',-6.95,-0.3623,'2021-08-01 08:37:00','2023-06-27 21:33:02',0,0,0,0,0),
(405,'XAU','USD',1925.45,1947.55,'2020-08-25','2020-08-25 00:00:00',-22.1,-1.1478,'2021-08-01 08:37:00','2023-06-27 21:33:02',0,0,0,0,0),
(406,'XAU','USD',1947.55,1932.85,'2020-08-24','2020-08-24 00:00:00',14.7,0.7548,'2021-08-01 08:37:01','2023-06-27 21:33:02',0,0,0,0,0),
(407,'XAU','USD',1932.85,1928.05,'2020-08-21','2020-08-21 00:00:00',4.8,0.2483,'2021-08-01 08:37:01','2023-06-27 21:33:02',0,0,0,0,0),
(408,'XAU','USD',1928.05,1993.15,'2020-08-20','2020-08-20 00:00:00',-65.1,-3.3765,'2021-08-01 08:37:02','2023-06-27 21:33:02',0,0,0,0,0),
(409,'XAU','USD',1993.15,2005.15,'2020-08-19','2020-08-19 00:00:00',-12,-0.6021,'2021-08-01 08:37:02','2023-06-27 21:33:02',0,0,0,0,0),
(410,'XAU','USD',2005.15,1949.85,'2020-08-18','2020-08-18 00:00:00',55.3,2.7579,'2021-08-01 08:37:03','2023-06-27 21:33:02',0,0,0,0,0),
(411,'XAU','USD',1949.85,1948.3,'2020-08-17','2020-08-17 00:00:00',1.55,0.0795,'2021-08-01 08:37:04','2023-06-27 21:33:02',0,0,0,0,0),
(412,'XAU','USD',1948.3,2030.3,'2020-08-14','2020-08-14 00:00:00',-82,-4.2088,'2021-08-01 08:37:04','2023-06-27 21:33:02',0,0,0,0,0),
(413,'XAU','USD',2030.3,2030.3,'2020-08-13','2020-08-13 00:00:00',0,0,'2021-08-01 08:37:05','2023-06-27 21:33:02',0,0,0,0,0),
(414,'XAU','USD',2030.3,2030.3,'2020-08-12','2020-08-12 00:00:00',0,0,'2021-08-01 08:37:05','2023-06-27 21:33:02',0,0,0,0,0),
(415,'XAU','USD',2030.3,2030.3,'2020-08-11','2020-08-11 00:00:00',0,0,'2021-08-01 08:37:06','2023-06-27 21:33:02',0,0,0,0,0),
(416,'XAU','USD',2030.3,2061.5,'2020-08-10','2020-08-10 00:00:00',-31.2,-1.5367,'2021-08-01 08:37:07','2023-06-27 21:33:02',0,0,0,0,0),
(417,'XAU','USD',2061.5,2049.15,'2020-08-07','2020-08-07 00:00:00',12.35,0.5991,'2021-08-01 08:37:07','2023-06-27 21:33:02',0,0,0,0,0),
(418,'XAU','USD',2049.15,2034.45,'2020-08-06','2020-08-06 00:00:00',14.7,0.7174,'2021-08-01 08:37:08','2023-06-27 21:33:02',0,0,0,0,0),
(419,'XAU','USD',2034.45,1972.25,'2020-08-05','2020-08-05 00:00:00',62.2,3.0573,'2021-08-01 08:37:08','2023-06-27 21:33:02',0,0,0,0,0),
(420,'XAU','USD',1696.3,1703.7,'2020-05-05','2020-05-05 00:00:00',-7.4,-0.4362,'2021-08-01 08:42:00','2023-06-27 21:33:02',0,0,0,0,0),
(421,'XAU','USD',1703.7,1673.05,'2020-05-04','2020-05-04 00:00:00',30.65,1.799,'2021-08-01 08:42:01','2023-06-27 21:33:02',0,0,0,0,0),
(422,'XAU','USD',1673.05,1716.75,'2020-05-01','2020-05-01 00:00:00',-43.7,-2.612,'2021-08-01 08:42:02','2023-06-27 21:33:02',0,0,0,0,0),
(423,'XAU','USD',1716.75,1706,'2020-04-30','2020-04-30 00:00:00',10.75,0.6262,'2021-08-01 08:42:02','2023-06-27 21:33:02',0,0,0,0,0),
(424,'XAU','USD',1706,1708.1,'2020-04-29','2020-04-29 00:00:00',-2.1,-0.1231,'2021-08-01 08:42:03','2023-06-27 21:33:02',0,0,0,0,0),
(425,'XAU','USD',1708.1,1717.25,'2020-04-28','2020-04-28 00:00:00',-9.15,-0.5357,'2021-08-01 08:42:03','2023-06-27 21:33:02',0,0,0,0,0),
(426,'XAU','USD',1717.25,1727.25,'2020-04-27','2020-04-27 00:00:00',-10,-0.5823,'2021-08-01 08:42:04','2023-06-27 21:33:02',0,0,0,0,0),
(427,'XAU','USD',1727.25,1727.55,'2020-04-24','2020-04-24 00:00:00',-0.3,-0.0174,'2021-08-01 08:42:05','2023-06-27 21:33:02',0,0,0,0,0),
(428,'XAU','USD',1727.55,1702.65,'2020-04-23','2020-04-23 00:00:00',24.9,1.4413,'2021-08-01 08:42:05','2023-06-27 21:33:02',0,0,0,0,0),
(429,'XAU','USD',1702.65,1678.6,'2020-04-22','2020-04-22 00:00:00',24.05,1.4125,'2021-08-01 08:42:06','2023-06-27 21:33:02',0,0,0,0,0),
(430,'XAU','USD',1678.6,1684.95,'2020-04-21','2020-04-21 00:00:00',-6.35,-0.3783,'2021-08-01 08:42:07','2023-06-27 21:33:02',0,0,0,0,0),
(431,'XAU','USD',1684.95,1693.15,'2020-04-20','2020-04-20 00:00:00',-8.2,-0.4867,'2021-08-01 08:42:07','2023-06-27 21:33:02',0,0,0,0,0),
(432,'XAU','USD',1693.15,1717.85,'2020-04-17','2020-04-17 00:00:00',-24.7,-1.4588,'2021-08-01 08:42:08','2023-06-27 21:33:02',0,0,0,0,0),
(433,'XAU','USD',1717.85,1712.25,'2020-04-16','2020-04-16 00:00:00',5.6,0.326,'2021-08-01 08:42:08','2023-06-27 21:33:02',0,0,0,0,0),
(434,'XAU','USD',1712.25,1715.85,'2020-04-15','2020-04-15 00:00:00',-3.6,-0.2102,'2021-08-01 08:42:09','2023-06-27 21:33:02',0,0,0,0,0),
(435,'XAU','USD',1715.85,1662.5,'2020-04-14','2020-04-14 00:00:00',53.35,3.1092,'2021-08-01 08:42:09','2023-06-27 21:33:02',0,0,0,0,0),
(436,'XAU','USD',1662.5,1662.5,'2020-04-13','2020-04-13 00:00:00',0,0,'2021-08-01 08:42:10','2023-06-27 21:33:02',0,0,0,0,0),
(437,'XAU','USD',1662.5,1662.5,'2020-04-10','2020-04-10 00:00:00',0,0,'2021-08-01 08:42:11','2023-06-27 21:33:02',0,0,0,0,0),
(438,'XAU','USD',1662.5,1649.05,'2020-04-09','2020-04-09 00:00:00',13.45,0.809,'2021-08-01 08:42:11','2023-06-27 21:33:02',0,0,0,0,0),
(439,'XAU','USD',1649.05,1652.2,'2020-04-08','2020-04-08 00:00:00',-3.15,-0.191,'2021-08-01 08:42:12','2023-06-27 21:33:02',0,0,0,0,0),
(440,'XAU','USD',1652.2,1636.6,'2020-04-07','2020-04-07 00:00:00',15.6,0.9442,'2021-08-01 08:42:12','2023-06-27 21:33:02',0,0,0,0,0),
(441,'XAU','USD',1636.6,1609.75,'2020-04-06','2020-04-06 00:00:00',26.85,1.6406,'2021-08-01 08:42:13','2023-06-27 21:33:02',0,0,0,0,0),
(442,'XAU','USD',1609.75,1588.05,'2020-04-03','2020-04-03 00:00:00',21.7,1.348,'2021-08-01 08:42:14','2023-06-27 21:33:02',0,0,0,0,0),
(443,'XAU','USD',1588.05,1594.25,'2020-04-02','2020-04-02 00:00:00',-6.2,-0.3904,'2021-08-01 08:42:14','2023-06-27 21:33:02',0,0,0,0,0),
(444,'XAU','USD',1594.25,1604.65,'2020-04-01','2020-04-01 00:00:00',-10.4,-0.6523,'2021-08-01 08:42:15','2023-06-27 21:33:02',0,0,0,0,0),
(445,'XAU','USD',1604.65,1624.45,'2020-03-31','2020-03-31 00:00:00',-19.8,-1.2339,'2021-08-01 08:42:16','2023-06-27 21:33:02',0,0,0,0,0),
(446,'XAU','USD',1624.45,1621.2,'2020-03-30','2020-03-30 00:00:00',3.25,0.2001,'2021-08-01 08:42:16','2023-06-27 21:33:02',0,0,0,0,0),
(447,'XAU','USD',1621.2,1620.1,'2020-03-27','2020-03-27 00:00:00',1.1,0.0679,'2021-08-01 08:42:17','2023-06-27 21:33:02',0,0,0,0,0),
(448,'XAU','USD',1620.1,1620.95,'2020-03-26','2020-03-26 00:00:00',-0.85,-0.0525,'2021-08-01 08:42:17','2023-06-27 21:33:02',0,0,0,0,0),
(449,'XAU','USD',1620.95,1599.5,'2020-03-25','2020-03-25 00:00:00',21.45,1.3233,'2021-08-01 08:42:18','2023-06-27 21:33:02',0,0,0,0,0),
(450,'XAU','USD',1599.5,1494.5,'2020-03-24','2020-03-24 00:00:00',105,6.5646,'2021-08-01 08:42:18','2023-06-27 21:33:02',0,0,0,0,0),
(451,'XAU','USD',1494.5,1504.45,'2020-03-23','2020-03-23 00:00:00',-9.95,-0.6658,'2021-08-01 08:42:19','2023-06-27 21:33:02',0,0,0,0,0),
(452,'XAU','USD',1504.45,1480.7,'2020-03-20','2020-03-20 00:00:00',23.75,1.5787,'2021-08-01 08:42:20','2023-06-27 21:33:02',0,0,0,0,0),
(453,'XAU','USD',1480.7,1506,'2020-03-19','2020-03-19 00:00:00',-25.3,-1.7087,'2021-08-01 08:42:20','2023-06-27 21:33:02',0,0,0,0,0),
(454,'XAU','USD',1506,1472.35,'2020-03-18','2020-03-18 00:00:00',33.65,2.2344,'2021-08-01 08:42:21','2023-06-27 21:33:02',0,0,0,0,0),
(455,'XAU','USD',1472.35,1504.65,'2020-03-17','2020-03-17 00:00:00',-32.3,-2.1938,'2021-08-01 08:42:21','2023-06-27 21:33:02',0,0,0,0,0),
(456,'XAU','USD',1504.65,1588.15,'2020-03-16','2020-03-16 00:00:00',-83.5,-5.5495,'2021-08-01 08:42:22','2023-06-27 21:33:02',0,0,0,0,0),
(457,'XAU','USD',1588.15,1636.65,'2020-03-13','2020-03-13 00:00:00',-48.5,-3.0539,'2021-08-01 08:42:22','2023-06-27 21:33:02',0,0,0,0,0),
(458,'XAU','USD',1636.65,1662.5,'2020-03-12','2020-03-12 00:00:00',-25.85,-1.5794,'2021-08-01 08:42:23','2023-06-27 21:33:02',0,0,0,0,0),
(459,'XAU','USD',1662.5,1657.4,'2020-03-11','2020-03-11 00:00:00',5.1,0.3068,'2021-08-01 08:42:24','2023-06-27 21:33:02',0,0,0,0,0),
(460,'XAU','USD',1657.4,1676.6,'2020-03-10','2020-03-10 00:00:00',-19.2,-1.1584,'2021-08-01 08:42:24','2023-06-27 21:33:02',0,0,0,0,0),
(461,'XAU','USD',1676.6,1687,'2020-03-09','2020-03-09 00:00:00',-10.4,-0.6203,'2021-08-01 08:42:25','2023-06-27 21:33:02',0,0,0,0,0),
(462,'XAU','USD',1687,1647.45,'2020-03-06','2020-03-06 00:00:00',39.55,2.3444,'2021-08-01 08:42:25','2023-06-27 21:33:02',0,0,0,0,0),
(463,'XAU','USD',1647.45,1644.8,'2020-03-05','2020-03-05 00:00:00',2.65,0.1609,'2021-08-01 08:42:26','2023-06-27 21:33:02',0,0,0,0,0),
(464,'XAU','USD',1644.8,1599.05,'2020-03-04','2020-03-04 00:00:00',45.75,2.7815,'2021-08-01 08:42:27','2023-06-27 21:33:02',0,0,0,0,0),
(465,'XAU','USD',1599.05,1609.7,'2020-03-03','2020-03-03 00:00:00',-10.65,-0.666,'2021-08-01 08:42:27','2023-06-27 21:33:02',0,0,0,0,0),
(466,'XAU','USD',1609.7,1626.35,'2020-03-02','2020-03-02 00:00:00',-16.65,-1.0344,'2021-08-01 08:42:28','2023-06-27 21:33:02',0,0,0,0,0),
(467,'XAU','USD',1626.35,1646.6,'2020-02-28','2020-02-28 00:00:00',-20.25,-1.2451,'2021-08-01 08:42:28','2023-06-27 21:33:02',0,0,0,0,0),
(468,'XAU','USD',1646.6,1647.95,'2020-02-27','2020-02-27 00:00:00',-1.35,-0.082,'2021-08-01 08:42:29','2023-06-27 21:33:02',0,0,0,0,0),
(469,'XAU','USD',1647.95,1655.9,'2020-02-26','2020-02-26 00:00:00',-7.95,-0.4824,'2021-08-01 08:42:30','2023-06-27 21:33:02',0,0,0,0,0),
(470,'XAU','USD',1655.9,1682.35,'2020-02-25','2020-02-25 00:00:00',-26.45,-1.5973,'2021-08-01 08:42:30','2023-06-27 21:33:02',0,0,0,0,0),
(471,'XAU','USD',1682.35,1633.7,'2020-02-24','2020-02-24 00:00:00',48.65,2.8918,'2021-08-01 08:42:31','2023-06-27 21:33:02',0,0,0,0,0),
(472,'XAU','USD',1633.7,1610.35,'2020-02-21','2020-02-21 00:00:00',23.35,1.4293,'2021-08-01 08:42:31','2023-06-27 21:33:02',0,0,0,0,0),
(473,'XAU','USD',1610.35,1609.5,'2020-02-20','2020-02-20 00:00:00',0.85,0.0528,'2021-08-01 08:42:32','2023-06-27 21:33:02',0,0,0,0,0),
(474,'XAU','USD',1609.5,1588.2,'2020-02-19','2020-02-19 00:00:00',21.3,1.3234,'2021-08-01 08:42:32','2023-06-27 21:33:02',0,0,0,0,0),
(475,'XAU','USD',1588.2,1580.3,'2020-02-18','2020-02-18 00:00:00',7.9,0.4974,'2021-08-01 08:42:33','2023-06-27 21:33:02',0,0,0,0,0),
(476,'XAU','USD',1580.3,1576.35,'2020-02-17','2020-02-17 00:00:00',3.95,0.25,'2021-08-01 08:42:33','2023-06-27 21:33:02',0,0,0,0,0),
(477,'XAU','USD',1576.35,1575,'2020-02-14','2020-02-14 00:00:00',1.35,0.0856,'2021-08-01 08:42:34','2023-06-27 21:33:02',0,0,0,0,0),
(478,'XAU','USD',1575,1566.75,'2020-02-13','2020-02-13 00:00:00',8.25,0.5238,'2021-08-01 08:42:35','2023-06-27 21:33:02',0,0,0,0,0),
(479,'XAU','USD',1566.75,1567.7,'2020-02-12','2020-02-12 00:00:00',-0.95,-0.0606,'2021-08-01 08:42:35','2023-06-27 21:33:02',0,0,0,0,0),
(480,'XAU','USD',1567.7,1574.05,'2020-02-11','2020-02-11 00:00:00',-6.35,-0.4051,'2021-08-01 08:42:36','2023-06-27 21:33:02',0,0,0,0,0),
(481,'XAU','USD',1574.05,1568.3,'2020-02-10','2020-02-10 00:00:00',5.75,0.3653,'2021-08-01 08:42:37','2023-06-27 21:33:02',0,0,0,0,0),
(482,'XAU','USD',1568.3,1564.75,'2020-02-07','2020-02-07 00:00:00',3.55,0.2264,'2021-08-01 08:42:37','2023-06-27 21:33:02',0,0,0,0,0),
(483,'XAU','USD',1564.75,1552.2,'2020-02-06','2020-02-06 00:00:00',12.55,0.802,'2021-08-01 08:42:38','2023-06-27 21:33:02',0,0,0,0,0),
(484,'XAU','USD',1552.2,1571.2,'2020-02-05','2020-02-05 00:00:00',-19,-1.2241,'2021-08-01 08:42:38','2023-06-27 21:33:02',0,0,0,0,0),
(485,'XAU','USD',1571.2,1578.85,'2020-02-04','2020-02-04 00:00:00',-7.65,-0.4869,'2021-08-01 08:42:39','2023-06-27 21:33:02',0,0,0,0,0),
(486,'XAU','USD',1578.85,1580.85,'2020-02-03','2020-02-03 00:00:00',-2,-0.1267,'2021-08-01 08:42:40','2023-06-27 21:33:02',0,0,0,0,0),
(487,'XAU','USD',1580.85,1580.4,'2020-01-31','2020-01-31 00:00:00',0.45,0.0285,'2021-08-01 08:42:40','2023-06-27 21:33:02',0,0,0,0,0),
(488,'XAU','USD',1580.4,1571.2,'2020-01-30','2020-01-30 00:00:00',9.2,0.5821,'2021-08-01 08:42:41','2023-06-27 21:33:02',0,0,0,0,0),
(489,'XAU','USD',1571.2,1579.6,'2020-01-29','2020-01-29 00:00:00',-8.4,-0.5346,'2021-08-01 08:42:41','2023-06-27 21:33:02',0,0,0,0,0),
(490,'XAU','USD',1579.6,1583.45,'2020-01-28','2020-01-28 00:00:00',-3.85,-0.2437,'2021-08-01 08:42:42','2023-06-27 21:33:02',0,0,0,0,0),
(491,'XAU','USD',1583.45,1561.85,'2020-01-27','2020-01-27 00:00:00',21.6,1.3641,'2021-08-01 08:42:42','2023-06-27 21:33:02',0,0,0,0,0),
(492,'XAU','USD',1561.85,1554.05,'2020-01-24','2020-01-24 00:00:00',7.8,0.4994,'2021-08-01 08:42:43','2023-06-27 21:33:02',0,0,0,0,0),
(493,'XAU','USD',1554.05,1558.1,'2020-01-23','2020-01-23 00:00:00',-4.05,-0.2606,'2021-08-01 08:42:43','2023-06-27 21:33:02',0,0,0,0,0),
(494,'XAU','USD',1558.1,1556.25,'2020-01-22','2020-01-22 00:00:00',1.85,0.1187,'2021-08-01 08:42:44','2023-06-27 21:33:02',0,0,0,0,0),
(495,'XAU','USD',1556.25,1559.25,'2020-01-21','2020-01-21 00:00:00',-3,-0.1928,'2021-08-01 08:42:45','2023-06-27 21:33:02',0,0,0,0,0),
(496,'XAU','USD',1559.25,1556.5,'2020-01-20','2020-01-20 00:00:00',2.75,0.1764,'2021-08-01 08:42:45','2023-06-27 21:33:02',0,0,0,0,0),
(497,'XAU','USD',1556.5,1555.2,'2020-01-17','2020-01-17 00:00:00',1.3,0.0835,'2021-08-01 08:42:46','2023-06-27 21:33:02',0,0,0,0,0),
(498,'XAU','USD',1555.2,1551.9,'2020-01-16','2020-01-16 00:00:00',3.3,0.2122,'2021-08-01 08:42:46','2023-06-27 21:33:02',0,0,0,0,0),
(499,'XAU','USD',1551.9,1544.95,'2020-01-15','2020-01-15 00:00:00',6.95,0.4478,'2021-08-01 08:42:47','2023-06-27 21:33:02',0,0,0,0,0),
(500,'XAU','USD',1544.95,1550.35,'2020-01-14','2020-01-14 00:00:00',-5.4,-0.3495,'2021-08-01 08:42:47','2023-06-27 21:33:02',0,0,0,0,0),
(501,'XAU','USD',1550.35,1548.8,'2020-01-13','2020-01-13 00:00:00',1.55,0.1,'2021-08-01 08:42:48','2023-06-27 21:33:02',0,0,0,0,0),
(502,'XAU','USD',1548.8,1547.85,'2020-01-10','2020-01-10 00:00:00',0.95,0.0613,'2021-08-01 08:42:49','2023-06-27 21:33:02',0,0,0,0,0),
(503,'XAU','USD',1547.85,1582.85,'2020-01-09','2020-01-09 00:00:00',-35,-2.2612,'2021-08-01 08:42:49','2023-06-27 21:33:02',0,0,0,0,0),
(504,'XAU','USD',1582.85,1566.5,'2020-01-08','2020-01-08 00:00:00',16.35,1.0329,'2021-08-01 08:42:50','2023-06-27 21:33:02',0,0,0,0,0),
(505,'XAU','USD',1566.5,1576.85,'2020-01-07','2020-01-07 00:00:00',-10.35,-0.6607,'2021-08-01 08:42:50','2023-06-27 21:33:02',0,0,0,0,0),
(506,'XAU','USD',1576.85,1547.4,'2020-01-06','2020-01-06 00:00:00',29.45,1.8676,'2021-08-01 08:42:51','2023-06-27 21:33:02',0,0,0,0,0),
(507,'XAU','USD',1547.4,1520.55,'2020-01-03','2020-01-03 00:00:00',26.85,1.7352,'2021-08-01 08:42:51','2023-06-27 21:33:02',0,0,0,0,0),
(508,'XAU','USD',1520.55,1523,'2020-01-02','2020-01-02 00:00:00',-2.45,-0.1611,'2021-08-01 08:42:52','2023-06-27 21:33:02',0,0,0,0,0),
(509,'XAU','USD',1523,1523,'2020-01-01','2020-01-01 00:00:00',0,0,'2021-08-01 08:42:52','2023-06-27 21:33:02',0,0,0,0,0),
(510,'XAU','USD',1523,1511.5,'2019-12-31','2019-12-31 00:00:00',11.5,0.7551,'2021-08-01 08:42:53','2023-06-27 21:33:02',0,0,0,0,0),
(511,'XAU','USD',1511.5,1510.6,'2019-12-30','2019-12-30 00:00:00',0.9,0.0595,'2021-08-01 08:42:54','2023-06-27 21:33:02',0,0,0,0,0),
(512,'XAU','USD',1510.6,1490.85,'2019-12-27','2019-12-27 00:00:00',19.75,1.3074,'2021-08-01 08:42:54','2023-06-27 21:33:02',0,0,0,0,0),
(513,'XAU','USD',1490.85,1490.85,'2019-12-26','2019-12-26 00:00:00',0,0,'2021-08-01 08:42:55','2023-06-27 21:33:02',0,0,0,0,0),
(514,'XAU','USD',1490.85,1490.85,'2019-12-25','2019-12-25 00:00:00',0,0,'2021-08-01 08:42:56','2023-06-27 21:33:02',0,0,0,0,0),
(515,'XAU','USD',1490.85,1483.95,'2019-12-24','2019-12-24 00:00:00',6.9,0.4628,'2021-08-01 08:42:56','2023-06-27 21:33:02',0,0,0,0,0),
(516,'XAU','USD',1483.95,1476.9,'2019-12-23','2019-12-23 00:00:00',7.05,0.4751,'2021-08-01 08:42:57','2023-06-27 21:33:02',0,0,0,0,0),
(517,'XAU','USD',1476.9,1474.4,'2019-12-20','2019-12-20 00:00:00',2.5,0.1693,'2021-08-01 08:42:57','2023-06-27 21:33:02',0,0,0,0,0),
(518,'XAU','USD',1474.4,1478.9,'2019-12-19','2019-12-19 00:00:00',-4.5,-0.3052,'2021-08-01 08:42:58','2023-06-27 21:33:02',0,0,0,0,0),
(519,'XAU','USD',1478.9,1478.4,'2019-12-18','2019-12-18 00:00:00',0.5,0.0338,'2021-08-01 08:42:58','2023-06-27 21:33:02',0,0,0,0,0),
(520,'XAU','USD',1478.4,1477.4,'2019-12-17','2019-12-17 00:00:00',1,0.0676,'2021-08-01 08:42:59','2023-06-27 21:33:02',0,0,0,0,0),
(521,'XAU','USD',1477.4,1470.6,'2019-12-16','2019-12-16 00:00:00',6.8,0.4603,'2021-08-01 08:43:00','2023-06-27 21:33:02',0,0,0,0,0),
(522,'XAU','USD',1470.6,1474.7,'2019-12-13','2019-12-13 00:00:00',-4.1,-0.2788,'2021-08-01 08:43:00','2023-06-27 21:33:02',0,0,0,0,0),
(523,'XAU','USD',1474.7,1468.05,'2019-12-12','2019-12-12 00:00:00',6.65,0.4509,'2021-08-01 08:43:01','2023-06-27 21:33:02',0,0,0,0,0),
(524,'XAU','USD',1468.05,1464.45,'2019-12-11','2019-12-11 00:00:00',3.6,0.2452,'2021-08-01 08:43:01','2023-06-27 21:33:02',0,0,0,0,0),
(525,'XAU','USD',1464.45,1463.6,'2019-12-10','2019-12-10 00:00:00',0.85,0.058,'2021-08-01 08:43:02','2023-06-27 21:33:02',0,0,0,0,0),
(526,'XAU','USD',1463.6,1474.85,'2019-12-09','2019-12-09 00:00:00',-11.25,-0.7687,'2021-08-01 08:43:03','2023-06-27 21:33:02',0,0,0,0,0),
(527,'XAU','USD',1474.85,1474.6,'2019-12-06','2019-12-06 00:00:00',0.25,0.017,'2021-08-01 08:43:03','2023-06-27 21:33:02',0,0,0,0,0),
(528,'XAU','USD',1474.6,1475.85,'2019-12-05','2019-12-05 00:00:00',-1.25,-0.0848,'2021-08-01 08:43:04','2023-06-27 21:33:02',0,0,0,0,0),
(529,'XAU','USD',1475.85,1470.4,'2019-12-04','2019-12-04 00:00:00',5.45,0.3693,'2021-08-01 08:43:05','2023-06-27 21:33:02',0,0,0,0,0),
(530,'XAU','USD',1470.4,1457.5,'2019-12-03','2019-12-03 00:00:00',12.9,0.8773,'2021-08-01 08:43:05','2023-06-27 21:33:02',0,0,0,0,0),
(531,'XAU','USD',1457.5,1456.35,'2019-12-02','2019-12-02 00:00:00',1.15,0.0789,'2021-08-01 08:43:06','2023-06-27 21:33:02',0,0,0,0,0),
(532,'XAU','USD',1456.35,1457.55,'2019-11-29','2019-11-29 00:00:00',-1.2,-0.0824,'2021-08-01 08:43:06','2023-06-27 21:33:02',0,0,0,0,0),
(533,'XAU','USD',1457.55,1459.8,'2019-11-28','2019-11-28 00:00:00',-2.25,-0.1544,'2021-08-01 08:43:07','2023-06-27 21:33:02',0,0,0,0,0),
(534,'XAU','USD',1459.8,1457.65,'2019-11-27','2019-11-27 00:00:00',2.15,0.1473,'2021-08-01 08:43:08','2023-06-27 21:33:02',0,0,0,0,0),
(535,'XAU','USD',1457.65,1459.45,'2019-11-26','2019-11-26 00:00:00',-1.8,-0.1235,'2021-08-01 08:43:08','2023-06-27 21:33:02',0,0,0,0,0),
(536,'XAU','USD',1459.45,1471.3,'2019-11-25','2019-11-25 00:00:00',-11.85,-0.8119,'2021-08-01 08:43:09','2023-06-27 21:33:02',0,0,0,0,0),
(537,'XAU','USD',1471.3,1468.9,'2019-11-22','2019-11-22 00:00:00',2.4,0.1631,'2021-08-01 08:43:09','2023-06-27 21:33:02',0,0,0,0,0),
(538,'XAU','USD',1468.9,1475.7,'2019-11-21','2019-11-21 00:00:00',-6.8,-0.4629,'2021-08-01 08:43:10','2023-06-27 21:33:02',0,0,0,0,0),
(539,'XAU','USD',1475.7,1464.9,'2019-11-20','2019-11-20 00:00:00',10.8,0.7319,'2021-08-01 08:43:11','2023-06-27 21:33:02',0,0,0,0,0),
(540,'XAU','USD',1464.9,1458.4,'2019-11-19','2019-11-19 00:00:00',6.5,0.4437,'2021-08-01 08:43:11','2023-06-27 21:33:02',0,0,0,0,0),
(541,'XAU','USD',1458.4,1465.6,'2019-11-18','2019-11-18 00:00:00',-7.2,-0.4937,'2021-08-01 08:43:12','2023-06-27 21:33:02',0,0,0,0,0),
(542,'XAU','USD',1465.6,1467.65,'2019-11-15','2019-11-15 00:00:00',-2.05,-0.1399,'2021-08-01 08:43:12','2023-06-27 21:33:02',0,0,0,0,0),
(543,'XAU','USD',1467.65,1463.45,'2019-11-14','2019-11-14 00:00:00',4.2,0.2862,'2021-08-01 08:43:13','2023-06-27 21:33:02',0,0,0,0,0),
(544,'XAU','USD',1463.45,1455,'2019-11-13','2019-11-13 00:00:00',8.45,0.5774,'2021-08-01 08:43:14','2023-06-27 21:33:02',0,0,0,0,0),
(545,'XAU','USD',1455,1465.5,'2019-11-12','2019-11-12 00:00:00',-10.5,-0.7216,'2021-08-01 08:43:14','2023-06-27 21:33:02',0,0,0,0,0),
(546,'XAU','USD',1465.5,1466.85,'2019-11-11','2019-11-11 00:00:00',-1.35,-0.0921,'2021-08-01 08:43:15','2023-06-27 21:33:02',0,0,0,0,0),
(547,'XAU','USD',1466.85,1484.1,'2019-11-08','2019-11-08 00:00:00',-17.25,-1.176,'2021-08-01 08:43:15','2023-06-27 21:33:02',0,0,0,0,0),
(548,'XAU','USD',1484.1,1488.55,'2019-11-07','2019-11-07 00:00:00',-4.45,-0.2998,'2021-08-01 08:43:16','2023-06-27 21:33:02',0,0,0,0,0),
(549,'XAU','USD',1488.55,1504.6,'2019-11-06','2019-11-06 00:00:00',-16.05,-1.0782,'2021-08-01 08:43:16','2023-06-27 21:33:02',0,0,0,0,0),
(550,'XAU','USD',1504.6,1509.2,'2019-11-05','2019-11-05 00:00:00',-4.6,-0.3057,'2021-08-01 08:43:17','2023-06-27 21:33:02',0,0,0,0,0),
(551,'XAU','USD',1509.2,1509.85,'2019-11-04','2019-11-04 00:00:00',-0.65,-0.0431,'2021-08-01 08:43:17','2023-06-27 21:33:02',0,0,0,0,0),
(552,'XAU','USD',1509.85,1506.4,'2019-11-01','2019-11-01 00:00:00',3.45,0.2285,'2021-08-01 08:43:18','2023-06-27 21:33:02',0,0,0,0,0),
(553,'XAU','USD',1506.4,1490.15,'2019-10-31','2019-10-31 00:00:00',16.25,1.0787,'2021-08-01 08:43:19','2023-06-27 21:33:02',0,0,0,0,0),
(554,'XAU','USD',1490.15,1492.75,'2019-10-30','2019-10-30 00:00:00',-2.6,-0.1745,'2021-08-01 08:43:19','2023-06-27 21:33:02',0,0,0,0,0),
(555,'XAU','USD',1492.75,1505.05,'2019-10-29','2019-10-29 00:00:00',-12.3,-0.824,'2021-08-01 08:43:20','2023-06-27 21:33:02',0,0,0,0,0),
(556,'XAU','USD',1505.05,1504.65,'2019-10-28','2019-10-28 00:00:00',0.4,0.0266,'2021-08-01 08:43:20','2023-06-27 21:33:02',0,0,0,0,0),
(557,'XAU','USD',1504.65,1488.85,'2019-10-25','2019-10-25 00:00:00',15.8,1.0501,'2021-08-01 08:43:21','2023-06-27 21:33:02',0,0,0,0,0),
(558,'XAU','USD',1488.85,1494.25,'2019-10-24','2019-10-24 00:00:00',-5.4,-0.3627,'2021-08-01 08:43:22','2023-06-27 21:33:02',0,0,0,0,0),
(559,'XAU','USD',1494.25,1487.45,'2019-10-23','2019-10-23 00:00:00',6.8,0.4551,'2021-08-01 08:43:22','2023-06-27 21:33:02',0,0,0,0,0),
(560,'XAU','USD',1807.55,1828.25,'2021-08-02','2021-08-02 00:00:00',-20.7,-1.1452,'2021-08-03 07:00:09','2023-06-27 21:33:02',58.1141,53.2712,50.8498,48.4284,43.5856),
(561,'XAU','USD',1809.7,1807.55,'2021-08-03','2021-08-03 00:00:00',2.15,0.1188,'2021-08-04 07:00:08','2023-06-27 21:33:02',58.1832,53.3346,50.9103,48.486,43.6374),
(562,'XAU','USD',1812.45,1809.7,'2021-08-04','2021-08-04 00:00:00',2.75,0.1517,'2021-08-05 07:00:06','2023-06-27 21:33:02',58.2716,53.4157,50.9877,48.5597,43.7037),
(563,'XAU','USD',1811.2,1812.45,'2021-08-05','2021-08-05 00:00:00',-1.25,-0.069,'2021-08-06 07:00:10','2023-06-27 21:33:02',58.2314,53.3788,50.9525,48.5262,43.6736),
(564,'XAU','USD',1799.45,1811.2,'2021-08-06','2021-08-06 00:00:00',-11.75,-0.653,'2021-08-07 07:00:08','2023-06-27 21:33:02',57.8537,53.0325,50.622,48.2114,43.3902),
(565,'XAU','USD',1741.5,1799.45,'2021-08-09','2021-08-09 00:00:00',-57.95,-3.3276,'2021-08-10 07:00:06','2023-06-27 21:33:02',55.9905,51.3246,48.9917,46.6588,41.9929),
(566,'XAU','USD',1729.55,1741.5,'2021-08-10','2021-08-10 00:00:00',-11.95,-0.6909,'2021-08-11 07:00:10','2023-06-27 21:33:02',55.6063,50.9725,48.6555,46.3386,41.7047),
(567,'XAU','USD',1734.05,1729.55,'2021-08-11','2021-08-11 00:00:00',4.5,0.2595,'2021-08-12 07:00:06','2023-06-27 21:33:02',55.751,51.1051,48.7821,46.4592,41.8133),
(568,'XAU','USD',1755.5,1734.05,'2021-08-12','2021-08-12 00:00:00',21.45,1.2219,'2021-08-13 07:00:09','2023-06-27 21:33:02',56.4406,51.7372,49.3856,47.0339,42.3305),
(569,'XAU','USD',1757.65,1755.5,'2021-08-13','2021-08-13 00:00:00',2.15,0.1223,'2021-08-14 06:08:08','2023-06-27 21:33:02',56.5098,51.8006,49.446,47.0915,42.3823),
(571,'XAU','USD',1775.75,1757.65,'2021-08-16','2021-08-16 00:00:00',18.1,1.0193,'2021-08-17 06:28:44','2023-06-27 21:33:02',57.0917,52.334,49.9552,47.5764,42.8188),
(572,'XAU','USD',1794.05,1775.75,'2021-08-17','2021-08-17 00:00:00',18.3,1.02,'2021-08-18 08:01:02','2023-06-27 21:33:02',57.68,52.8734,50.47,48.0667,43.26),
(574,'XAU','USD',1788.1,1794.05,'2021-08-18','2021-08-18 00:00:00',-5.95,-0.3328,'2021-08-19 07:23:30','2023-06-27 21:33:02',57.4887,52.698,50.3027,47.9073,43.1166),
(575,'XAU','USD',1788.2,1788.1,'2021-08-19','2021-08-19 00:00:00',0.1,0.0056,'2021-08-20 07:00:08','2023-06-27 21:33:02',57.492,52.701,50.3055,47.91,43.119),
(576,'XAU','USD',1782.95,1788.2,'2021-08-20','2021-08-20 00:00:00',-5.25,-0.2945,'2021-08-21 07:00:06','2023-06-27 21:33:02',57.3232,52.5462,50.1578,47.7693,42.9924),
(578,'XAU','USD',1786.9,1782.95,'2021-08-23','2021-08-23 00:00:00',3.95,0.2211,'2021-08-24 07:00:08','2023-06-27 21:33:02',57.4502,52.6627,50.2689,47.8751,43.0876),
(579,'XAU','USD',1802.95,1786.9,'2021-08-24','2021-08-24 00:00:00',16.05,0.8902,'2021-08-25 07:00:06','2023-06-27 21:33:02',57.9662,53.1357,50.7204,48.3052,43.4746),
(580,'XAU','USD',1794.7,1802.95,'2021-08-25','2021-08-25 00:00:00',-8.25,-0.4597,'2021-08-26 07:00:10','2023-06-27 21:33:02',57.7009,52.8925,50.4883,48.0841,43.2757),
(581,'XAU','USD',1783.8,1794.7,'2021-08-26','2021-08-26 00:00:00',-10.9,-0.6111,'2021-08-27 07:00:08','2023-06-27 21:33:02',57.3505,52.5713,50.1817,47.7921,43.0129),
(582,'XAU','USD',1795.5,1783.8,'2021-08-27','2021-08-27 00:00:00',11.7,0.6516,'2021-08-28 07:00:06','2023-06-27 21:33:02',57.7267,52.9161,50.5108,48.1056,43.295),
(583,'XAU','USD',1795.5,1795.5,'2021-08-30','2021-08-30 00:00:00',0,0,'2021-08-31 07:00:09','2023-06-27 21:33:02',57.7267,52.9161,50.5108,48.1056,43.295),
(584,'XAU','USD',1814.3,1795.5,'2021-08-31','2021-08-31 00:00:00',18.8,1.0362,'2021-09-01 07:00:09','2023-06-27 21:33:02',58.3311,53.4702,51.0397,48.6092,43.7483),
(585,'XAU','USD',1813.9,1814.3,'2021-09-01','2021-09-01 00:00:00',-0.4,-0.0221,'2021-09-02 07:00:07','2023-06-27 21:33:02',58.3182,53.4584,51.0285,48.5985,43.7387),
(586,'XAU','USD',1815.15,1813.9,'2021-09-02','2021-09-02 00:00:00',1.25,0.0689,'2021-09-03 07:00:11','2023-06-27 21:33:02',58.3584,53.4952,51.0636,48.632,43.7688),
(587,'XAU','USD',1812.05,1815.15,'2021-09-03','2021-09-03 00:00:00',-3.1,-0.1711,'2021-09-04 07:00:04','2023-06-27 21:33:02',58.2588,53.4039,50.9764,48.549,43.6941),
(590,'XAU','USD',1823.85,1812.05,'2021-09-06','2021-09-06 00:00:00',11.8,0.647,'2021-09-07 07:00:09','2023-06-27 21:33:02',0,0,0,0,0),
(591,'XAU','USD',1810.75,1823.85,'2021-09-07','2021-09-07 00:00:00',-13.1,-0.7235,'2021-09-08 07:00:07','2023-06-27 21:33:02',58.217,53.3656,50.9398,48.5141,43.6627),
(592,'XAU','USD',1797.95,1810.75,'2021-09-08','2021-09-08 00:00:00',-12.8,-0.7119,'2021-09-09 07:00:07','2023-06-27 21:33:02',57.8054,52.9883,50.5798,48.1712,43.3541),
(593,'XAU','USD',1795.35,1797.95,'2021-09-09','2021-09-09 00:00:00',-2.6,-0.1448,'2021-09-10 07:00:06','2023-06-27 21:33:02',57.7218,52.9117,50.5066,48.1015,43.2914),
(594,'XAU','USD',1799.9,1795.35,'2021-09-10','2021-09-10 00:00:00',4.55,0.2528,'2021-09-11 07:00:05','2023-06-27 21:33:02',57.8681,53.0458,50.6346,48.2234,43.4011),
(595,'XAU','USD',1787.85,1799.9,'2021-09-13','2021-09-13 00:00:00',-12.05,-0.674,'2021-09-14 07:00:13','2023-06-27 21:33:02',57.4807,52.6907,50.2956,47.9006,43.1105),
(596,'XAU','USD',1801.4,1788.65,'2021-09-15','2021-09-15 00:00:00',12.75,0.7078,'2021-09-16 07:18:45','2023-06-27 21:33:02',57.9164,53.09,50.6768,48.2636,43.4373),
(597,'XAU','USD',1788.65,1787.85,'2021-09-14','2021-09-14 00:00:00',0.8,0.0447,'2021-09-16 07:25:27','2023-06-27 21:33:02',57.5064,52.7142,50.3181,47.922,43.1298),
(598,'XAU','USD',1781.45,1801.4,'2021-09-16','2021-09-16 00:00:00',-19.95,-1.1199,'2021-09-17 07:00:08','2023-06-27 21:33:02',57.2749,52.502,50.1156,47.7291,42.9562),
(599,'XAU','USD',1766.1,1781.45,'2021-09-17','2021-09-17 00:00:00',-15.35,-0.8691,'2021-09-18 07:00:11','2023-06-27 21:33:02',56.7814,52.0496,49.6838,47.3179,42.5861),
(600,'XAU','USD',1757.15,1766.1,'2021-09-20','2021-09-20 00:00:00',-8.95,-0.5093,'2021-09-21 07:00:06','2023-06-27 21:33:02',56.4937,51.7859,49.432,47.0781,42.3703),
(601,'XAU','USD',1766.45,1757.15,'2021-09-21','2021-09-21 00:00:00',9.3,0.5265,'2021-09-22 07:00:10','2023-06-27 21:33:02',56.7927,52.06,49.6936,47.3272,42.5945),
(602,'XAU','USD',1775.35,1766.45,'2021-09-22','2021-09-22 00:00:00',8.9,0.5013,'2021-09-23 07:00:05','2023-06-27 21:33:02',57.0788,52.3223,49.944,47.5657,42.8091),
(603,'XAU','USD',1771.05,1775.35,'2021-09-23','2021-09-23 00:00:00',-4.3,-0.2428,'2021-09-24 07:00:06','2023-06-27 21:33:02',56.9406,52.1955,49.823,47.4505,42.7054),
(604,'XAU','USD',1755.15,1771.05,'2021-09-24','2021-09-24 00:00:00',-15.9,-0.9059,'2021-09-25 07:00:06','2023-06-27 21:33:02',56.4294,51.7269,49.3757,47.0245,42.322),
(605,'XAU','USD',1749.15,1755.15,'2021-09-27','2021-09-27 00:00:00',-6,-0.343,'2021-09-28 07:00:10','2023-06-27 21:33:02',56.2365,51.5501,49.2069,46.8637,42.1774),
(606,'XAU','USD',1739.65,1749.15,'2021-09-28','2021-09-28 00:00:00',-9.5,-0.5461,'2021-09-29 07:00:11','2023-06-27 21:33:02',55.931,51.2701,48.9397,46.6092,41.9483),
(607,'XAU','USD',1741.65,1739.65,'2021-09-29','2021-09-29 00:00:00',2,0.1148,'2021-09-30 07:00:09','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(608,'XAU','USD',1741.65,1741.65,'2021-09-30','2021-09-30 00:00:00',0,0,'2021-10-01 07:00:07','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(609,'XAU','USD',1741.65,1741.65,'2021-10-01','2021-10-01 00:00:00',0,0,'2021-10-02 07:00:06','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(610,'XAU','USD',1741.65,1741.65,'2021-10-04','2021-10-04 00:00:00',0,0,'2021-10-05 07:00:08','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(611,'XAU','USD',1741.65,1741.65,'2021-10-05','2021-10-05 00:00:00',0,0,'2021-10-06 07:00:07','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(612,'XAU','USD',1741.65,1741.65,'2021-10-06','2021-10-06 00:00:00',0,0,'2021-10-07 07:00:08','2023-06-27 21:33:02',55.9953,51.3291,48.9959,46.6628,41.9965),
(613,'XAU','USD',1758.55,1741.65,'2021-10-07','2021-10-07 00:00:00',16.9,0.961,'2021-10-08 07:00:05','2023-06-27 21:33:02',56.5387,51.8271,49.4714,47.1156,42.404),
(614,'XAU','USD',1757.5,1758.55,'2021-10-08','2021-10-08 00:00:00',-1.05,-0.0597,'2021-10-09 07:00:06','2023-06-27 21:33:02',56.5049,51.7962,49.4418,47.0874,42.3787),
(615,'XAU','USD',1752.55,1757.5,'2021-10-11','2021-10-11 00:00:00',-4.95,-0.2824,'2021-10-12 07:00:05','2023-06-27 21:33:02',0,0,0,0,0),
(616,'XAU','USD',1759.1,1752.55,'2021-10-12','2021-10-12 00:00:00',6.55,0.3723,'2021-10-13 07:00:04','2023-06-27 21:33:02',56.5564,51.8433,49.4868,47.1303,42.4173),
(617,'XAU','USD',1767.45,1759.1,'2021-10-13','2021-10-13 00:00:00',8.35,0.4724,'2021-10-14 07:00:05','2023-06-27 21:33:02',56.8248,52.0894,49.7217,47.354,42.6186),
(618,'XAU','USD',1797.15,1767.45,'2021-10-14','2021-10-14 00:00:00',29.7,1.6526,'2021-10-15 07:00:06','2023-06-27 21:33:02',57.7797,52.9647,50.5572,48.1498,43.3348),
(619,'XAU','USD',1781.45,1797.15,'2021-10-15','2021-10-15 00:00:00',-15.7,-0.8813,'2021-10-16 07:00:21','2023-06-27 21:33:02',57.2749,52.502,50.1156,47.7291,42.9562),
(620,'XAU','USD',1762.45,1781.45,'2021-10-18','2021-10-18 00:00:00',-19,-1.078,'2021-10-19 07:00:08','2023-06-27 21:33:02',56.6641,51.9421,49.5811,47.2201,42.4981),
(621,'XAU','USD',1779.4,1762.45,'2021-10-19','2021-10-19 00:00:00',16.95,0.9526,'2021-10-20 07:00:07','2023-06-27 21:33:02',57.209,52.4416,50.0579,47.6742,42.9068),
(622,'XAU','USD',1778.15,1779.4,'2021-10-20','2021-10-20 00:00:00',-1.25,-0.0703,'2021-10-21 07:00:05','2023-06-27 21:33:02',57.1689,52.4048,50.0227,47.6407,42.8766),
(623,'XAU','USD',1785.3,1778.15,'2021-10-21','2021-10-21 00:00:00',7.15,0.4005,'2021-10-22 07:00:09','2023-06-27 21:33:02',57.3987,52.6155,50.2239,47.8323,43.049),
(625,'XAU','USD',1792.3,1785.3,'2021-10-22','2021-10-22 00:00:00',7,0.3906,'2021-10-23 09:12:08','2023-06-27 21:33:02',57.6238,52.8218,50.4208,48.0198,43.2178),
(627,'XAU','USD',1799.2,1792.3,'2021-10-25','2021-10-25 00:00:00',6.9,0.3835,'2021-10-26 07:00:07','2023-06-27 21:33:02',57.8456,53.0252,50.6149,48.2047,43.3842),
(628,'XAU','USD',1801.9,1799.2,'2021-10-26','2021-10-26 00:00:00',2.7,0.1498,'2021-10-27 07:00:07','2023-06-27 21:33:02',57.9324,53.1047,50.6909,48.277,43.4493),
(629,'XAU','USD',1783.85,1801.9,'2021-10-27','2021-10-27 00:00:00',-18.05,-1.0119,'2021-10-28 07:00:10','2023-06-27 21:33:02',57.3521,52.5728,50.1831,47.7934,43.0141),
(630,'XAU','USD',1798.2,1783.85,'2021-10-28','2021-10-28 00:00:00',14.35,0.798,'2021-10-29 07:00:06','2023-06-27 21:33:02',57.8135,52.9957,50.5868,48.1779,43.3601),
(631,'XAU','USD',1796.3,1798.2,'2021-10-29','2021-10-29 00:00:00',-1.9,-0.1058,'2021-10-30 07:00:09','2023-06-27 21:33:02',57.7524,52.9397,50.5333,48.127,43.3143),
(632,'XAU','USD',1786.55,1796.3,'2021-11-01','2021-11-01 00:00:00',-9.75,-0.5457,'2021-11-02 07:00:10','2023-06-27 21:33:02',57.4389,52.6523,50.2591,47.8658,43.0792),
(633,'XAU','USD',1791.5,1786.55,'2021-11-02','2021-11-02 00:00:00',4.95,0.2763,'2021-11-03 07:00:05','2023-06-27 21:33:02',57.5981,52.7982,50.3983,47.9984,43.1985),
(634,'XAU','USD',1781.85,1791.5,'2021-11-03','2021-11-03 00:00:00',-9.65,-0.5416,'2021-11-04 07:00:05','2023-06-27 21:33:02',57.2878,52.5138,50.1268,47.7398,42.9659),
(635,'XAU','USD',1778.1,1781.85,'2021-11-04','2021-11-04 00:00:00',-3.75,-0.2109,'2021-11-05 07:00:11','2023-06-27 21:33:02',57.1672,52.4033,50.0213,47.6394,42.8754),
(636,'XAU','USD',1793.2,1778.1,'2021-11-05','2021-11-05 00:00:00',15.1,0.8421,'2021-11-06 07:00:07','2023-06-27 21:33:02',57.6527,52.8483,50.4461,48.0439,43.2395),
(637,'XAU','USD',1818,1793.2,'2021-11-08','2021-11-08 00:00:00',24.8,1.3641,'2021-11-09 07:00:07','2023-06-27 21:33:02',58.4501,53.5792,51.1438,48.7084,43.8375),
(639,'XAU','USD',1824.4,1818,'2021-11-09','2021-11-09 00:00:00',6.4,0.3508,'2021-11-10 07:00:08','2023-06-27 21:33:02',58.6558,53.7678,51.3238,48.8799,43.9919),
(640,'XAU','USD',1824.95,1824.4,'2021-11-10','2021-11-10 00:00:00',0.55,0.0301,'2021-11-11 07:00:07','2023-06-27 21:33:02',58.6735,53.784,51.3393,48.8946,44.0051),
(641,'XAU','USD',1859.25,1824.95,'2021-11-11','2021-11-11 00:00:00',34.3,1.8448,'2021-11-12 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(642,'XAU','USD',1850,1859.25,'2021-11-12','2021-11-12 00:00:00',-9.25,-0.5,'2021-11-13 07:00:07','2023-06-27 21:33:02',59.4789,54.5223,52.044,49.5657,44.6092),
(643,'XAU','USD',1863.8,1850,'2021-11-15','2021-11-15 00:00:00',13.8,0.7404,'2021-11-16 07:00:09','2023-06-27 21:33:02',59.9226,54.929,52.4322,49.9355,44.9419),
(644,'XAU','USD',1872.25,1863.8,'2021-11-16','2021-11-16 00:00:00',8.45,0.4513,'2021-11-17 07:00:08','2023-06-27 21:33:02',60.1942,55.178,52.67,50.1619,45.1457),
(645,'XAU','USD',1858.45,1872.25,'2021-11-17','2021-11-17 00:00:00',-13.8,-0.7426,'2021-11-18 07:00:08','2023-06-27 21:33:02',59.7506,54.7713,52.2817,49.7921,44.8129),
(646,'XAU','USD',1860.5,1858.45,'2021-11-18','2021-11-18 00:00:00',2.05,0.1102,'2021-11-19 07:00:06','2023-06-27 21:33:02',59.8165,54.8318,52.3394,49.8471,44.8623),
(647,'XAU','USD',1861.4,1860.5,'2021-11-19','2021-11-19 00:00:00',0.9,0.0484,'2021-11-20 07:00:08','2023-06-27 21:33:02',59.8454,54.8583,52.3647,49.8712,44.884),
(648,'XAU','USD',1841.1,1861.4,'2021-11-22','2021-11-22 00:00:00',-20.3,-1.1026,'2021-11-23 07:00:06','2023-06-27 21:33:02',59.1927,54.26,51.7936,49.3273,44.3946),
(649,'XAU','USD',1797.3,1841.1,'2021-11-23','2021-11-23 00:00:00',-43.8,-2.437,'2021-11-24 07:00:06','2023-06-27 21:33:02',57.7845,52.9692,50.5615,48.1538,43.3384),
(650,'XAU','USD',1790.8,1797.3,'2021-11-24','2021-11-24 00:00:00',-6.5,-0.363,'2021-11-25 07:00:05','2023-06-27 21:33:02',57.5756,52.7776,50.3786,47.9796,43.1817),
(651,'XAU','USD',1790.65,1790.8,'2021-11-25','2021-11-25 00:00:00',-0.15,-0.0084,'2021-11-26 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(652,'XAU','USD',1809.8,1790.65,'2021-11-26','2021-11-26 00:00:00',19.15,1.0581,'2021-11-27 07:00:09','2023-06-27 21:33:02',58.1864,53.3376,50.9131,48.4887,43.6398),
(653,'XAU','USD',1795,1809.8,'2021-11-29','2021-11-29 00:00:00',-14.8,-0.8245,'2021-11-30 07:00:11','2023-06-27 21:33:02',57.7106,52.9014,50.4968,48.0922,43.2829),
(654,'XAU','USD',1797.6,1795,'2021-11-30','2021-11-30 00:00:00',2.6,0.1446,'2021-12-01 07:00:11','2023-06-27 21:33:02',57.7942,52.978,50.5699,48.1618,43.3456),
(655,'XAU','USD',1786.8,1797.6,'2021-12-01','2021-12-01 00:00:00',-10.8,-0.6044,'2021-12-02 07:00:05','2023-06-27 21:33:02',57.447,52.6597,50.2661,47.8725,43.0852),
(656,'XAU','USD',1775.7,1786.8,'2021-12-02','2021-12-02 00:00:00',-11.1,-0.6251,'2021-12-03 07:00:08','2023-06-27 21:33:02',57.0901,52.3326,49.9538,47.5751,42.8176),
(657,'XAU','USD',1773.5,1775.7,'2021-12-03','2021-12-03 00:00:00',-2.2,-0.124,'2021-12-04 07:00:07','2023-06-27 21:33:02',57.0193,52.2677,49.8919,47.5161,42.7645),
(658,'XAU','USD',1781.25,1773.5,'2021-12-06','2021-12-06 00:00:00',7.75,0.4351,'2021-12-07 07:00:08','2023-06-27 21:33:02',57.2685,52.4961,50.11,47.7238,42.9514),
(659,'XAU','USD',1779.65,1781.25,'2021-12-07','2021-12-07 00:00:00',-1.6,-0.0899,'2021-12-08 07:00:14','2023-06-27 21:33:02',57.2171,52.449,50.0649,47.6809,42.9128),
(660,'XAU','USD',1789.8,1779.65,'2021-12-08','2021-12-08 00:00:00',10.15,0.5671,'2021-12-09 07:00:07','2023-06-27 21:33:02',57.5434,52.7481,50.3505,47.9528,43.1576),
(661,'XAU','USD',1783.4,1789.8,'2021-12-09','2021-12-09 00:00:00',-6.4,-0.3589,'2021-12-10 07:01:01','2023-06-27 21:33:02',57.3376,52.5595,50.1704,47.7814,43.0032),
(662,'XAU','USD',1771.9,1783.4,'2021-12-10','2021-12-10 00:00:00',-11.5,-0.649,'2021-12-11 07:00:11','2023-06-27 21:33:02',56.9679,52.2206,49.8469,47.4733,42.7259),
(663,'XAU','USD',1784.45,1771.9,'2021-12-13','2021-12-13 00:00:00',12.55,0.7033,'2021-12-14 07:00:06','2023-06-27 21:33:02',57.3714,52.5904,50.2,47.8095,43.0285),
(664,'XAU','USD',1782.35,1784.45,'2021-12-14','2021-12-14 00:00:00',-2.1,-0.1178,'2021-12-15 07:00:06','2023-06-27 21:33:02',57.3039,52.5286,50.1409,47.7532,42.9779),
(665,'XAU','USD',1769.4,1782.35,'2021-12-15','2021-12-15 00:00:00',-12.95,-0.7319,'2021-12-16 07:00:09','2023-06-27 21:33:02',56.8875,52.1469,49.7766,47.4063,42.6656),
(666,'XAU','USD',1785.15,1769.4,'2021-12-16','2021-12-16 00:00:00',15.75,0.8823,'2021-12-17 07:00:16','2023-06-27 21:33:02',57.3939,52.6111,50.2197,47.8283,43.0454),
(667,'XAU','USD',1807.5,1785.15,'2021-12-17','2021-12-17 00:00:00',22.35,1.2365,'2021-12-18 07:00:08','2023-06-27 21:33:02',58.1125,53.2698,50.8484,48.4271,43.5844),
(668,'XAU','USD',1797.4,1807.5,'2021-12-20','2021-12-20 00:00:00',-10.1,-0.5619,'2021-12-21 07:00:40','2023-06-27 21:33:02',57.7878,52.9721,50.5643,48.1565,43.3408),
(669,'XAU','USD',1795.85,1797.4,'2021-12-21','2021-12-21 00:00:00',-1.55,-0.0863,'2021-12-22 07:00:07','2023-06-27 21:33:02',57.7379,52.9264,50.5207,48.1149,43.3034),
(670,'XAU','USD',1789.9,1795.85,'2021-12-22','2021-12-22 00:00:00',-5.95,-0.3324,'2021-12-23 07:00:12','2023-06-27 21:33:02',57.5466,52.7511,50.3533,47.9555,43.16),
(671,'XAU','USD',1805.55,1789.9,'2021-12-23','2021-12-23 00:00:00',15.65,0.8668,'2021-12-24 07:00:08','2023-06-27 21:33:02',58.0498,53.2123,50.7936,48.3748,43.5373),
(672,'XAU','USD',1805.55,1805.55,'2021-12-24','2021-12-24 00:00:00',0,0,'2021-12-25 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(673,'XAU','USD',1805.55,1805.55,'2021-12-27','2021-12-27 00:00:00',0,0,'2021-12-28 07:00:12','2023-06-27 21:33:02',58.0498,53.2123,50.7936,48.3748,43.5373),
(674,'XAU','USD',1805.55,1805.55,'2021-12-28','2021-12-28 00:00:00',0,0,'2021-12-29 07:00:10','2023-06-27 21:33:02',58.0498,53.2123,50.7936,48.3748,43.5373),
(675,'XAU','USD',1796.35,1805.55,'2021-12-29','2021-12-29 00:00:00',-9.2,-0.5121,'2021-12-30 07:00:06','2023-06-27 21:33:02',57.754,52.9412,50.5347,48.1283,43.3155),
(676,'XAU','USD',1799.25,1796.35,'2021-12-30','2021-12-30 00:00:00',2.9,0.1612,'2021-12-31 07:00:05','2023-06-27 21:33:02',57.8472,53.0266,50.6163,48.206,43.3854),
(677,'XAU','USD',1799.25,1799.25,'2021-12-31','2021-12-31 00:00:00',0,0,'2022-01-01 07:00:11','2023-06-27 21:33:02',0,0,0,0,0),
(678,'XAU','USD',1799.25,1799.25,'2022-01-03','2022-01-03 00:00:00',0,0,'2022-01-04 07:00:14','2023-06-27 21:33:02',57.8472,53.0266,50.6163,48.206,43.3854),
(679,'XAU','USD',1809.05,1799.25,'2022-01-04','2022-01-04 00:00:00',9.8,0.5417,'2022-01-05 07:00:13','2023-06-27 21:33:02',58.1623,53.3154,50.892,48.4686,43.6217),
(680,'XAU','USD',1818.5,1809.05,'2022-01-05','2022-01-05 00:00:00',9.45,0.5197,'2022-01-06 07:00:11','2023-06-27 21:33:02',58.4661,53.594,51.1579,48.7218,43.8496),
(681,'XAU','USD',1804.95,1818.5,'2022-01-06','2022-01-06 00:00:00',-13.55,-0.7507,'2022-01-07 07:00:08','2023-06-27 21:33:02',58.0305,53.1946,50.7767,48.3587,43.5229),
(682,'XAU','USD',1792.2,1804.95,'2022-01-07','2022-01-07 00:00:00',-12.75,-0.7114,'2022-01-08 07:00:08','2023-06-27 21:33:02',57.6206,52.8189,50.418,48.0171,43.2154),
(683,'XAU','USD',1800.55,1792.2,'2022-01-10','2022-01-10 00:00:00',8.35,0.4637,'2022-01-11 07:00:12','2023-06-27 21:33:02',57.889,53.0649,50.6529,48.2409,43.4168),
(684,'XAU','USD',1805.2,1800.55,'2022-01-11','2022-01-11 00:00:00',4.65,0.2576,'2022-01-12 07:00:10','2023-06-27 21:33:02',58.0385,53.202,50.7837,48.3654,43.5289),
(685,'XAU','USD',1816.4,1805.2,'2022-01-12','2022-01-12 00:00:00',11.2,0.6166,'2022-01-13 07:00:08','2023-06-27 21:33:02',58.3986,53.5321,51.0988,48.6655,43.799),
(686,'XAU','USD',1822.4,1816.4,'2022-01-13','2022-01-13 00:00:00',6,0.3292,'2022-01-14 07:00:07','2023-06-27 21:33:02',58.5915,53.7089,51.2676,48.8263,43.9436),
(687,'XAU','USD',1822.25,1822.4,'2022-01-14','2022-01-14 00:00:00',-0.15,-0.0082,'2022-01-15 07:00:11','2023-06-27 21:33:02',58.5867,53.7045,51.2634,48.8222,43.94),
(689,'XAU','USD',1810.8,1820.05,'2022-01-18','2022-01-18 00:00:00',-9.25,-0.5108,'2022-01-19 07:00:11','2023-06-27 21:33:02',58.2186,53.367,50.9413,48.5155,43.6639),
(690,'XAU','USD',1817.5,1810.8,'2022-01-19','2022-01-19 00:00:00',6.7,0.3686,'2022-01-20 07:00:08','2023-06-27 21:33:02',58.434,53.5645,51.1297,48.695,43.8255),
(691,'XAU','USD',1836.7,1817.5,'2022-01-20','2022-01-20 00:00:00',19.2,1.0454,'2022-01-21 07:00:14','2023-06-27 21:33:02',59.0513,54.1303,51.6699,49.2094,44.2885),
(692,'XAU','USD',1834.25,1836.7,'2022-01-21','2022-01-21 00:00:00',-2.45,-0.1336,'2022-01-22 07:00:15','2023-06-27 21:33:02',58.9725,54.0581,51.6009,49.1438,44.2294),
(693,'XAU','USD',1838.25,1834.25,'2022-01-24','2022-01-24 00:00:00',4,0.2176,'2022-01-25 07:00:08','2023-06-27 21:33:02',59.1011,54.176,51.7135,49.2509,44.3258),
(694,'XAU','USD',1835.65,1838.25,'2022-01-25','2022-01-25 00:00:00',-2.6,-0.1416,'2022-01-26 07:00:12','2023-06-27 21:33:02',59.0175,54.0994,51.6403,49.1813,44.2631),
(695,'XAU','USD',1845.2,1835.65,'2022-01-26','2022-01-26 00:00:00',9.55,0.5176,'2022-01-27 07:00:07','2023-06-27 21:33:02',59.3246,54.3808,51.909,49.4371,44.4934),
(696,'XAU','USD',1815.5,1845.2,'2022-01-27','2022-01-27 00:00:00',-29.7,-1.6359,'2022-01-28 07:00:14','2023-06-27 21:33:02',58.3697,53.5055,51.0735,48.6414,43.7773),
(697,'XAU','USD',1790.2,1815.5,'2022-01-28','2022-01-28 00:00:00',-25.3,-1.4132,'2022-01-29 07:00:13','2023-06-27 21:33:02',57.5563,52.7599,50.3617,47.9636,43.1672),
(698,'XAU','USD',1790.6,1790.2,'2022-01-31','2022-01-31 00:00:00',0.4,0.0223,'2022-02-01 07:00:10','2023-06-27 21:33:02',57.5691,52.7717,50.373,47.9743,43.1768),
(699,'XAU','USD',1806.5,1790.6,'2022-02-01','2022-02-01 00:00:00',15.9,0.8802,'2022-02-02 07:00:12','2023-06-27 21:33:02',58.0803,53.2403,50.8203,48.4003,43.5602),
(700,'XAU','USD',1802,1806.5,'2022-02-02','2022-02-02 00:00:00',-4.5,-0.2497,'2022-02-03 07:00:07','2023-06-27 21:33:02',57.9356,53.1077,50.6937,48.2797,43.4517),
(701,'XAU','USD',1803.75,1802,'2022-02-03','2022-02-03 00:00:00',1.75,0.097,'2022-02-04 07:00:13','2023-06-27 21:33:02',57.9919,53.1593,50.7429,48.3266,43.4939),
(702,'XAU','USD',1814.55,1803.75,'2022-02-04','2022-02-04 00:00:00',10.8,0.5952,'2022-02-05 07:00:09','2023-06-27 21:33:02',58.3391,53.4775,51.0467,48.6159,43.7544),
(739,'XAU','USD',1487.45,1490.85,'2019-10-22','2019-10-22 00:00:00',-3.4,-0.2286,'2022-02-08 05:21:37','2023-06-27 21:33:02',0,0,0,0,0),
(740,'XAU','USD',1490.85,1487.5,'2019-10-21','2019-10-21 00:00:00',3.35,0.2247,'2022-02-08 05:21:39','2023-06-27 21:33:02',0,0,0,0,0),
(741,'XAU','USD',1487.5,1484.45,'2019-10-18','2019-10-18 00:00:00',3.05,0.205,'2022-02-08 05:21:41','2023-06-27 21:33:02',0,0,0,0,0),
(742,'XAU','USD',1484.45,1482.55,'2019-10-17','2019-10-17 00:00:00',1.9,0.128,'2022-02-08 05:21:44','2023-06-27 21:33:02',0,0,0,0,0),
(743,'XAU','USD',1482.55,1494.75,'2019-10-16','2019-10-16 00:00:00',-12.2,-0.8229,'2022-02-08 05:21:46','2023-06-27 21:33:02',0,0,0,0,0),
(744,'XAU','USD',1494.75,1494.2,'2019-10-15','2019-10-15 00:00:00',0.55,0.0368,'2022-02-08 05:21:49','2023-06-27 21:33:02',0,0,0,0,0),
(745,'XAU','USD',1494.2,1498.35,'2019-10-14','2019-10-14 00:00:00',-4.15,-0.2777,'2022-02-08 05:21:50','2023-06-27 21:33:02',0,0,0,0,0),
(746,'XAU','USD',1498.35,1508.2,'2019-10-11','2019-10-11 00:00:00',-9.85,-0.6574,'2022-02-08 05:21:51','2023-06-27 21:33:02',0,0,0,0,0),
(747,'XAU','USD',1508.2,1503.4,'2019-10-10','2019-10-10 00:00:00',4.8,0.3183,'2022-02-08 05:21:52','2023-06-27 21:33:02',0,0,0,0,0),
(748,'XAU','USD',1503.4,1500,'2019-10-09','2019-10-09 00:00:00',3.4,0.2262,'2022-02-08 05:21:54','2023-06-27 21:33:02',0,0,0,0,0),
(749,'XAU','USD',1500,1502.15,'2019-10-08','2019-10-08 00:00:00',-2.15,-0.1433,'2022-02-08 05:21:56','2023-06-27 21:33:02',0,0,0,0,0),
(750,'XAU','USD',1502.15,1509.5,'2019-10-07','2019-10-07 00:00:00',-7.35,-0.4893,'2022-02-08 05:21:57','2023-06-27 21:33:02',0,0,0,0,0),
(751,'XAU','USD',1509.5,1504,'2019-10-04','2019-10-04 00:00:00',5.5,0.3644,'2022-02-08 05:21:58','2023-06-27 21:33:02',0,0,0,0,0),
(752,'XAU','USD',1504,1484.05,'2019-10-03','2019-10-03 00:00:00',19.95,1.3265,'2022-02-08 05:21:59','2023-06-27 21:33:02',0,0,0,0,0),
(753,'XAU','USD',1484.05,1466.1,'2019-10-02','2019-10-02 00:00:00',17.95,1.2095,'2022-02-08 05:22:01','2023-06-27 21:33:02',0,0,0,0,0),
(754,'XAU','USD',1466.1,1487.6,'2019-10-01','2019-10-01 00:00:00',-21.5,-1.4665,'2022-02-08 05:22:03','2023-06-27 21:33:02',0,0,0,0,0),
(755,'XAU','USD',1487.6,1496.15,'2019-09-30','2019-09-30 00:00:00',-8.55,-0.5748,'2022-02-08 05:22:04','2023-06-27 21:33:02',0,0,0,0,0),
(756,'XAU','USD',1496.15,1507.05,'2019-09-27','2019-09-27 00:00:00',-10.9,-0.7285,'2022-02-08 05:22:05','2023-06-27 21:33:02',0,0,0,0,0),
(757,'XAU','USD',1507.05,1530.85,'2019-09-26','2019-09-26 00:00:00',-23.8,-1.5792,'2022-02-08 05:22:06','2023-06-27 21:33:02',0,0,0,0,0),
(758,'XAU','USD',1530.85,1520.25,'2019-09-25','2019-09-25 00:00:00',10.6,0.6924,'2022-02-08 05:22:07','2023-06-27 21:33:02',0,0,0,0,0),
(759,'XAU','USD',1520.25,1519.5,'2019-09-24','2019-09-24 00:00:00',0.75,0.0493,'2022-02-08 05:22:08','2023-06-27 21:33:02',0,0,0,0,0),
(760,'XAU','USD',1519.5,1504.1,'2019-09-23','2019-09-23 00:00:00',15.4,1.0135,'2022-02-08 05:22:09','2023-06-27 21:33:02',0,0,0,0,0),
(761,'XAU','USD',1504.1,1498.4,'2019-09-20','2019-09-20 00:00:00',5.7,0.379,'2022-02-08 05:22:11','2023-06-27 21:33:02',0,0,0,0,0),
(762,'XAU','USD',1498.4,1502.2,'2019-09-19','2019-09-19 00:00:00',-3.8,-0.2536,'2022-02-08 05:22:12','2023-06-27 21:33:02',0,0,0,0,0),
(763,'XAU','USD',1502.2,1499.3,'2019-09-18','2019-09-18 00:00:00',2.9,0.1931,'2022-02-08 05:22:13','2023-06-27 21:33:02',0,0,0,0,0),
(764,'XAU','USD',1499.3,1502.05,'2019-09-17','2019-09-17 00:00:00',-2.75,-0.1834,'2022-02-08 05:22:13','2023-06-27 21:33:02',0,0,0,0,0),
(765,'XAU','USD',1502.05,1506.3,'2019-09-16','2019-09-16 00:00:00',-4.25,-0.2829,'2022-02-08 05:22:14','2023-06-27 21:33:02',0,0,0,0,0),
(766,'XAU','USD',1506.3,1502.95,'2019-09-13','2019-09-13 00:00:00',3.35,0.2224,'2022-02-08 05:22:16','2023-06-27 21:33:02',0,0,0,0,0),
(767,'XAU','USD',1502.95,1493.65,'2019-09-12','2019-09-12 00:00:00',9.3,0.6188,'2022-02-08 05:22:17','2023-06-27 21:33:02',0,0,0,0,0),
(768,'XAU','USD',1493.65,1494.6,'2019-09-11','2019-09-11 00:00:00',-0.95,-0.0636,'2022-02-08 05:22:19','2023-06-27 21:33:02',0,0,0,0,0),
(769,'XAU','USD',1494.6,1509.95,'2019-09-10','2019-09-10 00:00:00',-15.35,-1.027,'2022-02-08 05:22:20','2023-06-27 21:33:02',0,0,0,0,0),
(770,'XAU','USD',1509.95,1504.95,'2019-09-09','2019-09-09 00:00:00',5,0.3311,'2022-02-08 05:22:21','2023-06-27 21:33:02',0,0,0,0,0),
(771,'XAU','USD',1504.95,1542.6,'2019-09-06','2019-09-06 00:00:00',-37.65,-2.5017,'2022-02-08 05:22:23','2023-06-27 21:33:02',0,0,0,0,0),
(772,'XAU','USD',1542.6,1538.8,'2019-09-05','2019-09-05 00:00:00',3.8,0.2463,'2022-02-08 05:22:24','2023-06-27 21:33:02',0,0,0,0,0),
(773,'XAU','USD',1538.8,1532.45,'2019-09-04','2019-09-04 00:00:00',6.35,0.4127,'2022-02-08 05:22:25','2023-06-27 21:33:02',0,0,0,0,0),
(774,'XAU','USD',1532.45,1523.35,'2019-09-03','2019-09-03 00:00:00',9.1,0.5938,'2022-02-08 05:22:26','2023-06-27 21:33:02',0,0,0,0,0),
(775,'XAU','USD',1523.35,1526.55,'2019-09-02','2019-09-02 00:00:00',-3.2,-0.2101,'2022-02-08 05:22:27','2023-06-27 21:33:02',0,0,0,0,0),
(776,'XAU','USD',1526.55,1536.65,'2019-08-30','2019-08-30 00:00:00',-10.1,-0.6616,'2022-02-08 05:22:28','2023-06-27 21:33:02',0,0,0,0,0),
(777,'XAU','USD',1536.65,1541.75,'2019-08-29','2019-08-29 00:00:00',-5.1,-0.3319,'2022-02-08 05:22:30','2023-06-27 21:33:02',0,0,0,0,0),
(778,'XAU','USD',1541.75,1531.85,'2019-08-28','2019-08-28 00:00:00',9.9,0.6421,'2022-02-08 05:22:31','2023-06-27 21:33:02',0,0,0,0,0),
(779,'XAU','USD',1531.85,1495.5,'2019-08-27','2019-08-27 00:00:00',36.35,2.3729,'2022-02-08 05:22:33','2023-06-27 21:33:02',0,0,0,0,0),
(780,'XAU','USD',1495.5,1495.5,'2019-08-26','2019-08-26 00:00:00',0,0,'2022-02-08 05:22:33','2023-06-27 21:33:02',0,0,0,0,0),
(781,'XAU','USD',1495.5,1498.7,'2019-08-23','2019-08-23 00:00:00',-3.2,-0.214,'2022-02-08 05:22:34','2023-06-27 21:33:02',0,0,0,0,0),
(782,'XAU','USD',1498.7,1499.65,'2019-08-22','2019-08-22 00:00:00',-0.95,-0.0634,'2022-02-08 05:22:35','2023-06-27 21:33:02',0,0,0,0,0),
(783,'XAU','USD',1499.65,1502.65,'2019-08-21','2019-08-21 00:00:00',-3,-0.2,'2022-02-08 05:22:37','2023-06-27 21:33:02',0,0,0,0,0),
(784,'XAU','USD',1502.65,1499.35,'2019-08-20','2019-08-20 00:00:00',3.3,0.2196,'2022-02-08 05:22:38','2023-06-27 21:33:02',0,0,0,0,0),
(785,'XAU','USD',1499.35,1509.05,'2019-08-19','2019-08-19 00:00:00',-9.7,-0.6469,'2022-02-08 05:22:39','2023-06-27 21:33:02',0,0,0,0,0),
(786,'XAU','USD',1509.05,1517.65,'2019-08-16','2019-08-16 00:00:00',-8.6,-0.5699,'2022-02-08 05:22:40','2023-06-27 21:33:02',0,0,0,0,0),
(787,'XAU','USD',1517.65,1500.35,'2019-08-15','2019-08-15 00:00:00',17.3,1.1399,'2022-02-08 05:22:41','2023-06-27 21:33:02',0,0,0,0,0),
(788,'XAU','USD',1500.35,1527.2,'2019-08-14','2019-08-14 00:00:00',-26.85,-1.7896,'2022-02-08 05:22:43','2023-06-27 21:33:02',0,0,0,0,0),
(789,'XAU','USD',1527.2,1501.95,'2019-08-13','2019-08-13 00:00:00',25.25,1.6534,'2022-02-08 05:22:44','2023-06-27 21:33:02',0,0,0,0,0),
(790,'XAU','USD',1501.95,1503.5,'2019-08-12','2019-08-12 00:00:00',-1.55,-0.1032,'2022-02-08 05:22:45','2023-06-27 21:33:02',0,0,0,0,0),
(791,'XAU','USD',1503.5,1497.4,'2019-08-09','2019-08-09 00:00:00',6.1,0.4057,'2022-02-08 05:22:46','2023-06-27 21:33:02',0,0,0,0,0),
(792,'XAU','USD',1497.4,1487.65,'2019-08-08','2019-08-08 00:00:00',9.75,0.6511,'2022-02-08 05:22:47','2023-06-27 21:33:02',0,0,0,0,0),
(793,'XAU','USD',1487.65,1461.85,'2019-08-07','2019-08-07 00:00:00',25.8,1.7343,'2022-02-08 05:22:48','2023-06-27 21:33:02',0,0,0,0,0),
(794,'XAU','USD',1461.85,1457.45,'2019-08-06','2019-08-06 00:00:00',4.4,0.301,'2022-02-08 05:22:49','2023-06-27 21:33:02',0,0,0,0,0),
(795,'XAU','USD',1457.45,1436.05,'2019-08-05','2019-08-05 00:00:00',21.4,1.4683,'2022-02-08 05:22:50','2023-06-27 21:33:02',0,0,0,0,0),
(796,'XAU','USD',1436.05,1406.4,'2019-08-02','2019-08-02 00:00:00',29.65,2.0647,'2022-02-08 05:22:51','2023-06-27 21:33:02',0,0,0,0,0),
(797,'XAU','USD',1406.4,1430.55,'2019-08-01','2019-08-01 00:00:00',-24.15,-1.7172,'2022-02-08 05:22:52','2023-06-27 21:33:02',0,0,0,0,0),
(798,'XAU','USD',1430.55,1428.45,'2019-07-31','2019-07-31 00:00:00',2.1,0.1468,'2022-02-08 05:22:53','2023-06-27 21:33:02',0,0,0,0,0),
(799,'XAU','USD',1428.45,1418.95,'2019-07-30','2019-07-30 00:00:00',9.5,0.6651,'2022-02-08 05:22:53','2023-06-27 21:33:02',0,0,0,0,0),
(800,'XAU','USD',1418.95,1418.25,'2019-07-29','2019-07-29 00:00:00',0.7,0.0493,'2022-02-08 05:22:54','2023-06-27 21:33:02',0,0,0,0,0),
(801,'XAU','USD',1418.25,1426.35,'2019-07-26','2019-07-26 00:00:00',-8.1,-0.5711,'2022-02-08 05:22:55','2023-06-27 21:33:02',0,0,0,0,0),
(802,'XAU','USD',1426.35,1425.55,'2019-07-25','2019-07-25 00:00:00',0.8,0.0561,'2022-02-08 05:22:56','2023-06-27 21:33:02',0,0,0,0,0),
(803,'XAU','USD',1425.55,1417.55,'2019-07-24','2019-07-24 00:00:00',8,0.5612,'2022-02-08 05:22:57','2023-06-27 21:33:02',0,0,0,0,0),
(804,'XAU','USD',1417.55,1424.45,'2019-07-23','2019-07-23 00:00:00',-6.9,-0.4868,'2022-02-08 05:22:58','2023-06-27 21:33:02',0,0,0,0,0),
(805,'XAU','USD',1424.45,1437.05,'2019-07-22','2019-07-22 00:00:00',-12.6,-0.8846,'2022-02-08 05:22:59','2023-06-27 21:33:02',0,0,0,0,0),
(806,'XAU','USD',1437.05,1420.9,'2019-07-19','2019-07-19 00:00:00',16.15,1.1238,'2022-02-08 05:23:00','2023-06-27 21:33:02',0,0,0,0,0),
(807,'XAU','USD',1420.9,1400.8,'2019-07-18','2019-07-18 00:00:00',20.1,1.4146,'2022-02-08 05:23:02','2023-06-27 21:33:02',0,0,0,0,0),
(808,'XAU','USD',1400.8,1416.1,'2019-07-17','2019-07-17 00:00:00',-15.3,-1.0922,'2022-02-08 05:23:03','2023-06-27 21:33:02',0,0,0,0,0),
(809,'XAU','USD',1416.1,1416.25,'2019-07-16','2019-07-16 00:00:00',-0.15,-0.0106,'2022-02-08 05:23:04','2023-06-27 21:33:02',0,0,0,0,0),
(810,'XAU','USD',1416.25,1405.6,'2019-07-15','2019-07-15 00:00:00',10.65,0.752,'2022-02-08 05:23:05','2023-06-27 21:33:02',0,0,0,0,0),
(811,'XAU','USD',1405.6,1423.1,'2019-07-12','2019-07-12 00:00:00',-17.5,-1.245,'2022-02-08 05:23:07','2023-06-27 21:33:02',0,0,0,0,0),
(812,'XAU','USD',1423.1,1395.45,'2019-07-11','2019-07-11 00:00:00',27.65,1.9429,'2022-02-08 05:23:08','2023-06-27 21:33:02',0,0,0,0,0),
(813,'XAU','USD',1395.45,1387.9,'2019-07-10','2019-07-10 00:00:00',7.55,0.541,'2022-02-08 05:23:09','2023-06-27 21:33:02',0,0,0,0,0),
(814,'XAU','USD',1387.9,1404.9,'2019-07-09','2019-07-09 00:00:00',-17,-1.2249,'2022-02-08 05:23:10','2023-06-27 21:33:02',0,0,0,0,0),
(815,'XAU','USD',1404.9,1414.4,'2019-07-08','2019-07-08 00:00:00',-9.5,-0.6762,'2022-02-08 05:23:11','2023-06-27 21:33:02',0,0,0,0,0),
(816,'XAU','USD',1414.4,1415.25,'2019-07-05','2019-07-05 00:00:00',-0.85,-0.0601,'2022-02-08 05:23:12','2023-06-27 21:33:02',0,0,0,0,0),
(817,'XAU','USD',1415.25,1425.1,'2019-07-04','2019-07-04 00:00:00',-9.85,-0.696,'2022-02-08 05:23:13','2023-06-27 21:33:02',0,0,0,0,0),
(818,'XAU','USD',1425.1,1393.1,'2019-07-03','2019-07-03 00:00:00',32,2.2455,'2022-02-08 05:23:14','2023-06-27 21:33:02',0,0,0,0,0),
(819,'XAU','USD',1393.1,1390.05,'2019-07-02','2019-07-02 00:00:00',3.05,0.2189,'2022-02-08 05:23:14','2023-06-27 21:33:02',0,0,0,0,0),
(820,'XAU','USD',1390.05,1413.2,'2019-07-01','2019-07-01 00:00:00',-23.15,-1.6654,'2022-02-08 05:23:15','2023-06-27 21:33:02',0,0,0,0,0),
(821,'XAU','USD',1413.2,1402.25,'2019-06-28','2019-06-28 00:00:00',10.95,0.7748,'2022-02-08 05:23:17','2023-06-27 21:33:02',0,0,0,0,0),
(822,'XAU','USD',1402.25,1406.75,'2019-06-27','2019-06-27 00:00:00',-4.5,-0.3209,'2022-02-08 05:23:18','2023-06-27 21:33:02',0,0,0,0,0),
(823,'XAU','USD',1406.75,1429.55,'2019-06-26','2019-06-26 00:00:00',-22.8,-1.6208,'2022-02-08 05:23:19','2023-06-27 21:33:02',0,0,0,0,0),
(824,'XAU','USD',1429.55,1405.45,'2019-06-25','2019-06-25 00:00:00',24.1,1.6858,'2022-02-08 05:23:20','2023-06-27 21:33:02',0,0,0,0,0),
(825,'XAU','USD',1405.45,1388.35,'2019-06-24','2019-06-24 00:00:00',17.1,1.2167,'2022-02-08 05:23:22','2023-06-27 21:33:02',0,0,0,0,0),
(826,'XAU','USD',1388.35,1381.65,'2019-06-21','2019-06-21 00:00:00',6.7,0.4826,'2022-02-08 05:23:23','2023-06-27 21:33:02',0,0,0,0,0),
(827,'XAU','USD',1381.65,1342.4,'2019-06-20','2019-06-20 00:00:00',39.25,2.8408,'2022-02-08 05:23:24','2023-06-27 21:33:02',0,0,0,0,0),
(828,'XAU','USD',1342.4,1344.55,'2019-06-19','2019-06-19 00:00:00',-2.15,-0.1602,'2022-02-08 05:23:25','2023-06-27 21:33:02',0,0,0,0,0),
(829,'XAU','USD',1344.55,1333.2,'2019-06-18','2019-06-18 00:00:00',11.35,0.8441,'2022-02-08 05:23:27','2023-06-27 21:33:02',0,0,0,0,0),
(830,'XAU','USD',1333.2,1352.45,'2019-06-17','2019-06-17 00:00:00',-19.25,-1.4439,'2022-02-08 05:23:28','2023-06-27 21:33:02',0,0,0,0,0),
(831,'XAU','USD',1352.45,1335.8,'2019-06-14','2019-06-14 00:00:00',16.65,1.2311,'2022-02-08 05:23:29','2023-06-27 21:33:02',0,0,0,0,0),
(832,'XAU','USD',1335.8,1336.65,'2019-06-13','2019-06-13 00:00:00',-0.85,-0.0636,'2022-02-08 05:23:30','2023-06-27 21:33:02',0,0,0,0,0),
(833,'XAU','USD',1336.65,1322.65,'2019-06-12','2019-06-12 00:00:00',14,1.0474,'2022-02-08 05:23:32','2023-06-27 21:33:02',0,0,0,0,0),
(834,'XAU','USD',1322.65,1328.6,'2019-06-11','2019-06-11 00:00:00',-5.95,-0.4499,'2022-02-08 05:23:33','2023-06-27 21:33:02',0,0,0,0,0),
(835,'XAU','USD',1328.6,1334.3,'2019-06-10','2019-06-10 00:00:00',-5.7,-0.429,'2022-02-08 05:23:34','2023-06-27 21:33:02',0,0,0,0,0),
(836,'XAU','USD',1334.3,1336.65,'2019-06-07','2019-06-07 00:00:00',-2.35,-0.1761,'2022-02-08 05:23:34','2023-06-27 21:33:02',0,0,0,0,0),
(837,'XAU','USD',1336.65,1337.75,'2019-06-06','2019-06-06 00:00:00',-1.1,-0.0823,'2022-02-08 05:23:36','2023-06-27 21:33:02',0,0,0,0,0),
(838,'XAU','USD',1337.75,1323.6,'2019-06-05','2019-06-05 00:00:00',14.15,1.0577,'2022-02-08 05:23:37','2023-06-27 21:33:02',0,0,0,0,0),
(839,'XAU','USD',1323.6,1313.95,'2019-06-04','2019-06-04 00:00:00',9.65,0.7291,'2022-02-08 05:23:38','2023-06-27 21:33:02',0,0,0,0,0),
(840,'XAU','USD',1313.95,1296,'2019-06-03','2019-06-03 00:00:00',17.95,1.3661,'2022-02-08 05:23:39','2023-06-27 21:33:02',0,0,0,0,0),
(841,'XAU','USD',1296,1276.45,'2019-05-31','2019-05-31 00:00:00',19.55,1.5085,'2022-02-08 05:23:41','2023-06-27 21:33:02',0,0,0,0,0),
(842,'XAU','USD',1276.45,1283.5,'2019-05-30','2019-05-30 00:00:00',-7.05,-0.5523,'2022-02-08 05:23:42','2023-06-27 21:33:02',0,0,0,0,0),
(843,'XAU','USD',1283.5,1283.9,'2019-05-29','2019-05-29 00:00:00',-0.4,-0.0312,'2022-02-08 05:23:43','2023-06-27 21:33:02',0,0,0,0,0),
(844,'XAU','USD',1283.9,1281.5,'2019-05-28','2019-05-28 00:00:00',2.4,0.1869,'2022-02-08 05:23:44','2023-06-27 21:33:02',0,0,0,0,0),
(845,'XAU','USD',1281.5,1281.5,'2019-05-27','2019-05-27 00:00:00',0,0,'2022-02-08 05:23:46','2023-06-27 21:33:02',0,0,0,0,0),
(846,'XAU','USD',1281.5,1275.95,'2019-05-24','2019-05-24 00:00:00',5.55,0.4331,'2022-02-08 05:23:47','2023-06-27 21:33:02',0,0,0,0,0),
(847,'XAU','USD',1275.95,1274,'2019-05-23','2019-05-23 00:00:00',1.95,0.1528,'2022-02-08 05:23:48','2023-06-27 21:33:02',0,0,0,0,0),
(848,'XAU','USD',1274,1276,'2019-05-22','2019-05-22 00:00:00',-2,-0.157,'2022-02-08 05:23:49','2023-06-27 21:33:02',0,0,0,0,0),
(849,'XAU','USD',1276,1275.25,'2019-05-21','2019-05-21 00:00:00',0.75,0.0588,'2022-02-08 05:23:50','2023-06-27 21:33:02',0,0,0,0,0),
(850,'XAU','USD',1275.25,1285.8,'2019-05-20','2019-05-20 00:00:00',-10.55,-0.8273,'2022-02-08 05:23:51','2023-06-27 21:33:02',0,0,0,0,0),
(851,'XAU','USD',1285.8,1295.55,'2019-05-17','2019-05-17 00:00:00',-9.75,-0.7583,'2022-02-08 05:23:53','2023-06-27 21:33:02',0,0,0,0,0),
(852,'XAU','USD',1295.55,1298.9,'2019-05-16','2019-05-16 00:00:00',-3.35,-0.2586,'2022-02-08 05:23:54','2023-06-27 21:33:02',0,0,0,0,0),
(853,'XAU','USD',1298.9,1297.6,'2019-05-15','2019-05-15 00:00:00',1.3,0.1001,'2022-02-08 05:23:54','2023-06-27 21:33:02',0,0,0,0,0),
(854,'XAU','USD',1297.6,1282.95,'2019-05-14','2019-05-14 00:00:00',14.65,1.129,'2022-02-08 05:23:56','2023-06-27 21:33:02',0,0,0,0,0),
(855,'XAU','USD',1282.95,1285.4,'2019-05-13','2019-05-13 00:00:00',-2.45,-0.191,'2022-02-08 05:23:57','2023-06-27 21:33:02',0,0,0,0,0),
(856,'XAU','USD',1285.4,1284.1,'2019-05-10','2019-05-10 00:00:00',1.3,0.1011,'2022-02-08 05:23:58','2023-06-27 21:33:02',0,0,0,0,0),
(857,'XAU','USD',1284.1,1287.75,'2019-05-09','2019-05-09 00:00:00',-3.65,-0.2842,'2022-02-08 05:23:59','2023-06-27 21:33:02',0,0,0,0,0),
(858,'XAU','USD',1287.75,1281.3,'2019-05-08','2019-05-08 00:00:00',6.45,0.5009,'2022-02-08 05:24:00','2023-06-27 21:33:02',0,0,0,0,0),
(859,'XAU','USD',1281.3,1270.05,'2019-05-07','2019-05-07 00:00:00',11.25,0.878,'2022-02-08 05:24:02','2023-06-27 21:33:02',0,0,0,0,0),
(860,'XAU','USD',1270.05,1270.05,'2019-05-06','2019-05-06 00:00:00',0,0,'2022-02-08 05:24:03','2023-06-27 21:33:02',0,0,0,0,0),
(861,'XAU','USD',1270.05,1271.45,'2019-05-03','2019-05-03 00:00:00',-1.4,-0.1102,'2022-02-08 05:24:05','2023-06-27 21:33:02',0,0,0,0,0),
(862,'XAU','USD',1271.45,1281.8,'2019-05-02','2019-05-02 00:00:00',-10.35,-0.814,'2022-02-08 05:24:07','2023-06-27 21:33:02',0,0,0,0,0),
(863,'XAU','USD',1281.8,1285.15,'2019-05-01','2019-05-01 00:00:00',-3.35,-0.2614,'2022-02-08 05:24:08','2023-06-27 21:33:02',0,0,0,0,0),
(864,'XAU','USD',1285.15,1282.15,'2019-04-30','2019-04-30 00:00:00',3,0.2334,'2022-02-08 05:24:09','2023-06-27 21:33:02',0,0,0,0,0),
(865,'XAU','USD',1282.15,1281.5,'2019-04-29','2019-04-29 00:00:00',0.65,0.0507,'2022-02-08 05:24:10','2023-06-27 21:33:02',0,0,0,0,0),
(866,'XAU','USD',1281.5,1277.85,'2019-04-26','2019-04-26 00:00:00',3.65,0.2848,'2022-02-08 05:24:12','2023-06-27 21:33:02',0,0,0,0,0),
(867,'XAU','USD',1277.85,1273.8,'2019-04-25','2019-04-25 00:00:00',4.05,0.3169,'2022-02-08 05:24:13','2023-06-27 21:33:02',0,0,0,0,0),
(868,'XAU','USD',1273.8,1273.45,'2019-04-24','2019-04-24 00:00:00',0.35,0.0275,'2022-02-08 05:24:14','2023-06-27 21:33:02',0,0,0,0,0),
(869,'XAU','USD',1273.45,1276.5,'2019-04-23','2019-04-23 00:00:00',-3.05,-0.2395,'2022-02-08 05:24:15','2023-06-27 21:33:02',0,0,0,0,0),
(870,'XAU','USD',1276.5,1276.5,'2019-04-22','2019-04-22 00:00:00',0,0,'2022-02-08 05:24:17','2023-06-27 21:33:02',0,0,0,0,0),
(871,'XAU','USD',1276.5,1276.5,'2019-04-19','2019-04-19 00:00:00',0,0,'2022-02-08 05:24:18','2023-06-27 21:33:02',0,0,0,0,0),
(872,'XAU','USD',1276.5,1276.1,'2019-04-18','2019-04-18 00:00:00',0.4,0.0313,'2022-02-08 05:24:19','2023-06-27 21:33:02',0,0,0,0,0),
(873,'XAU','USD',1276.1,1283.75,'2019-04-17','2019-04-17 00:00:00',-7.65,-0.5995,'2022-02-08 05:24:20','2023-06-27 21:33:02',0,0,0,0,0),
(874,'XAU','USD',1283.75,1286.75,'2019-04-16','2019-04-16 00:00:00',-3,-0.2337,'2022-02-08 05:24:22','2023-06-27 21:33:02',0,0,0,0,0),
(875,'XAU','USD',1286.75,1296.15,'2019-04-15','2019-04-15 00:00:00',-9.4,-0.7305,'2022-02-08 05:24:24','2023-06-27 21:33:02',0,0,0,0,0),
(876,'XAU','USD',1296.15,1304.65,'2019-04-12','2019-04-12 00:00:00',-8.5,-0.6558,'2022-02-08 05:24:24','2023-06-27 21:33:02',0,0,0,0,0),
(877,'XAU','USD',1304.65,1304.8,'2019-04-11','2019-04-11 00:00:00',-0.15,-0.0115,'2022-02-08 05:24:25','2023-06-27 21:33:02',0,0,0,0,0),
(878,'XAU','USD',1304.8,1301.85,'2019-04-10','2019-04-10 00:00:00',2.95,0.2261,'2022-02-08 05:24:27','2023-06-27 21:33:02',0,0,0,0,0),
(879,'XAU','USD',1301.85,1297.1,'2019-04-09','2019-04-09 00:00:00',4.75,0.3649,'2022-02-08 05:24:29','2023-06-27 21:33:02',0,0,0,0,0),
(880,'XAU','USD',1297.1,1288.9,'2019-04-08','2019-04-08 00:00:00',8.2,0.6322,'2022-02-08 05:24:30','2023-06-27 21:33:02',0,0,0,0,0),
(881,'XAU','USD',1288.9,1291.6,'2019-04-05','2019-04-05 00:00:00',-2.7,-0.2095,'2022-02-08 05:24:31','2023-06-27 21:33:02',0,0,0,0,0),
(882,'XAU','USD',1291.6,1291.85,'2019-04-04','2019-04-04 00:00:00',-0.25,-0.0194,'2022-02-08 05:24:32','2023-06-27 21:33:02',0,0,0,0,0),
(883,'XAU','USD',1291.85,1287.2,'2019-04-03','2019-04-03 00:00:00',4.65,0.3599,'2022-02-08 05:24:33','2023-06-27 21:33:02',0,0,0,0,0),
(884,'XAU','USD',1287.2,1291.9,'2019-04-02','2019-04-02 00:00:00',-4.7,-0.3651,'2022-02-08 05:24:34','2023-06-27 21:33:02',0,0,0,0,0),
(885,'XAU','USD',1291.9,1291.15,'2019-04-01','2019-04-01 00:00:00',0.75,0.0581,'2022-02-08 05:24:35','2023-06-27 21:33:02',0,0,0,0,0),
(886,'XAU','USD',1291.15,1306.9,'2019-03-29','2019-03-29 00:00:00',-15.75,-1.2198,'2022-02-08 05:24:37','2023-06-27 21:33:02',0,0,0,0,0),
(887,'XAU','USD',1306.9,1318.25,'2019-03-28','2019-03-28 00:00:00',-11.35,-0.8685,'2022-02-08 05:24:38','2023-06-27 21:33:02',0,0,0,0,0),
(888,'XAU','USD',1318.25,1315.25,'2019-03-27','2019-03-27 00:00:00',3,0.2276,'2022-02-08 05:24:40','2023-06-27 21:33:02',0,0,0,0,0),
(889,'XAU','USD',1315.25,1319.35,'2019-03-26','2019-03-26 00:00:00',-4.1,-0.3117,'2022-02-08 05:24:41','2023-06-27 21:33:02',0,0,0,0,0),
(890,'XAU','USD',1319.35,1311.1,'2019-03-25','2019-03-25 00:00:00',8.25,0.6253,'2022-02-08 05:24:42','2023-06-27 21:33:02',0,0,0,0,0),
(891,'XAU','USD',1311.1,1317.3,'2019-03-22','2019-03-22 00:00:00',-6.2,-0.4729,'2022-02-08 05:24:44','2023-06-27 21:33:02',0,0,0,0,0),
(892,'XAU','USD',1317.3,1303,'2019-03-21','2019-03-21 00:00:00',14.3,1.0856,'2022-02-08 05:24:45','2023-06-27 21:33:02',0,0,0,0,0),
(893,'XAU','USD',1303,1308.35,'2019-03-20','2019-03-20 00:00:00',-5.35,-0.4106,'2022-02-08 05:24:46','2023-06-27 21:33:02',0,0,0,0,0),
(894,'XAU','USD',1308.35,1305.35,'2019-03-19','2019-03-19 00:00:00',3,0.2293,'2022-02-08 05:24:47','2023-06-27 21:33:02',0,0,0,0,0),
(895,'XAU','USD',1305.35,1302.65,'2019-03-18','2019-03-18 00:00:00',2.7,0.2068,'2022-02-08 05:24:48','2023-06-27 21:33:02',0,0,0,0,0),
(896,'XAU','USD',1302.65,1299.2,'2019-03-15','2019-03-15 00:00:00',3.45,0.2648,'2022-02-08 05:24:49','2023-06-27 21:33:02',0,0,0,0,0),
(897,'XAU','USD',1299.2,1308.4,'2019-03-14','2019-03-14 00:00:00',-9.2,-0.7081,'2022-02-08 05:24:51','2023-06-27 21:33:02',0,0,0,0,0),
(898,'XAU','USD',1308.4,1296.95,'2019-03-13','2019-03-13 00:00:00',11.45,0.8751,'2022-02-08 05:24:52','2023-06-27 21:33:02',0,0,0,0,0),
(899,'XAU','USD',1296.95,1296.35,'2019-03-12','2019-03-12 00:00:00',0.6,0.0463,'2022-02-08 05:24:53','2023-06-27 21:33:02',0,0,0,0,0),
(900,'XAU','USD',1296.35,1294.1,'2019-03-11','2019-03-11 00:00:00',2.25,0.1736,'2022-02-08 05:24:54','2023-06-27 21:33:02',0,0,0,0,0),
(901,'XAU','USD',1294.1,1286.4,'2019-03-08','2019-03-08 00:00:00',7.7,0.595,'2022-02-08 05:24:56','2023-06-27 21:33:02',0,0,0,0,0),
(902,'XAU','USD',1286.4,1285.55,'2019-03-07','2019-03-07 00:00:00',0.85,0.0661,'2022-02-08 05:24:57','2023-06-27 21:33:02',0,0,0,0,0),
(903,'XAU','USD',1285.55,1285,'2019-03-06','2019-03-06 00:00:00',0.55,0.0428,'2022-02-08 05:24:59','2023-06-27 21:33:02',0,0,0,0,0),
(904,'XAU','USD',1285,1287.45,'2019-03-05','2019-03-05 00:00:00',-2.45,-0.1907,'2022-02-08 05:25:00','2023-06-27 21:33:02',0,0,0,0,0),
(905,'XAU','USD',1287.45,1309.95,'2019-03-04','2019-03-04 00:00:00',-22.5,-1.7476,'2022-02-08 05:25:01','2023-06-27 21:33:02',0,0,0,0,0),
(906,'XAU','USD',1309.95,1325.45,'2019-03-01','2019-03-01 00:00:00',-15.5,-1.1833,'2022-02-08 05:25:02','2023-06-27 21:33:02',0,0,0,0,0),
(907,'XAU','USD',1325.45,1326.45,'2019-02-28','2019-02-28 00:00:00',-1,-0.0754,'2022-02-08 05:25:03','2023-06-27 21:33:02',0,0,0,0,0),
(908,'XAU','USD',1326.45,1327.55,'2019-02-27','2019-02-27 00:00:00',-1.1,-0.0829,'2022-02-08 05:25:04','2023-06-27 21:33:02',0,0,0,0,0),
(909,'XAU','USD',1327.55,1329.15,'2019-02-26','2019-02-26 00:00:00',-1.6,-0.1205,'2022-02-08 05:25:05','2023-06-27 21:33:02',0,0,0,0,0),
(910,'XAU','USD',1329.15,1322.25,'2019-02-25','2019-02-25 00:00:00',6.9,0.5191,'2022-02-08 05:25:07','2023-06-27 21:33:02',0,0,0,0,0),
(911,'XAU','USD',1322.25,1335.05,'2019-02-22','2019-02-22 00:00:00',-12.8,-0.968,'2022-02-08 05:25:08','2023-06-27 21:33:02',0,0,0,0,0),
(912,'XAU','USD',1335.05,1345.75,'2019-02-21','2019-02-21 00:00:00',-10.7,-0.8015,'2022-02-08 05:25:09','2023-06-27 21:33:02',0,0,0,0,0),
(913,'XAU','USD',1345.75,1329.55,'2019-02-20','2019-02-20 00:00:00',16.2,1.2038,'2022-02-08 05:25:11','2023-06-27 21:33:02',0,0,0,0,0),
(914,'XAU','USD',1329.55,1323.95,'2019-02-19','2019-02-19 00:00:00',5.6,0.4212,'2022-02-08 05:25:12','2023-06-27 21:33:02',0,0,0,0,0),
(915,'XAU','USD',1323.95,1318,'2019-02-18','2019-02-18 00:00:00',5.95,0.4494,'2022-02-08 05:25:14','2023-06-27 21:33:02',0,0,0,0,0),
(916,'XAU','USD',1318,1305.65,'2019-02-15','2019-02-15 00:00:00',12.35,0.937,'2022-02-08 05:25:15','2023-06-27 21:33:02',0,0,0,0,0),
(917,'XAU','USD',1305.65,1311.15,'2019-02-14','2019-02-14 00:00:00',-5.5,-0.4212,'2022-02-08 05:25:16','2023-06-27 21:33:02',0,0,0,0,0),
(918,'XAU','USD',1311.15,1311.6,'2019-02-13','2019-02-13 00:00:00',-0.45,-0.0343,'2022-02-08 05:25:18','2023-06-27 21:33:02',0,0,0,0,0),
(919,'XAU','USD',1311.6,1306.75,'2019-02-12','2019-02-12 00:00:00',4.85,0.3698,'2022-02-08 05:25:19','2023-06-27 21:33:02',0,0,0,0,0),
(920,'XAU','USD',1306.75,1311.1,'2019-02-11','2019-02-11 00:00:00',-4.35,-0.3329,'2022-02-08 05:25:20','2023-06-27 21:33:02',0,0,0,0,0),
(921,'XAU','USD',1311.1,1306.6,'2019-02-08','2019-02-08 00:00:00',4.5,0.3432,'2022-02-08 05:25:21','2023-06-27 21:33:02',0,0,0,0,0),
(922,'XAU','USD',1306.6,1313.35,'2019-02-07','2019-02-07 00:00:00',-6.75,-0.5166,'2022-02-08 05:25:22','2023-06-27 21:33:02',0,0,0,0,0),
(923,'XAU','USD',1313.35,1314,'2019-02-06','2019-02-06 00:00:00',-0.65,-0.0495,'2022-02-08 05:25:23','2023-06-27 21:33:02',0,0,0,0,0),
(924,'XAU','USD',1314,1311,'2019-02-05','2019-02-05 00:00:00',3,0.2283,'2022-02-08 05:25:24','2023-06-27 21:33:02',0,0,0,0,0),
(925,'XAU','USD',1311,1320.75,'2019-02-04','2019-02-04 00:00:00',-9.75,-0.7437,'2022-02-08 05:25:25','2023-06-27 21:33:02',0,0,0,0,0),
(926,'XAU','USD',1320.75,1322.5,'2019-02-01','2019-02-01 00:00:00',-1.75,-0.1325,'2022-02-08 05:25:26','2023-06-27 21:33:02',0,0,0,0,0),
(927,'XAU','USD',1322.5,1312.95,'2019-01-31','2019-01-31 00:00:00',9.55,0.7221,'2022-02-08 05:25:27','2023-06-27 21:33:02',0,0,0,0,0),
(928,'XAU','USD',1312.95,1308.35,'2019-01-30','2019-01-30 00:00:00',4.6,0.3504,'2022-02-08 05:25:28','2023-06-27 21:33:02',0,0,0,0,0),
(929,'XAU','USD',1308.35,1301,'2019-01-29','2019-01-29 00:00:00',7.35,0.5618,'2022-02-08 05:25:29','2023-06-27 21:33:02',0,0,0,0,0),
(930,'XAU','USD',1301,1282.95,'2019-01-28','2019-01-28 00:00:00',18.05,1.3874,'2022-02-08 05:25:30','2023-06-27 21:33:02',0,0,0,0,0),
(931,'XAU','USD',1282.95,1279.75,'2019-01-25','2019-01-25 00:00:00',3.2,0.2494,'2022-02-08 05:25:32','2023-06-27 21:33:02',0,0,0,0,0),
(932,'XAU','USD',1279.75,1284.9,'2019-01-24','2019-01-24 00:00:00',-5.15,-0.4024,'2022-02-08 05:25:33','2023-06-27 21:33:02',0,0,0,0,0),
(933,'XAU','USD',1284.9,1284.75,'2019-01-23','2019-01-23 00:00:00',0.15,0.0117,'2022-02-08 05:25:34','2023-06-27 21:33:02',0,0,0,0,0),
(934,'XAU','USD',1284.75,1278.7,'2019-01-22','2019-01-22 00:00:00',6.05,0.4709,'2022-02-08 05:25:35','2023-06-27 21:33:02',0,0,0,0,0),
(935,'XAU','USD',1278.7,1285.05,'2019-01-21','2019-01-21 00:00:00',-6.35,-0.4966,'2022-02-08 05:25:36','2023-06-27 21:33:02',0,0,0,0,0),
(936,'XAU','USD',1285.05,1294,'2019-01-18','2019-01-18 00:00:00',-8.95,-0.6965,'2022-02-08 05:25:37','2023-06-27 21:33:02',0,0,0,0,0),
(937,'XAU','USD',1294,1290.5,'2019-01-17','2019-01-17 00:00:00',3.5,0.2705,'2022-02-08 05:25:38','2023-06-27 21:33:02',0,0,0,0,0),
(938,'XAU','USD',1290.5,1289.35,'2019-01-16','2019-01-16 00:00:00',1.15,0.0891,'2022-02-08 05:25:40','2023-06-27 21:33:02',0,0,0,0,0),
(939,'XAU','USD',1289.35,1293.7,'2019-01-15','2019-01-15 00:00:00',-4.35,-0.3374,'2022-02-08 05:25:42','2023-06-27 21:33:02',0,0,0,0,0),
(940,'XAU','USD',1293.7,1292.8,'2019-01-14','2019-01-14 00:00:00',0.9,0.0696,'2022-02-08 05:25:42','2023-06-27 21:33:02',0,0,0,0,0),
(941,'XAU','USD',1292.8,1292.4,'2019-01-11','2019-01-11 00:00:00',0.4,0.0309,'2022-02-08 05:25:44','2023-06-27 21:33:02',0,0,0,0,0),
(942,'XAU','USD',1292.4,1281.3,'2019-01-10','2019-01-10 00:00:00',11.1,0.8589,'2022-02-08 05:25:45','2023-06-27 21:33:02',0,0,0,0,0),
(943,'XAU','USD',1281.3,1283.9,'2019-01-09','2019-01-09 00:00:00',-2.6,-0.2029,'2022-02-08 05:25:47','2023-06-27 21:33:02',0,0,0,0,0),
(944,'XAU','USD',1283.9,1291.5,'2019-01-08','2019-01-08 00:00:00',-7.6,-0.5919,'2022-02-08 05:25:48','2023-06-27 21:33:02',0,0,0,0,0),
(945,'XAU','USD',1291.5,1290.35,'2019-01-07','2019-01-07 00:00:00',1.15,0.089,'2022-02-08 05:25:49','2023-06-27 21:33:02',0,0,0,0,0),
(946,'XAU','USD',1290.35,1287.95,'2019-01-04','2019-01-04 00:00:00',2.4,0.186,'2022-02-08 05:25:50','2023-06-27 21:33:02',0,0,0,0,0),
(947,'XAU','USD',1287.95,1287.2,'2019-01-03','2019-01-03 00:00:00',0.75,0.0582,'2022-02-08 05:25:51','2023-06-27 21:33:02',0,0,0,0,0),
(948,'XAU','USD',1287.2,1281.65,'2019-01-02','2019-01-02 00:00:00',5.55,0.4312,'2022-02-08 05:25:53','2023-06-27 21:33:02',0,0,0,0,0),
(949,'XAU','USD',1281.65,1281.65,'2019-01-01','2019-01-01 00:00:00',0,0,'2022-02-08 05:25:54','2023-06-27 21:33:02',0,0,0,0,0),
(950,'XAU','USD',1281.65,1277.25,'2018-12-31','2018-12-31 00:00:00',4.4,0.3433,'2022-02-08 05:25:55','2023-06-27 21:33:02',0,0,0,0,0),
(951,'XAU','USD',1277.25,1271.1,'2018-12-28','2018-12-28 00:00:00',6.15,0.4815,'2022-02-08 05:25:56','2023-06-27 21:33:02',0,0,0,0,0),
(952,'XAU','USD',1271.1,1261.25,'2018-12-27','2018-12-27 00:00:00',9.85,0.7749,'2022-02-08 05:25:57','2023-06-27 21:33:02',0,0,0,0,0),
(953,'XAU','USD',1261.25,1261.25,'2018-12-26','2018-12-26 00:00:00',0,0,'2022-02-08 05:25:58','2023-06-27 21:33:02',0,0,0,0,0),
(954,'XAU','USD',1261.25,1261.25,'2018-12-25','2018-12-25 00:00:00',0,0,'2022-02-08 05:25:59','2023-06-27 21:33:02',0,0,0,0,0),
(955,'XAU','USD',1261.25,1257.6,'2018-12-24','2018-12-24 00:00:00',3.65,0.2894,'2022-02-08 05:26:00','2023-06-27 21:33:02',0,0,0,0,0),
(956,'XAU','USD',1257.6,1255,'2018-12-21','2018-12-21 00:00:00',2.6,0.2067,'2022-02-08 05:26:03','2023-06-27 21:33:02',0,0,0,0,0),
(957,'XAU','USD',1255,1248.6,'2018-12-20','2018-12-20 00:00:00',6.4,0.51,'2022-02-08 05:26:05','2023-06-27 21:33:02',0,0,0,0,0),
(958,'XAU','USD',1248.6,1248.8,'2018-12-19','2018-12-19 00:00:00',-0.2,-0.016,'2022-02-08 05:26:07','2023-06-27 21:33:02',0,0,0,0,0),
(959,'XAU','USD',1248.8,1239.1,'2018-12-18','2018-12-18 00:00:00',9.7,0.7767,'2022-02-08 05:26:09','2023-06-27 21:33:02',0,0,0,0,0),
(960,'XAU','USD',1239.1,1239.15,'2018-12-17','2018-12-17 00:00:00',-0.05,-0.004,'2022-02-08 05:26:11','2023-06-27 21:33:02',0,0,0,0,0),
(961,'XAU','USD',1239.15,1244.45,'2018-12-14','2018-12-14 00:00:00',-5.3,-0.4277,'2022-02-08 05:26:13','2023-06-27 21:33:02',0,0,0,0,0),
(962,'XAU','USD',1244.45,1244.75,'2018-12-13','2018-12-13 00:00:00',-0.3,-0.0241,'2022-02-08 05:26:15','2023-06-27 21:33:02',0,0,0,0,0),
(963,'XAU','USD',1244.75,1248.25,'2018-12-12','2018-12-12 00:00:00',-3.5,-0.2812,'2022-02-08 05:26:17','2023-06-27 21:33:02',0,0,0,0,0),
(964,'XAU','USD',1248.25,1246.8,'2018-12-11','2018-12-11 00:00:00',1.45,0.1162,'2022-02-08 05:26:18','2023-06-27 21:33:02',0,0,0,0,0),
(965,'XAU','USD',1246.8,1241.2,'2018-12-10','2018-12-10 00:00:00',5.6,0.4491,'2022-02-08 05:26:20','2023-06-27 21:33:02',0,0,0,0,0),
(966,'XAU','USD',1241.2,1236.45,'2018-12-07','2018-12-07 00:00:00',4.75,0.3827,'2022-02-08 05:26:22','2023-06-27 21:33:02',0,0,0,0,0),
(967,'XAU','USD',1236.45,1236.15,'2018-12-06','2018-12-06 00:00:00',0.3,0.0243,'2022-02-08 05:26:24','2023-06-27 21:33:02',0,0,0,0,0),
(968,'XAU','USD',1811.15,1814.55,'2022-02-07','2022-02-07 00:00:00',-3.4,-0.1877,'2022-02-08 07:00:10','2023-06-27 21:33:02',58.2298,53.3773,50.9511,48.5249,43.6724),
(969,'XAU','USD',1821,1811.15,'2022-02-08','2022-02-08 00:00:00',9.85,0.5409,'2022-02-09 07:00:15','2023-06-27 21:33:02',58.5465,53.6676,51.2282,48.7888,43.9099),
(970,'XAU','USD',1828.1,1821,'2022-02-09','2022-02-09 00:00:00',7.1,0.3884,'2022-02-10 07:00:13','2023-06-27 21:33:02',58.7748,53.8769,51.4279,48.979,44.0811),
(971,'XAU','USD',1832.3,1828.1,'2022-02-10','2022-02-10 00:00:00',4.2,0.2292,'2022-02-11 07:00:16','2023-06-27 21:33:02',58.9098,54.0007,51.5461,49.0915,44.1824),
(972,'XAU','USD',1826.25,1832.3,'2022-02-11','2022-02-11 00:00:00',-6.05,-0.3313,'2022-02-12 07:00:09','2023-06-27 21:33:02',58.7153,53.8224,51.3759,48.9294,44.0365),
(973,'XAU','USD',1855.8,1826.25,'2022-02-14','2022-02-14 00:00:00',29.55,1.5923,'2022-02-15 07:00:23','2023-06-27 21:33:02',59.6654,54.6932,52.2072,49.7211,44.749),
(974,'XAU','USD',1855.1,1855.8,'2022-02-15','2022-02-15 00:00:00',-0.7,-0.0377,'2022-02-16 07:00:10','2023-06-27 21:33:02',59.6428,54.6726,52.1875,49.7024,44.7321),
(975,'XAU','USD',1854.4,1855.1,'2022-02-16','2022-02-16 00:00:00',-0.7,-0.0377,'2022-02-17 07:00:14','2023-06-27 21:33:02',59.6203,54.652,52.1678,49.6836,44.7153),
(976,'XAU','USD',1886.55,1854.4,'2022-02-17','2022-02-17 00:00:00',32.15,1.7042,'2022-02-18 07:00:12','2023-06-27 21:33:02',60.654,55.5995,53.0722,50.545,45.4905),
(977,'XAU','USD',1886.95,1886.55,'2022-02-18','2022-02-18 00:00:00',0.4,0.0212,'2022-02-19 07:00:06','2023-06-27 21:33:02',60.6669,55.6113,53.0835,50.5557,45.5001),
(978,'XAU','USD',2007,1999.25,'2022-03-08','2022-03-08 00:00:00',7.75,0.3861,'2022-03-09 07:00:08','2023-06-27 21:33:02',64.5265,59.1493,56.4607,53.7721,48.3949),
(979,'XAU','USD',1961.6,1991.45,'2022-03-14','2022-03-14 00:00:00',-29.85,-1.5217,'2022-03-15 07:00:06','2023-06-27 21:33:02',63.0669,57.8113,55.1835,52.5558,47.3002),
(980,'XAU','USD',1956.65,1945.9,'2022-03-25','2022-03-25 00:00:00',10.75,0.5494,'2022-03-26 07:00:05','2023-06-27 21:33:02',62.9078,57.6654,55.0443,52.4231,47.1808),
(981,'XAU','USD',1927,1956.65,'2022-03-28','2022-03-28 00:00:00',-29.65,-1.5387,'2022-03-29 07:00:13','2023-06-27 21:33:02',61.9545,56.7916,54.2102,51.6287,46.4659),
(982,'XAU','USD',1911.05,1927,'2022-03-29','2022-03-29 00:00:00',-15.95,-0.8346,'2022-03-30 07:00:19','2023-06-27 21:33:02',61.4417,56.3215,53.7615,51.2014,46.0813),
(983,'XAU','USD',1917.8,1911.05,'2022-03-30','2022-03-30 00:00:00',6.75,0.352,'2022-03-31 07:00:11','2023-06-27 21:33:02',61.6587,56.5205,53.9514,51.3823,46.244),
(984,'XAU','USD',1924.1,1917.8,'2022-03-31','2022-03-31 00:00:00',6.3,0.3274,'2022-04-01 07:00:10','2023-06-27 21:33:02',61.8613,56.7061,54.1286,51.551,46.3959),
(985,'XAU','USD',1933.35,1924.1,'2022-04-01','2022-04-01 00:00:00',9.25,0.4784,'2022-04-02 07:00:11','2023-06-27 21:33:02',62.1586,56.9788,54.3888,51.7989,46.619),
(986,'XAU','USD',1927.1,1933.35,'2022-04-04','2022-04-04 00:00:00',-6.25,-0.3243,'2022-04-05 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(987,'XAU','USD',1927.1,1927.1,'2022-04-05','2022-04-05 00:00:00',0,0,'2022-04-06 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(988,'XAU','USD',1927.1,1927.1,'2022-04-06','2022-04-06 00:00:00',0,0,'2022-04-07 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(989,'XAU','USD',1927.1,1927.1,'2022-04-07','2022-04-07 00:00:00',0,0,'2022-04-08 07:00:06','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(990,'XAU','USD',1927.1,1927.1,'2022-04-08','2022-04-08 00:00:00',0,0,'2022-04-09 07:00:07','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(991,'XAU','USD',1927.1,1927.1,'2022-04-11','2022-04-11 00:00:00',0,0,'2022-04-12 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(992,'XAU','USD',1927.1,1927.1,'2022-04-18','2022-04-18 00:00:00',0,0,'2022-04-19 07:00:07','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(993,'XAU','USD',1927.1,1927.1,'2022-04-26','2022-04-26 00:00:00',0,0,'2022-04-27 07:00:18','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(994,'XAU','USD',1927.1,1927.1,'2022-04-27','2022-04-27 00:00:00',0,0,'2022-04-28 07:00:16','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(995,'XAU','USD',1927.1,1927.1,'2022-04-28','2022-04-28 00:00:00',0,0,'2022-04-29 07:00:14','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(996,'XAU','USD',1927.1,1927.1,'2022-04-29','2022-04-29 00:00:00',0,0,'2022-04-30 07:00:07','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(997,'XAU','USD',1927.1,1927.1,'2022-05-02','2022-05-02 00:00:00',0,0,'2022-05-03 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(998,'XAU','USD',1927.1,1927.1,'2022-05-03','2022-05-03 00:00:00',0,0,'2022-05-04 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(999,'XAU','USD',1927.1,1927.1,'2022-05-04','2022-05-04 00:00:00',0,0,'2022-05-05 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1000,'XAU','USD',1927.1,1927.1,'2022-05-05','2022-05-05 00:00:00',0,0,'2022-05-06 07:00:16','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1001,'XAU','USD',1927.1,1927.1,'2022-05-06','2022-05-06 00:00:00',0,0,'2022-05-07 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1002,'XAU','USD',1927.1,1927.1,'2022-05-09','2022-05-09 00:00:00',0,0,'2022-05-10 07:00:13','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1003,'XAU','USD',1927.1,1927.1,'2022-05-10','2022-05-10 00:00:00',0,0,'2022-05-11 07:00:17','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1004,'XAU','USD',1927.1,1927.1,'2022-05-11','2022-05-11 00:00:00',0,0,'2022-05-12 07:00:14','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1005,'XAU','USD',1927.1,1927.1,'2022-05-12','2022-05-12 00:00:00',0,0,'2022-05-13 07:00:11','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1006,'XAU','USD',1927.1,1927.1,'2022-05-13','2022-05-13 00:00:00',0,0,'2022-05-14 07:00:16','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1007,'XAU','USD',1927.1,1927.1,'2022-05-16','2022-05-16 00:00:00',0,0,'2022-05-17 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1008,'XAU','USD',1927.1,1927.1,'2022-05-17','2022-05-17 00:00:00',0,0,'2022-05-18 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1009,'XAU','USD',1927.1,1927.1,'2022-05-18','2022-05-18 00:00:00',0,0,'2022-05-19 07:00:11','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1010,'XAU','USD',1927.1,1927.1,'2022-05-19','2022-05-19 00:00:00',0,0,'2022-05-20 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1011,'XAU','USD',1927.1,1927.1,'2022-05-20','2022-05-20 00:00:00',0,0,'2022-05-21 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1012,'XAU','USD',1927.1,1927.1,'2022-05-23','2022-05-23 00:00:00',0,0,'2022-05-24 07:00:11','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1013,'XAU','USD',1927.1,1927.1,'2022-05-24','2022-05-24 00:00:00',0,0,'2022-05-25 07:00:13','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1014,'XAU','USD',1927.1,1927.1,'2022-05-25','2022-05-25 00:00:00',0,0,'2022-05-26 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1015,'XAU','USD',1927.1,1927.1,'2022-05-26','2022-05-26 00:00:00',0,0,'2022-05-27 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1016,'XAU','USD',1927.1,1927.1,'2022-05-27','2022-05-27 00:00:00',0,0,'2022-05-28 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1017,'XAU','USD',1927.1,1927.1,'2022-05-30','2022-05-30 00:00:00',0,0,'2022-05-31 07:00:08','2023-06-27 21:33:02',0,0,0,0,0),
(1018,'XAU','USD',1927.1,1927.1,'2022-05-31','2022-05-31 00:00:00',0,0,'2022-06-01 07:00:09','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1019,'XAU','USD',1927.1,1927.1,'2022-06-01','2022-06-01 00:00:00',0,0,'2022-06-02 07:00:15','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1020,'XAU','USD',1927.1,1927.1,'2022-06-02','2022-06-02 00:00:00',0,0,'2022-06-03 07:00:11','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1021,'XAU','USD',1927.1,1927.1,'2022-06-03','2022-06-03 00:00:00',0,0,'2022-06-04 07:00:05','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1022,'XAU','USD',1927.1,1927.1,'2022-06-06','2022-06-06 00:00:00',0,0,'2022-06-07 07:00:10','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1023,'XAU','USD',1927.1,1927.1,'2022-06-07','2022-06-07 00:00:00',0,0,'2022-06-08 07:00:12','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1024,'XAU','USD',1927.1,1927.1,'2022-06-08','2022-06-08 00:00:00',0,0,'2022-06-09 07:00:14','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1025,'XAU','USD',1849.25,1927.1,'2022-06-09','2022-06-09 00:00:00',-77.85,-4.2098,'2022-06-10 07:00:10','2023-06-27 21:33:02',59.4548,54.5002,52.0229,49.5456,44.5911),
(1026,'XAU','USD',1843.35,1849.25,'2022-06-10','2022-06-10 00:00:00',-5.9,-0.3201,'2022-06-11 07:00:09','2023-06-27 21:33:02',59.2651,54.3263,51.8569,49.3876,44.4488),
(1027,'XAU','USD',1855.95,1843.35,'2022-06-13','2022-06-13 00:00:00',12.6,0.6789,'2022-06-14 07:00:14','2023-06-27 21:33:02',59.6702,54.6977,52.2114,49.7251,44.7526),
(1028,'XAU','USD',1823.65,1855.95,'2022-06-14','2022-06-14 00:00:00',-32.3,-1.7712,'2022-06-15 07:00:24','2023-06-27 21:33:02',58.6317,53.7457,51.3027,48.8598,43.9738),
(1029,'XAU','USD',1823.15,1823.65,'2022-06-15','2022-06-15 00:00:00',-0.5,-0.0274,'2022-06-16 07:00:09','2023-06-27 21:33:02',58.6156,53.731,51.2887,48.8464,43.9617),
(1030,'XAU','USD',1831.55,1823.15,'2022-06-16','2022-06-16 00:00:00',8.4,0.4586,'2022-06-17 07:00:14','2023-06-27 21:33:02',58.8857,53.9786,51.525,49.0714,44.1643),
(1031,'XAU','USD',1841.2,1849.85,'2022-06-20','2022-06-20 00:00:00',-8.65,-0.4698,'2022-06-21 07:00:13','2023-06-27 21:33:02',0,0,0,0,0),
(1032,'XAU','USD',1836.5,1841.2,'2022-06-21','2022-06-21 00:00:00',-4.7,-0.2559,'2022-06-22 07:00:15','2023-06-27 21:33:02',59.0448,54.1244,51.6642,49.204,44.2836),
(1033,'XAU','USD',1827.3,1836.5,'2022-06-22','2022-06-22 00:00:00',-9.2,-0.5035,'2022-06-23 07:00:19','2023-06-27 21:33:02',58.7491,53.8533,51.4054,48.9575,44.0618),
(1034,'XAU','USD',1831.4,1827.3,'2022-06-23','2022-06-23 00:00:00',4.1,0.2239,'2022-06-24 07:00:20','2023-06-27 21:33:02',58.8809,53.9741,51.5208,49.0674,44.1607),
(1035,'XAU','USD',1826.5,1831.4,'2022-06-24','2022-06-24 00:00:00',-4.9,-0.2683,'2022-06-25 07:00:08','2023-06-27 21:33:02',58.7233,53.8297,51.3829,48.9361,44.0425),
(1036,'XAU','USD',1838.05,1826.5,'2022-06-27','2022-06-27 00:00:00',11.55,0.6284,'2022-06-28 07:00:20','2023-06-27 21:33:02',59.0947,54.1701,51.7078,49.2456,44.321),
(1037,'XAU','USD',1827,1838.05,'2022-06-28','2022-06-28 00:00:00',-11.05,-0.6048,'2022-06-29 07:00:13','2023-06-27 21:33:02',58.7394,53.8445,51.397,48.9495,44.0546),
(1038,'XAU','USD',1811.85,1827,'2022-06-29','2022-06-29 00:00:00',-15.15,-0.8362,'2022-06-30 07:00:23','2023-06-27 21:33:02',58.2523,53.398,50.9708,48.5436,43.6892),
(1039,'XAU','USD',1813.6,1811.85,'2022-06-30','2022-06-30 00:00:00',1.75,0.0965,'2022-07-01 07:00:20','2023-06-27 21:33:02',58.3086,53.4495,51.02,48.5905,43.7314),
(1040,'XAU','USD',1795.65,1813.6,'2022-07-01','2022-07-01 00:00:00',-17.95,-0.9996,'2022-07-02 07:00:08','2023-06-27 21:33:02',57.7315,52.9205,50.5151,48.1096,43.2986),
(1041,'XAU','USD',1766.65,1804.4,'2022-07-06','2022-07-06 00:00:00',-37.75,-2.1368,'2022-07-07 07:00:18','2023-06-27 21:33:02',56.7991,52.0659,49.6992,47.3326,42.5993),
(1042,'XAU','USD',1743.45,1766.65,'2022-07-07','2022-07-07 00:00:00',-23.2,-1.3307,'2022-07-08 07:00:09','2023-06-27 21:33:02',56.0532,51.3821,49.0466,46.711,42.0399),
(1043,'XAU','USD',1737.05,1743.45,'2022-07-08','2022-07-08 00:00:00',-6.4,-0.3684,'2022-07-09 07:00:11','2023-06-27 21:33:02',55.8475,51.1935,48.8665,46.5395,41.8856),
(1044,'XAU','USD',1737.4,1737.05,'2022-07-11','2022-07-11 00:00:00',0.35,0.0201,'2022-07-12 07:00:25','2023-06-27 21:33:02',55.8587,51.2038,48.8764,46.5489,41.894),
(1045,'XAU','USD',1734.35,1737.4,'2022-07-12','2022-07-12 00:00:00',-3.05,-0.1759,'2022-07-13 07:00:16','2023-06-27 21:33:02',55.7606,51.1139,48.7906,46.4672,41.8205),
(1046,'XAU','USD',1728.9,1734.35,'2022-07-13','2022-07-13 00:00:00',-5.45,-0.3152,'2022-07-14 07:00:09','2023-06-27 21:33:02',55.5854,50.9533,48.6372,46.3212,41.6891),
(1047,'XAU','USD',1716.15,1728.9,'2022-07-14','2022-07-14 00:00:00',-12.75,-0.7429,'2022-07-15 07:00:08','2023-06-27 21:33:02',55.1755,50.5775,48.2786,45.9796,41.3816),
(1048,'XAU','USD',1702.55,1716.15,'2022-07-15','2022-07-15 00:00:00',-13.6,-0.7988,'2022-07-16 07:00:05','2023-06-27 21:33:02',54.7383,50.1767,47.896,45.6152,41.0537),
(1049,'XAU','USD',1723.65,1702.55,'2022-07-18','2022-07-18 00:00:00',21.1,1.2241,'2022-07-19 07:00:08','2023-06-27 21:33:02',55.4166,50.7986,48.4896,46.1805,41.5625),
(1050,'XAU','USD',1712.95,1723.65,'2022-07-19','2022-07-19 00:00:00',-10.7,-0.6247,'2022-07-20 07:00:19','2023-06-27 21:33:02',55.0726,50.4832,48.1885,45.8939,41.3045),
(1051,'XAU','USD',1712.65,1712.95,'2022-07-20','2022-07-20 00:00:00',-0.3,-0.0175,'2022-07-21 07:00:08','2023-06-27 21:33:02',55.063,50.4744,48.1801,45.8858,41.2972),
(1052,'XAU','USD',1686.55,1712.65,'2022-07-21','2022-07-21 00:00:00',-26.1,-1.5475,'2022-07-22 07:00:15','2023-06-27 21:33:02',54.2238,49.7052,47.4459,45.1865,40.6679),
(1053,'XAU','USD',1725,1686.55,'2022-07-22','2022-07-22 00:00:00',38.45,2.229,'2022-07-23 07:00:07','2023-06-27 21:33:02',55.46,50.8384,48.5275,46.2167,41.595),
(1054,'XAU','USD',1731.95,1725,'2022-07-25','2022-07-25 00:00:00',6.95,0.4013,'2022-07-26 07:00:11','2023-06-27 21:33:02',55.6835,51.0432,48.723,46.4029,41.7626),
(1055,'XAU','USD',1719.85,1731.95,'2022-07-26','2022-07-26 00:00:00',-12.1,-0.7035,'2022-07-27 07:00:12','2023-06-27 21:33:02',55.2945,50.6866,48.3827,46.0787,41.4708),
(1056,'XAU','USD',1723.95,1719.85,'2022-07-27','2022-07-27 00:00:00',4.1,0.2378,'2022-07-28 07:00:19','2023-06-27 21:33:02',55.4263,50.8074,48.498,46.1886,41.5697),
(1057,'XAU','USD',1746.6,1723.95,'2022-07-28','2022-07-28 00:00:00',22.65,1.2968,'2022-07-29 07:00:12','2023-06-27 21:33:02',56.1545,51.475,49.1352,46.7954,42.1159),
(1058,'XAU','USD',1766.75,1758.9,'2022-08-01','2022-08-01 00:00:00',7.85,0.4443,'2022-08-02 07:00:16','2023-06-27 21:33:02',56.8023,52.0688,49.702,47.3353,42.6017),
(1059,'XAU','USD',1772.9,1766.75,'2022-08-02','2022-08-02 00:00:00',6.15,0.3469,'2022-08-03 07:00:08','2023-06-27 21:33:02',57.0001,52.2501,49.8751,47.5,42.75),
(1060,'XAU','USD',1766.6,1772.9,'2022-08-03','2022-08-03 00:00:00',-6.3,-0.3566,'2022-08-04 07:00:10','2023-06-27 21:33:02',56.7975,52.0644,49.6978,47.3313,42.5981),
(1061,'XAU','USD',1777.9,1766.6,'2022-08-04','2022-08-04 00:00:00',11.3,0.6356,'2022-08-05 07:00:10','2023-06-27 21:33:02',57.1608,52.3974,50.0157,47.634,42.8706),
(1062,'XAU','USD',1786.75,1777.9,'2022-08-05','2022-08-05 00:00:00',8.85,0.4953,'2022-08-06 07:00:06','2023-06-27 21:33:02',57.4453,52.6582,50.2647,47.8711,43.084),
(1063,'XAU','USD',1775.7,1786.75,'2022-08-08','2022-08-08 00:00:00',-11.05,-0.6223,'2022-08-09 07:00:17','2023-06-27 21:33:02',57.0901,52.3326,49.9538,47.5751,42.8176),
(1064,'XAU','USD',1790.6,1775.7,'2022-08-09','2022-08-09 00:00:00',14.9,0.8321,'2022-08-10 07:00:15','2023-06-27 21:33:02',57.5691,52.7717,50.373,47.9743,43.1768),
(1065,'XAU','USD',1793.5,1790.6,'2022-08-10','2022-08-10 00:00:00',2.9,0.1617,'2022-08-11 07:00:11','2023-06-27 21:33:02',57.6624,52.8572,50.4546,48.052,43.2468),
(1066,'XAU','USD',1789.7,1793.5,'2022-08-11','2022-08-11 00:00:00',-3.8,-0.2123,'2022-08-12 07:00:11','2023-06-27 21:33:02',57.5402,52.7452,50.3477,47.9502,43.1551),
(1067,'XAU','USD',1788.45,1789.7,'2022-08-12','2022-08-12 00:00:00',-1.25,-0.0699,'2022-08-13 07:00:10','2023-06-27 21:33:02',57.5,52.7083,50.3125,47.9167,43.125),
(1068,'XAU','USD',1781.45,1788.45,'2022-08-15','2022-08-15 00:00:00',-7,-0.3929,'2022-08-16 07:00:15','2023-06-27 21:33:02',57.2749,52.502,50.1156,47.7291,42.9562),
(1069,'XAU','USD',1776.15,1781.45,'2022-08-16','2022-08-16 00:00:00',-5.3,-0.2984,'2022-08-17 07:00:14','2023-06-27 21:33:02',57.1045,52.3458,49.9665,47.5871,42.8284),
(1070,'XAU','USD',1776.15,1776.15,'2022-08-17','2022-08-17 00:00:00',0,0,'2022-08-18 07:00:09','2023-06-27 21:33:02',57.1045,52.3458,49.9665,47.5871,42.8284),
(1071,'XAU','USD',1765.6,1776.15,'2022-08-18','2022-08-18 00:00:00',-10.55,-0.5975,'2022-08-19 07:00:10','2023-06-27 21:33:02',56.7654,52.0349,49.6697,47.3045,42.574),
(1072,'XAU','USD',1752.9,1765.6,'2022-08-19','2022-08-19 00:00:00',-12.7,-0.7245,'2022-08-20 07:00:13','2023-06-27 21:33:02',56.357,51.6606,49.3124,46.9642,42.2678),
(1073,'XAU','USD',1732.8,1752.9,'2022-08-22','2022-08-22 00:00:00',-20.1,-1.16,'2022-08-23 07:00:11','2023-06-27 21:33:02',55.7108,51.0682,48.747,46.4257,41.7831),
(1074,'XAU','USD',1739.45,1732.8,'2022-08-23','2022-08-23 00:00:00',6.65,0.3823,'2022-08-24 07:00:12','2023-06-27 21:33:02',55.9246,51.2642,48.934,46.6038,41.9435),
(1075,'XAU','USD',1752,1739.45,'2022-08-24','2022-08-24 00:00:00',12.55,0.7163,'2022-08-25 07:00:18','2023-06-27 21:33:02',56.3281,51.6341,49.2871,46.9401,42.2461),
(1076,'XAU','USD',1762.4,1752,'2022-08-25','2022-08-25 00:00:00',10.4,0.5901,'2022-08-26 07:00:19','2023-06-27 21:33:02',56.6625,51.9406,49.5797,47.2187,42.4969),
(1077,'XAU','USD',1752.1,1762.4,'2022-08-26','2022-08-26 00:00:00',-10.3,-0.5879,'2022-08-27 07:00:13','2023-06-27 21:33:02',56.3313,51.637,49.2899,46.9428,42.2485),
(1078,'XAU','USD',1752.1,1752.1,'2022-08-29','2022-08-29 00:00:00',0,0,'2022-08-30 07:00:09','2023-06-27 21:33:02',56.3313,51.637,49.2899,46.9428,42.2485),
(1079,'XAU','USD',1734,1752.1,'2022-08-30','2022-08-30 00:00:00',-18.1,-1.0438,'2022-08-31 07:00:13','2023-06-27 21:33:02',55.7494,51.1036,48.7807,46.4578,41.812),
(1080,'XAU','USD',1712.4,1734,'2022-08-31','2022-08-31 00:00:00',-21.6,-1.2614,'2022-09-01 07:00:16','2023-06-27 21:33:02',55.0549,50.467,48.1731,45.8791,41.2912),
(1081,'XAU','USD',1706,1712.4,'2022-09-01','2022-09-01 00:00:00',-6.4,-0.3751,'2022-09-02 07:00:13','2023-06-27 21:33:02',54.8492,50.2784,47.993,45.7076,41.1369),
(1082,'XAU','USD',1706.9,1706,'2022-09-02','2022-09-02 00:00:00',0.9,0.0527,'2022-09-03 07:00:12','2023-06-27 21:33:02',54.8781,50.3049,48.0183,45.7318,41.1586),
(1083,'XAU','USD',1711.95,1706.9,'2022-09-05','2022-09-05 00:00:00',5.05,0.295,'2022-09-06 07:00:18','2023-06-27 21:33:02',0,0,0,0,0),
(1084,'XAU','USD',1712.5,1711.95,'2022-09-06','2022-09-06 00:00:00',0.55,0.0321,'2022-09-07 07:00:15','2023-06-27 21:33:02',55.0582,50.47,48.1759,45.8818,41.2936),
(1085,'XAU','USD',1705.05,1712.5,'2022-09-07','2022-09-07 00:00:00',-7.45,-0.4369,'2022-09-08 07:00:21','2023-06-27 21:33:02',54.8186,50.2504,47.9663,45.6822,41.114),
(1086,'XAU','USD',1705.05,1705.05,'2022-09-08','2022-09-08 00:00:00',0,0,'2022-09-09 07:00:13','2023-06-27 21:33:02',54.8186,50.2504,47.9663,45.6822,41.114),
(1087,'XAU','USD',1726.95,1705.05,'2022-09-09','2022-09-09 00:00:00',21.9,1.2681,'2022-09-10 07:00:10','2023-06-27 21:33:02',55.5227,50.8958,48.5824,46.2689,41.642),
(1088,'XAU','USD',1726.5,1726.95,'2022-09-12','2022-09-12 00:00:00',-0.45,-0.0261,'2022-09-13 07:00:14','2023-06-27 21:33:02',55.5083,50.8826,48.5697,46.2569,41.6312),
(1089,'XAU','USD',1727.05,1726.5,'2022-09-13','2022-09-13 00:00:00',0.55,0.0318,'2022-09-14 07:00:15','2023-06-27 21:33:02',55.5259,50.8988,48.5852,46.2716,41.6445),
(1090,'XAU','USD',1703.8,1727.05,'2022-09-14','2022-09-14 00:00:00',-23.25,-1.3646,'2022-09-15 07:00:11','2023-06-27 21:33:02',54.7784,50.2136,47.9311,45.6487,41.0838),
(1091,'XAU','USD',1689,1703.8,'2022-09-15','2022-09-15 00:00:00',-14.8,-0.8763,'2022-09-16 07:00:22','2023-06-27 21:33:02',54.3026,49.7774,47.5148,45.2522,40.727),
(1092,'XAU','USD',1664.3,1689,'2022-09-16','2022-09-16 00:00:00',-24.7,-1.4841,'2022-09-17 07:00:13','2023-06-27 21:33:02',53.5085,49.0494,46.8199,44.5904,40.1314),
(1093,'XAU','USD',1664.3,1664.3,'2022-09-19','2022-09-19 00:00:00',0,0,'2022-09-20 07:00:14','2023-06-27 21:33:02',53.5085,49.0494,46.8199,44.5904,40.1314),
(1094,'XAU','USD',1667.9,1664.3,'2022-09-20','2022-09-20 00:00:00',3.6,0.2158,'2022-09-21 07:00:19','2023-06-27 21:33:02',53.6242,49.1555,46.9212,44.6869,40.2182),
(1095,'XAU','USD',1674.45,1667.9,'2022-09-21','2022-09-21 00:00:00',6.55,0.3912,'2022-09-22 07:00:14','2023-06-27 21:33:02',53.8348,49.3486,47.1055,44.8623,40.3761),
(1096,'XAU','USD',1671.85,1674.45,'2022-09-22','2022-09-22 00:00:00',-2.6,-0.1555,'2022-09-23 07:00:14','2023-06-27 21:33:02',53.7512,49.272,47.0323,44.7927,40.3134),
(1097,'XAU','USD',1661.45,1671.85,'2022-09-23','2022-09-23 00:00:00',-10.4,-0.626,'2022-09-24 07:00:12','2023-06-27 21:33:02',53.4169,48.9655,46.7398,44.514,40.0626),
(1098,'XAU','USD',1647,1661.45,'2022-09-26','2022-09-26 00:00:00',-14.45,-0.8774,'2022-09-27 07:00:13','2023-06-27 21:33:02',52.9523,48.5396,46.3332,44.1269,39.7142),
(1099,'XAU','USD',1632.6,1647,'2022-09-27','2022-09-27 00:00:00',-14.4,-0.882,'2022-09-28 07:00:19','2023-06-27 21:33:02',52.4893,48.1152,45.9281,43.7411,39.367),
(1100,'XAU','USD',1618.2,1632.6,'2022-09-28','2022-09-28 00:00:00',-14.4,-0.8899,'2022-09-29 07:00:19','2023-06-27 21:33:02',52.0263,47.6908,45.523,43.3553,39.0198),
(1101,'XAU','USD',1646.6,1618.2,'2022-09-29','2022-09-29 00:00:00',28.4,1.7248,'2022-09-30 07:00:17','2023-06-27 21:33:02',52.9394,48.5278,46.322,44.1162,39.7046),
(1102,'XAU','USD',1663.3,1670.8,'2022-10-27','2022-10-27 00:00:00',-7.5,-0.4509,'2022-10-28 13:03:01','2023-06-27 21:33:02',53.4763,49.02,46.7918,44.5636,40.1073),
(1103,'XAU','USD',1670.8,1642.85,'2022-10-26','2022-10-26 00:00:00',27.95,1.6729,'2022-10-28 13:03:22','2023-06-27 21:33:02',53.7175,49.241,47.0028,44.7646,40.2881),
(1104,'XAU','USD',1642.85,1646.35,'2022-10-25','2022-10-25 00:00:00',-3.5,-0.213,'2022-10-28 13:03:45','2023-06-27 21:33:02',52.8189,48.4173,46.2165,44.0157,39.6141),
(1105,'XAU','USD',1646.35,1624.55,'2022-10-24','2022-10-24 00:00:00',21.8,1.3241,'2022-10-28 13:04:07','2023-06-27 21:33:02',52.9314,48.5204,46.315,44.1095,39.6985),
(1106,'XAU','USD',1624.55,1633.2,'2022-10-21','2022-10-21 00:00:00',-8.65,-0.5325,'2022-10-28 13:04:28','2023-06-27 21:33:02',52.2305,47.878,45.7017,43.5254,39.1729),
(1107,'XAU','USD',1633.2,1640.7,'2022-10-20','2022-10-20 00:00:00',-7.5,-0.4592,'2022-10-28 13:04:56','2023-06-27 21:33:02',52.5086,48.1329,45.945,43.7572,39.3814),
(1108,'XAU','USD',1640.7,1652.25,'2022-10-19','2022-10-19 00:00:00',-11.55,-0.704,'2022-10-28 13:05:24','2023-06-27 21:33:02',52.7497,48.3539,46.156,43.9581,39.5623),
(1109,'XAU','USD',1652.25,1655.15,'2022-10-18','2022-10-18 00:00:00',-2.9,-0.1755,'2022-10-28 13:05:53','2023-06-27 21:33:02',53.1211,48.6943,46.4809,44.2676,39.8408),
(1110,'XAU','USD',1655.15,1655.15,'2022-10-17','2022-10-17 00:00:00',0,0,'2022-10-28 13:06:23','2023-06-27 21:33:02',53.2143,48.7798,46.5625,44.3453,39.9107),
(1111,'XAU','USD',1655.15,1676.4,'2022-10-14','2022-10-14 00:00:00',-21.25,-1.2839,'2022-10-28 13:06:46','2023-06-27 21:33:02',53.2143,48.7798,46.5625,44.3453,39.9107),
(1112,'XAU','USD',1676.4,1672.3,'2022-10-13','2022-10-13 00:00:00',4.1,0.2446,'2022-10-28 13:07:11','2023-06-27 21:33:02',53.8975,49.4061,47.1603,44.9146,40.4231),
(1113,'XAU','USD',1672.3,1664.15,'2022-10-12','2022-10-12 00:00:00',8.15,0.4874,'2022-10-28 13:07:35','2023-06-27 21:33:02',53.7657,49.2852,47.045,44.8047,40.3243),
(1114,'XAU','USD',1664.15,1680.05,'2022-10-11','2022-10-11 00:00:00',-15.9,-0.9554,'2022-10-28 13:08:00','2023-06-27 21:33:02',53.5037,49.045,46.8157,44.5864,40.1277),
(1115,'XAU','USD',1680.05,1711.5,'2022-10-10','2022-10-10 00:00:00',-31.45,-1.872,'2022-10-28 13:08:25','2023-06-27 21:33:02',0,0,0,0,0),
(1116,'XAU','USD',1711.5,1716,'2022-10-07','2022-10-07 00:00:00',-4.5,-0.2629,'2022-10-28 13:08:49','2023-06-27 21:33:02',55.026,50.4405,48.1478,45.855,41.2695),
(1117,'XAU','USD',1716,1712.15,'2022-10-06','2022-10-06 00:00:00',3.85,0.2244,'2022-10-28 13:09:16','2023-06-27 21:33:02',55.1707,50.5731,48.2743,45.9756,41.378),
(1118,'XAU','USD',1712.15,1709.15,'2022-10-05','2022-10-05 00:00:00',3,0.1752,'2022-10-28 13:09:45','2023-06-27 21:33:02',55.0469,50.4597,48.166,45.8724,41.2852),
(1119,'XAU','USD',1709.15,1660.8,'2022-10-04','2022-10-04 00:00:00',48.35,2.8289,'2022-10-28 13:10:13','2023-06-27 21:33:02',54.9504,50.3712,48.0816,45.792,41.2128),
(1120,'XAU','USD',1660.8,1672.75,'2022-10-03','2022-10-03 00:00:00',-11.95,-0.7195,'2022-10-28 13:10:42','2023-06-27 21:33:02',53.396,48.9463,46.7215,44.4966,40.047),
(1121,'XAU','USD',1672.75,1646.6,'2022-09-30','2022-09-30 00:00:00',26.15,1.5633,'2022-10-28 13:36:42','2023-06-27 21:33:02',53.7802,49.2985,47.0576,44.8168,40.3351),
(1122,'XAU','USD',1649.25,1663.3,'2022-10-28','2022-10-28 00:00:00',-14.05,-0.8519,'2022-10-29 07:00:11','2023-06-27 21:33:02',53.0246,48.6059,46.3965,44.1872,39.7685),
(1123,'XAU','USD',1638.85,1649.25,'2022-10-31','2022-10-31 00:00:00',-10.4,-0.6346,'2022-11-01 07:00:11','2023-06-27 21:33:02',52.6903,48.2994,46.104,43.9085,39.5177),
(1124,'XAU','USD',1834.5,1850.25,'2023-01-06','2023-01-06 00:00:00',-15.75,-0.8585,'2023-01-08 10:17:17','2023-06-27 21:33:02',58.9805,54.0655,51.608,49.1505,44.2354),
(1125,'XAU','USD',1850.25,1857.55,'2023-01-05','2023-01-05 00:00:00',-7.3,-0.3945,'2023-01-08 10:17:18','2023-06-27 21:33:02',59.4869,54.5297,52.0511,49.5724,44.6152),
(1126,'XAU','USD',1857.55,1835.05,'2023-01-04','2023-01-04 00:00:00',22.5,1.2113,'2023-01-08 10:17:19','2023-06-27 21:33:02',59.7216,54.7448,52.2564,49.768,44.7912),
(1127,'XAU','USD',1835.05,1805.4,'2023-01-03','2023-01-03 00:00:00',29.65,1.6158,'2023-01-08 10:17:20','2023-06-27 21:33:02',58.9982,54.0817,51.6234,49.1652,44.2487),
(1128,'XAU','USD',1805.4,1805.4,'2023-01-02','2023-01-02 00:00:00',0,0,'2023-01-08 10:17:21','2023-06-27 21:33:02',0,0,0,0,0),
(1129,'XAU','USD',1805.4,1805.4,'2022-12-30','2022-12-30 00:00:00',0,0,'2023-01-08 10:17:22','2023-06-27 21:33:02',58.045,53.2079,50.7893,48.3708,43.5337),
(1130,'XAU','USD',1805.4,1802.65,'2022-12-29','2022-12-29 00:00:00',2.75,0.1523,'2023-01-08 10:17:23','2023-06-27 21:33:02',58.045,53.2079,50.7893,48.3708,43.5337),
(1131,'XAU','USD',1802.65,1815.2,'2022-12-28','2022-12-28 00:00:00',-12.55,-0.6962,'2023-01-08 10:17:24','2023-06-27 21:33:02',57.9565,53.1268,50.712,48.2971,43.4674),
(1132,'XAU','USD',1815.2,1815.2,'2022-12-27','2022-12-27 00:00:00',0,0,'2023-01-08 10:17:26','2023-06-27 21:33:02',58.36,53.4967,51.065,48.6334,43.77),
(1133,'XAU','USD',1815.2,1815.2,'2022-12-26','2022-12-26 00:00:00',0,0,'2023-01-08 10:17:27','2023-06-27 21:33:02',0,0,0,0,0),
(1134,'XAU','USD',1815.2,1815.2,'2022-12-23','2022-12-23 00:00:00',0,0,'2023-01-08 10:17:28','2023-06-27 21:33:02',58.36,53.4967,51.065,48.6334,43.77),
(1135,'XAU','USD',1815.2,1813.5,'2022-12-22','2022-12-22 00:00:00',1.7,0.0937,'2023-01-08 10:17:29','2023-06-27 21:33:02',58.36,53.4967,51.065,48.6334,43.77),
(1136,'XAU','USD',1813.5,1806.35,'2022-12-21','2022-12-21 00:00:00',7.15,0.3943,'2023-01-08 10:17:30','2023-06-27 21:33:02',58.3054,53.4466,51.0172,48.5878,43.729),
(1137,'XAU','USD',1806.35,1796.5,'2022-12-20','2022-12-20 00:00:00',9.85,0.5453,'2023-01-08 10:17:31','2023-06-27 21:33:02',58.0755,53.2359,50.8161,48.3963,43.5566),
(1138,'XAU','USD',1796.5,1780.15,'2022-12-19','2022-12-19 00:00:00',16.35,0.9101,'2023-01-08 10:17:32','2023-06-27 21:33:02',57.7588,52.9456,50.539,48.1323,43.3191),
(1139,'XAU','USD',1780.15,1775.95,'2022-12-16','2022-12-16 00:00:00',4.2,0.2359,'2023-01-08 10:17:33','2023-06-27 21:33:02',57.2332,52.4637,50.079,47.6943,42.9249),
(1140,'XAU','USD',1775.95,1785.15,'2022-12-15','2022-12-15 00:00:00',-9.2,-0.518,'2023-01-08 10:17:34','2023-06-27 21:33:02',57.0981,52.3399,49.9609,47.5818,42.8236),
(1141,'XAU','USD',1785.15,1785.15,'2022-12-14','2022-12-14 00:00:00',0,0,'2023-01-08 10:17:35','2023-06-27 21:33:02',57.3939,52.6111,50.2197,47.8283,43.0454),
(1142,'XAU','USD',1785.15,1790.6,'2022-12-13','2022-12-13 00:00:00',-5.45,-0.3053,'2023-01-08 10:17:36','2023-06-27 21:33:02',57.3939,52.6111,50.2197,47.8283,43.0454),
(1143,'XAU','USD',1790.6,1793,'2022-12-12','2022-12-12 00:00:00',-2.4,-0.134,'2023-01-08 10:17:37','2023-06-27 21:33:02',57.5691,52.7717,50.373,47.9743,43.1768),
(1144,'XAU','USD',1793,1782.45,'2022-12-09','2022-12-09 00:00:00',10.55,0.5884,'2023-01-08 10:17:39','2023-06-27 21:33:02',57.6463,52.8424,50.4405,48.0386,43.2347),
(1145,'XAU','USD',1782.45,1771.85,'2022-12-08','2022-12-08 00:00:00',10.6,0.5947,'2023-01-08 10:17:40','2023-06-27 21:33:02',57.3071,52.5315,50.1437,47.7559,42.9803),
(1146,'XAU','USD',1771.85,1773.35,'2022-12-07','2022-12-07 00:00:00',-1.5,-0.0847,'2023-01-08 10:17:41','2023-06-27 21:33:02',56.9663,52.2191,49.8455,47.4719,42.7247),
(1147,'XAU','USD',1773.35,1794.35,'2022-12-06','2022-12-06 00:00:00',-21,-1.1842,'2023-01-08 10:17:42','2023-06-27 21:33:02',57.0145,52.2633,49.8877,47.5121,42.7609),
(1148,'XAU','USD',1794.35,1800.75,'2022-12-05','2022-12-05 00:00:00',-6.4,-0.3567,'2023-01-08 10:17:43','2023-06-27 21:33:02',57.6897,52.8822,50.4785,48.0747,43.2673),
(1149,'XAU','USD',1800.75,1779.6,'2022-12-02','2022-12-02 00:00:00',21.15,1.1745,'2023-01-08 10:17:44','2023-06-27 21:33:02',57.8955,53.0708,50.6585,48.2462,43.4216),
(1150,'XAU','USD',1779.6,1759.65,'2022-12-01','2022-12-01 00:00:00',19.95,1.121,'2023-01-08 10:17:45','2023-06-27 21:33:02',57.2155,52.4475,50.0635,47.6796,42.9116),
(1151,'XAU','USD',1759.65,1755.35,'2022-11-30','2022-11-30 00:00:00',4.3,0.2444,'2023-01-08 10:17:46','2023-06-27 21:33:02',56.5741,51.8596,49.5023,47.1451,42.4305),
(1152,'XAU','USD',1755.35,1762.9,'2022-11-29','2022-11-29 00:00:00',-7.55,-0.4301,'2023-01-08 10:17:47','2023-06-27 21:33:02',56.4358,51.7328,49.3813,47.0298,42.3269),
(1153,'XAU','USD',1762.9,1753.55,'2022-11-28','2022-11-28 00:00:00',9.35,0.5304,'2023-01-08 10:17:48','2023-06-27 21:33:02',56.6786,51.9553,49.5937,47.2321,42.5089),
(1154,'XAU','USD',1753.55,1755.25,'2022-11-25','2022-11-25 00:00:00',-1.7,-0.0969,'2023-01-08 10:17:49','2023-06-27 21:33:02',56.3779,51.6798,49.3307,46.9816,42.2835),
(1155,'XAU','USD',1755.25,1735.75,'2022-11-24','2022-11-24 00:00:00',19.5,1.111,'2023-01-08 10:17:50','2023-06-27 21:33:02',0,0,0,0,0),
(1156,'XAU','USD',1735.75,1747,'2022-11-23','2022-11-23 00:00:00',-11.25,-0.6481,'2023-01-08 10:17:51','2023-06-27 21:33:02',55.8057,51.1552,48.83,46.5047,41.8542),
(1157,'XAU','USD',1747,1739.65,'2022-11-22','2022-11-22 00:00:00',7.35,0.4207,'2023-01-08 10:17:52','2023-06-27 21:33:02',56.1674,51.4867,49.1464,46.8061,42.1255),
(1158,'XAU','USD',1739.65,1764.75,'2022-11-21','2022-11-21 00:00:00',-25.1,-1.4428,'2023-01-08 10:17:53','2023-06-27 21:33:02',55.931,51.2701,48.9397,46.6092,41.9483),
(1159,'XAU','USD',1764.75,1764.55,'2022-11-18','2022-11-18 00:00:00',0.2,0.0113,'2023-01-08 10:17:54','2023-06-27 21:33:02',56.738,52.0099,49.6458,47.2817,42.5535),
(1160,'XAU','USD',1764.55,1783.2,'2022-11-17','2022-11-17 00:00:00',-18.65,-1.0569,'2023-01-08 10:17:55','2023-06-27 21:33:02',56.7316,52.004,49.6401,47.2763,42.5487),
(1161,'XAU','USD',1783.2,1775.1,'2022-11-16','2022-11-16 00:00:00',8.1,0.4542,'2023-01-08 10:17:56','2023-06-27 21:33:02',57.3312,52.5536,50.1648,47.776,42.9984),
(1162,'XAU','USD',1775.1,1757.35,'2022-11-15','2022-11-15 00:00:00',17.75,0.9999,'2023-01-08 10:17:57','2023-06-27 21:33:02',57.0708,52.3149,49.9369,47.559,42.8031),
(1163,'XAU','USD',1757.35,1764.75,'2022-11-14','2022-11-14 00:00:00',-7.4,-0.4211,'2023-01-08 10:17:58','2023-06-27 21:33:02',56.5001,51.7918,49.4376,47.0834,42.3751),
(1164,'XAU','USD',1764.75,1705.65,'2022-11-11','2022-11-11 00:00:00',59.1,3.3489,'2023-01-08 10:17:59','2023-06-27 21:33:02',0,0,0,0,0),
(1165,'XAU','USD',1705.65,1705.15,'2022-11-10','2022-11-10 00:00:00',0.5,0.0293,'2023-01-08 10:18:00','2023-06-27 21:33:02',54.8379,50.2681,47.9832,45.6983,41.1284),
(1166,'XAU','USD',1705.15,1670.8,'2022-11-09','2022-11-09 00:00:00',34.35,2.0145,'2023-01-08 10:18:02','2023-06-27 21:33:02',54.8218,50.2534,47.9691,45.6849,41.1164),
(1167,'XAU','USD',1670.8,1679.9,'2022-11-08','2022-11-08 00:00:00',-9.1,-0.5446,'2023-01-08 10:18:03','2023-06-27 21:33:02',53.7175,49.241,47.0028,44.7646,40.2881),
(1168,'XAU','USD',1679.9,1648.8,'2022-11-07','2022-11-07 00:00:00',31.1,1.8513,'2023-01-08 10:18:04','2023-06-27 21:33:02',54.01,49.5092,47.2588,45.0084,40.5075),
(1169,'XAU','USD',1648.8,1620.65,'2022-11-04','2022-11-04 00:00:00',28.15,1.7073,'2023-01-08 10:18:04','2023-06-27 21:33:02',53.0102,48.5926,46.3839,44.1751,39.7576),
(1170,'XAU','USD',1620.65,1656.45,'2022-11-03','2022-11-03 00:00:00',-35.8,-2.209,'2023-01-08 10:18:05','2023-06-27 21:33:02',52.1051,47.763,45.592,43.4209,39.0788),
(1171,'XAU','USD',1656.45,1652.55,'2022-11-02','2022-11-02 00:00:00',3.9,0.2354,'2023-01-08 10:18:06','2023-06-27 21:33:02',53.2561,48.8181,46.5991,44.3801,39.9421),
(1172,'XAU','USD',1652.55,1638.85,'2022-11-01','2022-11-01 00:00:00',13.7,0.829,'2023-01-08 10:18:07','2023-06-27 21:33:02',53.1307,48.7032,46.4894,44.2756,39.848),
(1173,'XAU','USD',1873.8,1834.5,'2023-01-09','2023-01-09 00:00:00',39.3,2.0973,'2023-01-10 07:00:03','2023-06-27 21:33:02',60.2441,55.2237,52.7136,50.2034,45.1831),
(1174,'XAU','USD',1875.2,1873.8,'2023-01-10','2023-01-10 00:00:00',1.4,0.0747,'2023-01-11 07:00:03','2023-06-27 21:33:02',60.2891,55.265,52.7529,50.2409,45.2168),
(1175,'XAU','USD',1884.25,1875.2,'2023-01-11','2023-01-11 00:00:00',9.05,0.4803,'2023-01-12 07:00:11','2023-06-27 21:33:02',60.58,55.5317,53.0075,50.4834,45.435),
(1176,'XAU','USD',1883.1,1884.25,'2023-01-12','2023-01-12 00:00:00',-1.15,-0.0611,'2023-01-13 07:00:03','2023-06-27 21:33:02',60.5431,55.4978,52.9752,50.4526,45.4073),
(1177,'XAU','USD',1904.05,1883.1,'2023-01-13','2023-01-13 00:00:00',20.95,1.1003,'2023-01-14 07:00:02','2023-06-27 21:33:02',61.2166,56.1152,53.5646,51.0139,45.9125),
(1178,'XAU','USD',1915.1,1904.05,'2023-01-16','2023-01-16 00:00:00',11.05,0.577,'2023-01-17 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(1179,'XAU','USD',1904.95,1915.1,'2023-01-17','2023-01-17 00:00:00',-10.15,-0.5328,'2023-01-18 07:00:03','2023-06-27 21:33:02',61.2456,56.1418,53.5899,51.038,45.9342),
(1180,'XAU','USD',1911.55,1904.95,'2023-01-18','2023-01-18 00:00:00',6.6,0.3453,'2023-01-19 07:00:02','2023-06-27 21:33:02',61.4578,56.3363,53.7755,51.2148,46.0933),
(1181,'XAU','USD',1907.5,1911.55,'2023-01-19','2023-01-19 00:00:00',-4.05,-0.2123,'2023-01-20 07:00:11','2023-06-27 21:33:02',61.3275,56.2169,53.6616,51.1063,45.9957),
(1182,'XAU','USD',1928.75,1907.5,'2023-01-20','2023-01-20 00:00:00',21.25,1.1017,'2023-01-21 07:00:07','2023-06-27 21:33:02',62.0108,56.8432,54.2594,51.6756,46.5081),
(1183,'XAU','USD',1927.2,1928.75,'2023-01-23','2023-01-23 00:00:00',-1.55,-0.0804,'2023-01-24 07:00:08','2023-06-27 21:33:02',61.9609,56.7975,54.2158,51.6341,46.4707),
(1184,'XAU','USD',1936.5,1927.2,'2023-01-24','2023-01-24 00:00:00',9.3,0.4802,'2023-01-25 07:00:11','2023-06-27 21:33:02',62.2599,57.0716,54.4774,51.8833,46.6949),
(1185,'XAU','USD',1925.85,1936.5,'2023-01-25','2023-01-25 00:00:00',-10.65,-0.553,'2023-01-26 07:00:10','2023-06-27 21:33:02',61.9175,56.7577,54.1778,51.5979,46.4381),
(1186,'XAU','USD',1936.45,1925.85,'2023-01-26','2023-01-26 00:00:00',10.6,0.5474,'2023-01-27 07:00:03','2023-06-27 21:33:02',62.2583,57.0701,54.476,51.8819,46.6937),
(1187,'XAU','USD',1928.25,1936.45,'2023-01-27','2023-01-27 00:00:00',-8.2,-0.4253,'2023-01-28 07:00:03','2023-06-27 21:33:02',61.9947,56.8285,54.2453,51.6622,46.496),
(1188,'XAU','USD',1926.75,1928.25,'2023-01-30','2023-01-30 00:00:00',-1.5,-0.0779,'2023-01-31 07:00:03','2023-06-27 21:33:02',61.9465,56.7842,54.2031,51.622,46.4598),
(1189,'XAU','USD',1905.2,1926.75,'2023-01-31','2023-01-31 00:00:00',-21.55,-1.1311,'2023-02-01 07:00:03','2023-06-27 21:33:02',61.2536,56.1491,53.5969,51.0447,45.9402),
(1190,'XAU','USD',1925.6,1905.2,'2023-02-01','2023-02-01 00:00:00',20.4,1.0594,'2023-02-02 07:00:02','2023-06-27 21:33:02',61.9095,56.7504,54.1708,51.5912,46.4321),
(1191,'XAU','USD',1954.9,1925.6,'2023-02-02','2023-02-02 00:00:00',29.3,1.4988,'2023-02-03 07:00:03','2023-06-27 21:33:02',62.8515,57.6139,54.9951,52.3762,47.1386),
(1192,'XAU','USD',1873.5,1910,'2023-02-06','2023-02-06 00:00:00',-36.5,-1.9482,'2023-02-07 07:00:03','2023-06-27 21:33:02',60.2344,55.2149,52.7051,50.1954,45.1758),
(1193,'XAU','USD',1873.8,1873.5,'2023-02-07','2023-02-07 00:00:00',0.3,0.016,'2023-02-08 07:00:07','2023-06-27 21:33:02',60.2441,55.2237,52.7136,50.2034,45.1831),
(1194,'XAU','USD',1880.75,1873.8,'2023-02-08','2023-02-08 00:00:00',6.95,0.3695,'2023-02-09 07:00:02','2023-06-27 21:33:02',60.4675,55.4286,52.9091,50.3896,45.3506),
(1195,'XAU','USD',1882.1,1880.75,'2023-02-09','2023-02-09 00:00:00',1.35,0.0717,'2023-02-10 07:00:03','2023-06-27 21:33:02',60.5109,55.4683,52.9471,50.4258,45.3832),
(1196,'XAU','USD',1864.1,1882.1,'2023-02-10','2023-02-10 00:00:00',-18,-0.9656,'2023-02-11 07:00:03','2023-06-27 21:33:02',59.9322,54.9379,52.4407,49.9435,44.9492),
(1197,'XAU','USD',1858.5,1864.1,'2023-02-13','2023-02-13 00:00:00',-5.6,-0.3013,'2023-02-14 07:00:06','2023-06-27 21:33:02',59.7522,54.7728,52.2831,49.7935,44.8141),
(1198,'XAU','USD',1860.5,1858.5,'2023-02-14','2023-02-14 00:00:00',2,0.1075,'2023-02-15 07:00:04','2023-06-27 21:33:02',59.8165,54.8318,52.3394,49.8471,44.8623),
(1199,'XAU','USD',1835.45,1860.5,'2023-02-15','2023-02-15 00:00:00',-25.05,-1.3648,'2023-02-16 07:00:11','2023-06-27 21:33:02',59.0111,54.0935,51.6347,49.1759,44.2583),
(1200,'XAU','USD',1837.3,1835.45,'2023-02-16','2023-02-16 00:00:00',1.85,0.1007,'2023-02-17 07:00:04','2023-06-27 21:33:02',59.0706,54.148,51.6867,49.2255,44.3029),
(1201,'XAU','USD',1824.5,1837.3,'2023-02-17','2023-02-17 00:00:00',-12.8,-0.7016,'2023-02-18 07:00:08','2023-06-27 21:33:02',58.659,53.7708,51.3267,48.8825,43.9943),
(1202,'XAU','USD',1844.2,1824.5,'2023-02-20','2023-02-20 00:00:00',19.7,1.0682,'2023-02-21 07:00:04','2023-06-27 21:33:02',0,0,0,0,0),
(1203,'XAU','USD',1833.2,1844.2,'2023-02-21','2023-02-21 00:00:00',-11,-0.6,'2023-02-22 07:00:03','2023-06-27 21:33:02',58.9387,54.0272,51.5714,49.1156,44.2041),
(1204,'XAU','USD',1833.45,1833.2,'2023-02-22','2023-02-22 00:00:00',0.25,0.0136,'2023-02-23 07:00:02','2023-06-27 21:33:02',58.9468,54.0346,51.5784,49.1223,44.2101),
(1205,'XAU','USD',1826.95,1833.45,'2023-02-23','2023-02-23 00:00:00',-6.5,-0.3558,'2023-02-24 07:00:02','2023-06-27 21:33:02',58.7378,53.843,51.3956,48.9482,44.0534),
(1206,'XAU','USD',1809.05,1824.1,'2023-02-27','2023-02-27 00:00:00',-15.05,-0.8319,'2023-02-28 07:00:02','2023-06-27 21:33:02',58.1623,53.3154,50.892,48.4686,43.6217),
(1207,'XAU','USD',1810.2,1809.05,'2023-02-28','2023-02-28 00:00:00',1.15,0.0635,'2023-03-01 07:00:03','2023-06-27 21:33:02',58.1993,53.3493,50.9244,48.4994,43.6495),
(1208,'XAU','USD',1833.5,1810.2,'2023-03-01','2023-03-01 00:00:00',23.3,1.2708,'2023-03-02 07:00:02','2023-06-27 21:33:02',58.9484,54.036,51.5798,49.1237,44.2113),
(1209,'XAU','USD',1831.75,1833.5,'2023-03-02','2023-03-02 00:00:00',-1.75,-0.0955,'2023-03-03 07:00:03','2023-06-27 21:33:02',58.8921,53.9845,51.5306,49.0768,44.1691),
(1210,'XAU','USD',1845.55,1831.75,'2023-03-03','2023-03-03 00:00:00',13.8,0.7477,'2023-03-04 07:00:03','2023-06-27 21:33:02',59.3358,54.3912,51.9188,49.4465,44.5019),
(1211,'XAU','USD',1851.7,1845.55,'2023-03-06','2023-03-06 00:00:00',6.15,0.3321,'2023-03-07 07:00:02','2023-06-27 21:33:02',0,0,0,0,0),
(1212,'XAU','USD',1843.05,1851.7,'2023-03-07','2023-03-07 00:00:00',-8.65,-0.4693,'2023-03-08 07:00:03','2023-06-27 21:33:02',0,0,0,0,0),
(1213,'XAU','USD',1813.35,1843.05,'2023-03-08','2023-03-08 00:00:00',-29.7,-1.6379,'2023-03-09 07:00:02','2023-06-27 21:33:02',58.3006,53.4422,51.013,48.5838,43.7254),
(1214,'XAU','USD',1817.5,1813.35,'2023-03-09','2023-03-09 00:00:00',4.15,0.2283,'2023-03-10 07:00:03','2023-06-27 21:33:02',58.434,53.5645,51.1297,48.695,43.8255),
(1215,'XAU','USD',1834.95,1817.5,'2023-03-10','2023-03-10 00:00:00',17.45,0.951,'2023-03-11 07:00:03','2023-06-27 21:33:02',58.995,54.0788,51.6206,49.1625,44.2463),
(1216,'XAU','USD',1882.1,1834.95,'2023-03-13','2023-03-13 00:00:00',47.15,2.5052,'2023-03-14 07:00:03','2023-06-27 21:33:02',60.5109,55.4683,52.9471,50.4258,45.3832),
(1217,'XAU','USD',1901.45,1882.1,'2023-03-14','2023-03-14 00:00:00',19.35,1.0176,'2023-03-15 07:00:03','2023-06-27 21:33:02',61.133,56.0386,53.4914,50.9442,45.8498),
(1218,'XAU','USD',1906,1901.45,'2023-03-15','2023-03-15 00:00:00',4.55,0.2387,'2023-03-16 07:00:03','2023-06-27 21:33:02',61.2793,56.1727,53.6194,51.0661,45.9595),
(1219,'XAU','USD',1919.4,1906,'2023-03-16','2023-03-16 00:00:00',13.4,0.6981,'2023-03-17 07:00:03','2023-06-27 21:33:02',61.7101,56.5676,53.9964,51.4251,46.2826),
(1220,'XAU','USD',1930.9,1919.4,'2023-03-17','2023-03-17 00:00:00',11.5,0.5956,'2023-03-18 07:00:03','2023-06-27 21:33:02',62.0799,56.9066,54.3199,51.7332,46.5599),
(1221,'XAU','USD',1981.95,1930.9,'2023-03-20','2023-03-20 00:00:00',51.05,2.5757,'2023-03-21 07:00:04','2023-06-27 21:33:02',63.7212,58.4111,55.756,53.101,47.7909),
(1222,'XAU','USD',1965.95,1981.95,'2023-03-21','2023-03-21 00:00:00',-16,-0.8139,'2023-03-22 07:00:04','2023-06-27 21:33:02',63.2068,57.9395,55.3059,52.6723,47.4051),
(1223,'XAU','USD',1941.85,1965.95,'2023-03-22','2023-03-22 00:00:00',-24.1,-1.2411,'2023-03-23 07:00:03','2023-06-27 21:33:02',62.4319,57.2293,54.6279,52.0266,46.8239),
(1224,'XAU','USD',1977.55,1941.85,'2023-03-23','2023-03-23 00:00:00',35.7,1.8053,'2023-03-24 07:00:03','2023-06-27 21:33:02',63.5797,58.2814,55.6322,52.9831,47.6848),
(1225,'XAU','USD',1996.15,1977.55,'2023-03-24','2023-03-24 00:00:00',18.6,0.9318,'2023-03-25 07:00:03','2023-06-27 21:33:02',64.1777,58.8296,56.1555,53.4814,48.1333),
(1226,'XAU','USD',1960.25,1996.15,'2023-03-27','2023-03-27 00:00:00',-35.9,-1.8314,'2023-03-28 07:00:07','2023-06-27 21:33:02',63.0235,57.7715,55.1456,52.5196,47.2676),
(1227,'XAU','USD',1949.85,1960.25,'2023-03-28','2023-03-28 00:00:00',-10.4,-0.5334,'2023-03-29 07:00:07','2023-06-27 21:33:02',62.6891,57.465,54.853,52.2409,47.0168),
(1228,'XAU','USD',1965.85,1949.85,'2023-03-29','2023-03-29 00:00:00',16,0.8139,'2023-03-30 07:00:08','2023-06-27 21:33:02',63.2035,57.9366,55.3031,52.6696,47.4027),
(1229,'XAU','USD',1968.1,1965.85,'2023-03-30','2023-03-30 00:00:00',2.25,0.1143,'2023-03-31 07:00:07','2023-06-27 21:33:02',63.2759,58.0029,55.3664,52.7299,47.4569),
(1230,'XAU','USD',1978.8,1968.1,'2023-03-31','2023-03-31 00:00:00',10.7,0.5407,'2023-04-01 07:00:07','2023-06-27 21:33:02',63.6199,58.3182,55.6674,53.0166,47.7149),
(1231,'XAU','USD',1963.1,1978.8,'2023-04-03','2023-04-03 00:00:00',-15.7,-0.7998,'2023-04-04 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(1232,'XAU','USD',2022.3,1982.25,'2023-04-05','2023-04-05 00:00:00',40.05,1.9804,'2023-04-06 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(1233,'XAU','USD',2017.25,2022.3,'2023-04-06','2023-04-06 00:00:00',-5.05,-0.2503,'2023-04-07 07:00:08','2023-06-27 21:33:02',0,0,0,0,0),
(1234,'XAU','USD',2017.25,2017.25,'2023-04-07','2023-04-07 00:00:00',0,0,'2023-04-08 07:00:07','2023-06-27 21:33:02',0,0,0,0,0),
(1235,'XAU','USD',2017.25,2017.25,'2023-04-10','2023-04-10 00:00:00',0,0,'2023-04-11 07:00:08','2023-06-27 21:33:02',64.8561,59.4514,56.7491,54.0467,48.6421),
(1248,'XAU','USD',2001.5,2017.25,'2023-04-11','2023-04-11 00:00:00',-15.75,-0.7869,'2023-04-12 07:00:08','2023-06-27 21:33:02',64.3497,58.9872,56.306,53.6248,48.2623),
(1249,'XAU','USD',2008.9,2001.5,'2023-04-12','2023-04-12 00:00:00',7.4,0.3684,'2023-04-13 09:31:27','2023-06-27 21:33:02',64.5876,59.2053,56.5142,53.823,48.4407),
(1250,'XAU','USD',2027.1,2008.9,'2023-04-13','2023-04-13 00:00:00',18.2,0.8978,'2023-04-18 07:46:25','2023-06-27 21:33:02',65.1728,59.7417,57.0262,54.3106,48.8796),
(1251,'XAU','USD',2035.65,2027.1,'2023-04-14','2023-04-14 00:00:00',8.55,0.42,'2023-04-18 07:46:31','2023-06-27 21:33:02',65.4477,59.9937,57.2667,54.5397,49.0858),
(1254,'XAU','USD',2009.8,2035.65,'2023-04-17','2023-04-17 00:00:00',-25.85,-1.2862,'2023-04-18 07:46:38','2023-06-27 21:33:02',64.6166,59.2319,56.5395,53.8471,48.4624),
(1260,'XAU','USD',1999.3,2009.8,'2023-04-18','2023-04-18 00:00:00',-10.5,-0.5252,'2023-04-23 19:52:05','2023-06-27 21:33:02',64.279,58.9224,56.2441,53.5658,48.2092),
(1261,'XAU','USD',1976.1,1999.3,'2023-04-19','2023-04-19 00:00:00',-23.2,-1.174,'2023-04-23 19:52:06','2023-06-27 21:33:02',63.5331,58.2387,55.5915,52.9442,47.6498),
(1262,'XAU','USD',1994.05,1976.1,'2023-04-20','2023-04-20 00:00:00',17.95,0.9002,'2023-04-23 19:52:12','2023-06-27 21:33:02',64.1102,58.7677,56.0964,53.4252,48.0826),
(1263,'XAU','USD',1986.1,1994.05,'2023-04-21','2023-04-21 00:00:00',-7.95,-0.4003,'2023-04-23 19:52:18','2023-06-27 21:33:02',63.8546,58.5334,55.8728,53.2122,47.8909),
(1264,'XAU','USD',1927.1,1927.1,'2022-04-19','2022-04-19 00:00:00',0,0,'2023-04-23 19:53:36','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1265,'XAU','USD',1927.1,1927.1,'2022-04-20','2022-04-20 00:00:00',0,0,'2023-04-23 19:53:37','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1266,'XAU','USD',1927.1,1927.1,'2022-04-21','2022-04-21 00:00:00',0,0,'2023-04-23 19:53:39','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1267,'XAU','USD',1927.1,1927.1,'2022-04-22','2022-04-22 00:00:00',0,0,'2023-04-23 19:53:45','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1268,'XAU','USD',1986.15,1986.1,'2023-04-24','2023-04-24 00:00:00',0.05,0.0025,'2023-04-25 07:07:10','2023-06-27 21:33:02',63.8562,58.5349,55.8742,53.2135,47.8922),
(1269,'XAU','USD',1927.1,1927.1,'2022-04-25','2022-04-25 00:00:00',0,0,'2023-04-25 07:09:34','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1270,'XAU','USD',1990.2,1986.15,'2023-04-25','2023-04-25 00:00:00',4.05,0.2035,'2023-04-26 07:00:08','2023-06-27 21:33:02',63.9864,58.6542,55.9881,53.322,47.9898),
(1271,'XAU','USD',1999.05,1990.2,'2023-04-26','2023-04-26 00:00:00',8.85,0.4427,'2023-04-27 07:00:08','2023-06-27 21:33:02',64.2709,58.915,56.2371,53.5591,48.2032),
(1272,'XAG','USD',24.85,24.895,'2023-04-26','2023-04-26 00:00:00',-0.045,-0.1811,'2023-04-27 08:48:25','2023-06-27 21:33:02',0.7989,0.7324,0.6991,0.6658,0.5992),
(1295,'XAU','USD',1910,1954.9,'2023-02-03','2023-02-03 00:00:00',-44.9,-2.3508,'2023-04-27 09:54:51','2023-06-27 21:33:02',61.4079,56.2906,53.7319,51.1733,46.0559),
(1309,'XAU','USD',1824.1,1826.95,'2023-02-24','2023-02-24 00:00:00',-2.85,-0.1562,'2023-04-27 09:55:34','2023-06-27 21:33:02',58.6462,53.759,51.3154,48.8718,43.9846),
(1336,'XAU','USD',1982.25,1963.1,'2023-04-04','2023-04-04 00:00:00',19.15,0.9661,'2023-04-27 09:56:49','2023-06-27 21:33:02',0,0,0,0,0),
(1353,'XAG','USD',24.295,23.855,'2023-01-03','2023-01-03 00:00:00',0.44,1.8111,'2023-04-27 09:59:22','2023-06-27 21:33:02',0.7811,0.716,0.6835,0.6509,0.5858),
(1354,'XAG','USD',24.29,24.295,'2023-01-04','2023-01-04 00:00:00',-0.005,-0.0206,'2023-04-27 09:59:28','2023-06-27 21:33:02',0.7809,0.7159,0.6833,0.6508,0.5857),
(1355,'XAG','USD',23.41,24.29,'2023-01-05','2023-01-05 00:00:00',-0.88,-3.7591,'2023-04-27 09:59:30','2023-06-27 21:33:02',0.7526,0.6899,0.6586,0.6272,0.5645),
(1356,'XAG','USD',23.455,23.41,'2023-01-06','2023-01-06 00:00:00',0.045,0.1919,'2023-04-27 09:59:36','2023-06-27 21:33:02',0.7541,0.6913,0.6598,0.6284,0.5656),
(1357,'XAG','USD',23.85,23.455,'2023-01-09','2023-01-09 00:00:00',0.395,1.6562,'2023-04-27 09:59:38','2023-06-27 21:33:02',0.7668,0.7029,0.6709,0.639,0.5751),
(1358,'XAG','USD',23.515,23.85,'2023-01-10','2023-01-10 00:00:00',-0.335,-1.4246,'2023-04-27 09:59:39','2023-06-27 21:33:02',0.756,0.693,0.6615,0.63,0.567),
(1359,'XAG','USD',23.87,23.515,'2023-01-11','2023-01-11 00:00:00',0.355,1.4872,'2023-04-27 09:59:41','2023-06-27 21:33:02',0.7674,0.7035,0.6715,0.6395,0.5756),
(1360,'XAG','USD',23.7,23.87,'2023-01-12','2023-01-12 00:00:00',-0.17,-0.7173,'2023-04-27 09:59:43','2023-06-27 21:33:02',0.762,0.6985,0.6667,0.635,0.5715),
(1361,'XAG','USD',23.675,23.7,'2023-01-13','2023-01-13 00:00:00',-0.025,-0.1056,'2023-04-27 09:59:45','2023-06-27 21:33:02',0.7612,0.6977,0.666,0.6343,0.5709),
(1362,'XAG','USD',24.1,24.17,'2023-01-17','2023-01-17 00:00:00',-0.07,-0.2905,'2023-04-27 09:59:47','2023-06-27 21:33:02',0.7748,0.7103,0.678,0.6457,0.5811),
(1363,'XAG','USD',24.185,24.1,'2023-01-18','2023-01-18 00:00:00',0.085,0.3515,'2023-04-27 09:59:53','2023-06-27 21:33:02',0.7776,0.7128,0.6804,0.648,0.5832),
(1364,'XAG','USD',23.445,24.185,'2023-01-19','2023-01-19 00:00:00',-0.74,-3.1563,'2023-04-27 09:59:55','2023-06-27 21:33:02',0.7538,0.691,0.6596,0.6281,0.5653),
(1365,'XAG','USD',23.87,23.445,'2023-01-20','2023-01-20 00:00:00',0.425,1.7805,'2023-04-27 09:59:56','2023-06-27 21:33:02',0.7674,0.7035,0.6715,0.6395,0.5756),
(1366,'XAG','USD',23.675,23.87,'2023-01-23','2023-01-23 00:00:00',-0.195,-0.8237,'2023-04-27 09:59:58','2023-06-27 21:33:02',0.7612,0.6977,0.666,0.6343,0.5709),
(1367,'XAG','USD',23.71,23.675,'2023-01-24','2023-01-24 00:00:00',0.035,0.1476,'2023-04-27 10:00:00','2023-06-27 21:33:02',0.7623,0.6988,0.667,0.6352,0.5717),
(1368,'XAG','USD',23.43,23.71,'2023-01-25','2023-01-25 00:00:00',-0.28,-1.195,'2023-04-27 10:00:02','2023-06-27 21:33:02',0.7533,0.6905,0.6591,0.6277,0.565),
(1369,'XAG','USD',23.71,23.43,'2023-01-26','2023-01-26 00:00:00',0.28,1.1809,'2023-04-27 10:00:04','2023-06-27 21:33:02',0.7623,0.6988,0.667,0.6352,0.5717),
(1370,'XAG','USD',23.725,23.71,'2023-01-27','2023-01-27 00:00:00',0.015,0.0632,'2023-04-27 10:00:07','2023-06-27 21:33:02',0.7628,0.6992,0.6674,0.6356,0.5721),
(1371,'XAG','USD',23.635,23.725,'2023-01-30','2023-01-30 00:00:00',-0.09,-0.3808,'2023-04-27 10:00:09','2023-06-27 21:33:02',0.7599,0.6966,0.6649,0.6332,0.5699),
(1372,'XAG','USD',22.995,23.635,'2023-01-31','2023-01-31 00:00:00',-0.64,-2.7832,'2023-04-27 10:00:16','2023-06-27 21:33:02',0.7393,0.6777,0.6469,0.6161,0.5545),
(1373,'XAG','USD',23.495,22.995,'2023-02-01','2023-02-01 00:00:00',0.5,2.1281,'2023-04-27 10:00:18','2023-06-27 21:33:02',0.7554,0.6924,0.661,0.6295,0.5665),
(1374,'XAG','USD',24.435,23.495,'2023-02-02','2023-02-02 00:00:00',0.94,3.8469,'2023-04-27 10:00:20','2023-06-27 21:33:02',0.7856,0.7201,0.6874,0.6547,0.5892),
(1375,'XAG','USD',23.49,24.435,'2023-02-03','2023-02-03 00:00:00',-0.945,-4.023,'2023-04-27 10:00:22','2023-06-27 21:33:02',0.7552,0.6923,0.6608,0.6294,0.5664),
(1376,'XAG','USD',22.38,23.49,'2023-02-06','2023-02-06 00:00:00',-1.11,-4.9598,'2023-04-27 10:00:23','2023-06-27 21:33:02',0.7195,0.6596,0.6296,0.5996,0.5397),
(1377,'XAG','USD',22.205,22.38,'2023-02-07','2023-02-07 00:00:00',-0.175,-0.7881,'2023-04-27 10:00:25','2023-06-27 21:33:02',0.7139,0.6544,0.6247,0.5949,0.5354),
(1378,'XAG','USD',22.45,22.205,'2023-02-08','2023-02-08 00:00:00',0.245,1.0913,'2023-04-27 10:00:27','2023-06-27 21:33:02',0.7218,0.6616,0.6316,0.6015,0.5413),
(1379,'XAG','USD',22.465,22.45,'2023-02-09','2023-02-09 00:00:00',0.015,0.0668,'2023-04-27 10:00:29','2023-06-27 21:33:02',0.7223,0.6621,0.632,0.6019,0.5417),
(1380,'XAG','USD',22.115,22.465,'2023-02-10','2023-02-10 00:00:00',-0.35,-1.5826,'2023-04-27 10:00:30','2023-06-27 21:33:02',0.711,0.6518,0.6221,0.5925,0.5333),
(1381,'XAG','USD',21.985,22.115,'2023-02-13','2023-02-13 00:00:00',-0.13,-0.5913,'2023-04-27 10:00:37','2023-06-27 21:33:02',0.7068,0.6479,0.6185,0.589,0.5301),
(1382,'XAG','USD',21.71,21.985,'2023-02-14','2023-02-14 00:00:00',-0.275,-1.2667,'2023-04-27 10:00:39','2023-06-27 21:33:02',0.698,0.6398,0.6107,0.5817,0.5235),
(1383,'XAG','USD',21.47,21.71,'2023-02-15','2023-02-15 00:00:00',-0.24,-1.1178,'2023-04-27 10:00:41','2023-06-27 21:33:02',0.6903,0.6328,0.604,0.5752,0.5177),
(1384,'XAG','USD',21.565,21.47,'2023-02-16','2023-02-16 00:00:00',0.095,0.4405,'2023-04-27 10:00:43','2023-06-27 21:33:02',0.6933,0.6356,0.6067,0.5778,0.52),
(1385,'XAG','USD',21.215,21.565,'2023-02-17','2023-02-17 00:00:00',-0.35,-1.6498,'2023-04-27 10:00:45','2023-06-27 21:33:02',0.6821,0.6252,0.5968,0.5684,0.5116),
(1386,'XAG','USD',21.775,21.71,'2023-02-21','2023-02-21 00:00:00',0.065,0.2985,'2023-04-27 10:00:46','2023-06-27 21:33:02',0.7001,0.6417,0.6126,0.5834,0.5251),
(1387,'XAG','USD',21.86,21.775,'2023-02-22','2023-02-22 00:00:00',0.085,0.3888,'2023-04-27 10:00:48','2023-06-27 21:33:02',0.7028,0.6442,0.615,0.5857,0.5271),
(1388,'XAG','USD',21.52,21.86,'2023-02-23','2023-02-23 00:00:00',-0.34,-1.5799,'2023-04-27 10:00:49','2023-06-27 21:33:02',0.6919,0.6342,0.6054,0.5766,0.5189),
(1389,'XAG','USD',21.09,21.52,'2023-02-24','2023-02-24 00:00:00',-0.43,-2.0389,'2023-04-27 10:00:51','2023-06-27 21:33:02',0.6781,0.6216,0.5933,0.565,0.5085),
(1390,'XAG','USD',20.73,21.09,'2023-02-27','2023-02-27 00:00:00',-0.36,-1.7366,'2023-04-27 10:00:52','2023-06-27 21:33:02',0.6665,0.6109,0.5832,0.5554,0.4999),
(1391,'XAG','USD',20.525,20.73,'2023-02-28','2023-02-28 00:00:00',-0.205,-0.9988,'2023-04-27 10:00:54','2023-06-27 21:33:02',0.6599,0.6049,0.5774,0.5499,0.4949),
(1392,'XAG','USD',20.995,20.525,'2023-03-01','2023-03-01 00:00:00',0.47,2.2386,'2023-04-27 10:00:55','2023-06-27 21:33:02',0.675,0.6188,0.5906,0.5625,0.5063),
(1393,'XAG','USD',20.8,20.995,'2023-03-02','2023-03-02 00:00:00',-0.195,-0.9375,'2023-04-27 10:00:56','2023-06-27 21:33:02',0.6687,0.613,0.5851,0.5573,0.5016),
(1394,'XAG','USD',21.09,20.8,'2023-03-03','2023-03-03 00:00:00',0.29,1.3751,'2023-04-27 10:00:58','2023-06-27 21:33:02',0.6781,0.6216,0.5933,0.565,0.5085),
(1395,'XAG','USD',21.085,21.09,'2023-03-06','2023-03-06 00:00:00',-0.005,-0.0237,'2023-04-27 10:00:59','2023-06-27 21:33:02',0.6779,0.6214,0.5932,0.5649,0.5084),
(1396,'XAG','USD',20.91,21.085,'2023-03-07','2023-03-07 00:00:00',-0.175,-0.8369,'2023-04-27 10:01:01','2023-06-27 21:33:02',0.6723,0.6162,0.5882,0.5602,0.5042),
(1397,'XAG','USD',20.105,20.91,'2023-03-08','2023-03-08 00:00:00',-0.805,-4.004,'2023-04-27 10:01:03','2023-06-27 21:33:02',0.6464,0.5925,0.5656,0.5387,0.4848),
(1398,'XAG','USD',20.12,20.105,'2023-03-09','2023-03-09 00:00:00',0.015,0.0746,'2023-04-27 10:01:06','2023-06-27 21:33:02',0.6469,0.593,0.566,0.5391,0.4852),
(1399,'XAG','USD',20.09,20.12,'2023-03-10','2023-03-10 00:00:00',-0.03,-0.1493,'2023-04-27 10:01:07','2023-06-27 21:33:02',0.6459,0.5921,0.5652,0.5383,0.4844),
(1400,'XAG','USD',21.095,20.09,'2023-03-13','2023-03-13 00:00:00',1.005,4.7642,'2023-04-27 10:01:09','2023-06-27 21:33:02',0.6782,0.6217,0.5934,0.5652,0.5087),
(1401,'XAG','USD',21.64,21.095,'2023-03-14','2023-03-14 00:00:00',0.545,2.5185,'2023-04-27 10:01:10','2023-06-27 21:33:02',0.6957,0.6378,0.6088,0.5798,0.5218),
(1402,'XAG','USD',22.095,21.64,'2023-03-15','2023-03-15 00:00:00',0.455,2.0593,'2023-04-27 10:01:12','2023-06-27 21:33:02',0.7104,0.6512,0.6216,0.592,0.5328),
(1403,'XAG','USD',22.01,22.095,'2023-03-16','2023-03-16 00:00:00',-0.085,-0.3862,'2023-04-27 10:01:14','2023-06-27 21:33:02',0.7076,0.6487,0.6192,0.5897,0.5307),
(1404,'XAG','USD',21.885,22.01,'2023-03-17','2023-03-17 00:00:00',-0.125,-0.5712,'2023-04-27 10:01:16','2023-06-27 21:33:02',0.7036,0.645,0.6157,0.5863,0.5277),
(1405,'XAG','USD',22.495,21.885,'2023-03-20','2023-03-20 00:00:00',0.61,2.7117,'2023-04-27 10:01:17','2023-06-27 21:33:02',0.7232,0.663,0.6328,0.6027,0.5424),
(1406,'XAG','USD',22.465,22.495,'2023-03-21','2023-03-21 00:00:00',-0.03,-0.1335,'2023-04-27 10:01:18','2023-06-27 21:33:02',0.7223,0.6621,0.632,0.6019,0.5417),
(1407,'XAG','USD',22.345,22.465,'2023-03-22','2023-03-22 00:00:00',-0.12,-0.537,'2023-04-27 10:01:20','2023-06-27 21:33:02',0.7184,0.6585,0.6286,0.5987,0.5388),
(1408,'XAG','USD',22.9,22.345,'2023-03-23','2023-03-23 00:00:00',0.555,2.4236,'2023-04-27 10:01:21','2023-06-27 21:33:02',0.7363,0.6749,0.6442,0.6135,0.5522),
(1409,'XAG','USD',23.17,22.9,'2023-03-24','2023-03-24 00:00:00',0.27,1.1653,'2023-04-27 10:01:22','2023-06-27 21:33:02',0.7449,0.6829,0.6518,0.6208,0.5587),
(1410,'XAG','USD',22.89,23.17,'2023-03-27','2023-03-27 00:00:00',-0.28,-1.2232,'2023-04-27 10:01:24','2023-06-27 21:33:02',0.7359,0.6746,0.6439,0.6133,0.5519),
(1411,'XAG','USD',23.045,22.89,'2023-03-28','2023-03-28 00:00:00',0.155,0.6726,'2023-04-27 10:01:26','2023-06-27 21:33:02',0.7409,0.6792,0.6483,0.6174,0.5557),
(1412,'XAG','USD',23.255,23.045,'2023-03-29','2023-03-29 00:00:00',0.21,0.903,'2023-04-27 10:01:27','2023-06-27 21:33:02',0.7477,0.6854,0.6542,0.6231,0.5607),
(1413,'XAG','USD',23.71,23.255,'2023-03-30','2023-03-30 00:00:00',0.455,1.919,'2023-04-27 10:01:28','2023-06-27 21:33:02',0.7623,0.6988,0.667,0.6352,0.5717),
(1414,'XAG','USD',23.885,23.71,'2023-03-31','2023-03-31 00:00:00',0.175,0.7327,'2023-04-27 10:01:30','2023-06-27 21:33:02',0.7679,0.7039,0.6719,0.6399,0.5759),
(1415,'XAG','USD',23.925,23.885,'2023-04-03','2023-04-03 00:00:00',0.04,0.1672,'2023-04-27 10:01:31','2023-06-27 21:33:02',0.7692,0.7051,0.6731,0.641,0.5769),
(1416,'XAG','USD',24.015,23.925,'2023-04-04','2023-04-04 00:00:00',0.09,0.3748,'2023-04-27 10:01:32','2023-06-27 21:33:02',0.7721,0.7078,0.6756,0.6434,0.5791),
(1417,'XAG','USD',24.74,24.015,'2023-04-05','2023-04-05 00:00:00',0.725,2.9305,'2023-04-27 10:01:34','2023-06-27 21:33:02',0.7954,0.7291,0.696,0.6628,0.5966),
(1418,'XAG','USD',24.935,24.74,'2023-04-06','2023-04-06 00:00:00',0.195,0.782,'2023-04-27 10:01:35','2023-06-27 21:33:02',0.8017,0.7349,0.7015,0.6681,0.6013),
(1419,'XAG','USD',24.935,24.935,'2023-04-07','2023-04-07 00:00:00',0,0,'2023-04-27 10:01:37','2023-06-27 21:33:02',0.8017,0.7349,0.7015,0.6681,0.6013),
(1420,'XAG','USD',24.935,24.935,'2023-04-10','2023-04-10 00:00:00',0,0,'2023-04-27 10:01:43','2023-06-27 21:33:02',0.8017,0.7349,0.7015,0.6681,0.6013),
(1421,'XAG','USD',25.055,24.935,'2023-04-11','2023-04-11 00:00:00',0.12,0.4789,'2023-04-27 10:01:45','2023-06-27 21:33:02',0.8055,0.7384,0.7048,0.6713,0.6042),
(1422,'XAG','USD',25.145,25.055,'2023-04-12','2023-04-12 00:00:00',0.09,0.3579,'2023-04-27 10:01:47','2023-06-27 21:33:02',0.8084,0.7411,0.7074,0.6737,0.6063),
(1423,'XAG','USD',25.62,25.145,'2023-04-13','2023-04-13 00:00:00',0.475,1.854,'2023-04-27 10:01:49','2023-06-27 21:33:02',0.8237,0.7551,0.7207,0.6864,0.6178),
(1424,'XAG','USD',26.025,25.62,'2023-04-14','2023-04-14 00:00:00',0.405,1.5562,'2023-04-27 10:01:50','2023-06-27 21:33:02',0.8367,0.767,0.7321,0.6973,0.6275),
(1425,'XAG','USD',25.39,26.025,'2023-04-17','2023-04-17 00:00:00',-0.635,-2.501,'2023-04-27 10:01:51','2023-06-27 21:33:02',0.8163,0.7483,0.7143,0.6803,0.6122),
(1426,'XAG','USD',25.09,25.39,'2023-04-18','2023-04-18 00:00:00',-0.3,-1.1957,'2023-04-27 10:01:53','2023-06-27 21:33:02',0.8067,0.7394,0.7058,0.6722,0.605),
(1427,'XAG','USD',24.75,25.09,'2023-04-19','2023-04-19 00:00:00',-0.34,-1.3737,'2023-04-27 10:01:55','2023-06-27 21:33:02',0.7957,0.7294,0.6963,0.6631,0.5968),
(1428,'XAG','USD',25.4,24.75,'2023-04-20','2023-04-20 00:00:00',0.65,2.5591,'2023-04-27 10:01:57','2023-06-27 21:33:02',0.8166,0.7486,0.7146,0.6805,0.6125),
(1429,'XAG','USD',25.155,25.4,'2023-04-21','2023-04-21 00:00:00',-0.245,-0.974,'2023-04-27 10:01:59','2023-06-27 21:33:02',0.8088,0.7414,0.7077,0.674,0.6066),
(1430,'XAG','USD',25.03,25.155,'2023-04-24','2023-04-24 00:00:00',-0.125,-0.4994,'2023-04-27 10:02:01','2023-06-27 21:33:02',0.8047,0.7377,0.7041,0.6706,0.6035),
(1431,'XAG','USD',24.895,25.03,'2023-04-25','2023-04-25 00:00:00',-0.135,-0.5423,'2023-04-27 10:02:03','2023-06-27 21:33:02',0.8004,0.7337,0.7003,0.667,0.6003),
(1433,'XAU','USD',1997.65,1999.05,'2023-04-27','2023-04-27 00:00:00',-1.4,-0.0701,'2023-04-28 07:18:12','2023-06-27 21:33:02',64.2259,58.8738,56.1977,53.5216,48.1695),
(1434,'XAG','USD',25.145,24.85,'2023-04-27','2023-04-27 00:00:00',0.295,1.1732,'2023-04-28 07:23:28','2023-06-27 21:33:02',0.8084,0.7411,0.7074,0.6737,0.6063),
(1435,'XAG','USD',26.11,26.125,'2021-04-26','2021-04-26 00:00:00',-0.015,-0.0574,'2023-04-28 07:30:09','2023-06-27 21:33:02',0.8395,0.7695,0.7345,0.6995,0.6296),
(1436,'XAU','USD',1982.7,1997.65,'2023-04-28','2023-04-28 00:00:00',-14.95,-0.754,'2023-04-29 07:00:12','2023-06-27 21:33:02',63.7453,58.4332,55.7771,53.1211,47.809),
(1437,'XAG','USD',24.765,25.145,'2023-04-28','2023-04-28 00:00:00',-0.38,-1.5344,'2023-04-29 07:05:17','2023-06-27 21:33:02',0.7962,0.7299,0.6967,0.6635,0.5972),
(1438,'XAU','USD',1982.7,1982.7,'2023-05-01','2023-05-01 00:00:00',0,0,'2023-05-02 07:00:14','2023-06-27 21:33:02',63.7453,58.4332,55.7771,53.1211,47.809),
(1439,'XAG','USD',24.765,24.765,'2023-05-01','2023-05-01 00:00:00',0,0,'2023-05-02 07:05:14','2023-06-27 21:33:02',0.7962,0.7299,0.6967,0.6635,0.5972),
(1440,'XAU','USD',1980.9,1982.7,'2023-05-02','2023-05-02 00:00:00',-1.8,-0.0909,'2023-05-03 07:00:15','2023-06-27 21:33:02',63.6874,58.3801,55.7265,53.0728,47.7656),
(1441,'XAG','USD',24.77,24.765,'2023-05-02','2023-05-02 00:00:00',0.005,0.0202,'2023-05-03 07:05:14','2023-06-27 21:33:02',0.7964,0.73,0.6968,0.6636,0.5973),
(1558,'XAU','USD',1895,1895.45,'2022-02-22','2022-02-22 00:00:00',-0.45,-0.0237,'2023-05-03 19:33:47','2023-06-27 21:33:02',60.9257,55.8485,53.31,50.7714,45.6942),
(1559,'XAU','USD',1895.7,1895,'2022-02-23','2022-02-23 00:00:00',0.7,0.0369,'2023-05-03 19:33:48','2023-06-27 21:33:02',60.9482,55.8692,53.3296,50.7901,45.7111),
(1560,'XAU','USD',1968.35,1895.7,'2022-02-24','2022-02-24 00:00:00',72.65,3.6909,'2023-05-03 19:33:50','2023-06-27 21:33:02',63.2839,58.0103,55.3734,52.7366,47.4629),
(1561,'XAU','USD',1912.15,1968.35,'2022-02-25','2022-02-25 00:00:00',-56.2,-2.9391,'2023-05-03 19:33:52','2023-06-27 21:33:02',61.4771,56.354,53.7924,51.2309,46.1078),
(1562,'XAU','USD',1903.3,1912.15,'2022-02-28','2022-02-28 00:00:00',-8.85,-0.465,'2023-05-03 19:33:54','2023-06-27 21:33:02',61.1925,56.0931,53.5435,50.9938,45.8944),
(1563,'XAU','USD',1920.45,1903.3,'2022-03-01','2022-03-01 00:00:00',17.15,0.893,'2023-05-03 19:33:56','2023-06-27 21:33:02',61.7439,56.5986,54.0259,51.4533,46.3079),
(1564,'XAU','USD',1926,1920.45,'2022-03-02','2022-03-02 00:00:00',5.55,0.2882,'2023-05-03 19:33:58','2023-06-27 21:33:02',61.9223,56.7621,54.182,51.6019,46.4418),
(1565,'XAU','USD',1935.4,1926,'2022-03-03','2022-03-03 00:00:00',9.4,0.4857,'2023-05-03 19:33:59','2023-06-27 21:33:02',62.2246,57.0392,54.4465,51.8538,46.6684),
(1566,'XAU','USD',1943.8,1935.4,'2022-03-04','2022-03-04 00:00:00',8.4,0.4321,'2023-05-03 19:34:06','2023-06-27 21:33:02',62.4946,57.2867,54.6828,52.0789,46.871),
(1567,'XAU','USD',1999.25,1943.8,'2022-03-07','2022-03-07 00:00:00',55.45,2.7735,'2023-05-03 19:34:08','2023-06-27 21:33:02',64.2774,58.9209,56.2427,53.5645,48.208),
(1569,'XAU','USD',2017.15,2007,'2022-03-09','2022-03-09 00:00:00',10.15,0.5032,'2023-05-03 19:34:16','2023-06-27 21:33:02',64.8529,59.4485,56.7463,54.0441,48.6397),
(1570,'XAU','USD',1997.65,2017.15,'2022-03-10','2022-03-10 00:00:00',-19.5,-0.9761,'2023-05-03 19:34:17','2023-06-27 21:33:02',64.2259,58.8738,56.1977,53.5216,48.1695),
(1571,'XAU','USD',1991.45,1997.65,'2022-03-11','2022-03-11 00:00:00',-6.2,-0.3113,'2023-05-03 19:34:19','2023-06-27 21:33:02',64.0266,58.6911,56.0233,53.3555,48.02),
(1573,'XAU','USD',1928.75,1961.6,'2022-03-15','2022-03-15 00:00:00',-32.85,-1.7032,'2023-05-03 19:34:23','2023-06-27 21:33:02',62.0108,56.8432,54.2594,51.6756,46.5081),
(1574,'XAU','USD',1918.75,1928.75,'2022-03-16','2022-03-16 00:00:00',-10,-0.5212,'2023-05-03 19:34:24','2023-06-27 21:33:02',61.6892,56.5485,53.9781,51.4077,46.2669),
(1575,'XAU','USD',1941.4,1918.75,'2022-03-17','2022-03-17 00:00:00',22.65,1.1667,'2023-05-03 19:34:26','2023-06-27 21:33:02',62.4175,57.216,54.6153,52.0145,46.8131),
(1576,'XAU','USD',1932.9,1941.4,'2022-03-18','2022-03-18 00:00:00',-8.5,-0.4398,'2023-05-03 19:34:27','2023-06-27 21:33:02',62.1442,56.9655,54.3762,51.7868,46.6081),
(1577,'XAU','USD',1925.05,1932.9,'2022-03-21','2022-03-21 00:00:00',-7.85,-0.4078,'2023-05-03 19:34:29','2023-06-27 21:33:02',61.8918,56.7341,54.1553,51.5765,46.4188),
(1578,'XAU','USD',1929.35,1925.05,'2022-03-22','2022-03-22 00:00:00',4.3,0.2229,'2023-05-03 19:34:30','2023-06-27 21:33:02',62.03,56.8609,54.2763,51.6917,46.5225),
(1579,'XAU','USD',1932.15,1929.35,'2022-03-23','2022-03-23 00:00:00',2.8,0.1449,'2023-05-03 19:34:32','2023-06-27 21:33:02',62.1201,56.9434,54.3551,51.7667,46.59),
(1580,'XAU','USD',1945.9,1932.15,'2022-03-24','2022-03-24 00:00:00',13.75,0.7066,'2023-05-03 19:34:34','2023-06-27 21:33:02',62.5621,57.3486,54.7419,52.1351,46.9216),
(1593,'XAU','USD',1927.1,1927.1,'2022-04-12','2022-04-12 00:00:00',0,0,'2023-05-03 19:34:54','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1594,'XAU','USD',1927.1,1927.1,'2022-04-13','2022-04-13 00:00:00',0,0,'2023-05-03 19:34:56','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1595,'XAU','USD',1927.1,1927.1,'2022-04-14','2022-04-14 00:00:00',0,0,'2023-05-03 19:34:57','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1596,'XAU','USD',1927.1,1927.1,'2022-04-15','2022-04-15 00:00:00',0,0,'2023-05-03 19:34:59','2023-06-27 21:33:02',61.9577,56.7946,54.213,51.6314,46.4683),
(1640,'XAU','USD',1849.85,1831.55,'2022-06-17','2022-06-17 00:00:00',18.3,0.9893,'2023-05-03 19:36:29','2023-06-27 21:33:02',59.4741,54.5179,52.0398,49.5617,44.6055),
(1650,'XAU','USD',1804.4,1807.05,'2022-07-05','2022-07-05 00:00:00',-2.65,-0.1469,'2023-05-03 19:44:14','2023-06-27 21:33:02',58.0128,53.1784,50.7612,48.344,43.5096),
(1668,'XAU','USD',1758.9,1746.6,'2022-07-29','2022-07-29 00:00:00',12.3,0.6993,'2023-05-03 19:44:48','2023-06-27 21:33:02',56.5499,51.8375,49.4812,47.125,42.4125),
(1940,'XAU','USD',2016.9,1980.9,'2023-05-03','2023-05-03 00:00:00',36,1.7849,'2023-05-04 07:00:11','2023-06-27 21:33:02',64.8448,59.4411,56.7392,54.0374,48.6336),
(1941,'XAG','USD',25.25,24.77,'2023-05-03','2023-05-03 00:00:00',0.48,1.901,'2023-05-04 07:05:14','2023-06-27 21:33:02',0.8118,0.7442,0.7103,0.6765,0.6089),
(1942,'XAU','USD',2036.05,2016.9,'2023-05-04','2023-05-04 00:00:00',19.15,0.9405,'2023-05-05 07:00:14','2023-06-27 21:33:02',65.4605,60.0055,57.278,54.5504,49.0954),
(1943,'XAG','USD',25.625,25.25,'2023-05-04','2023-05-04 00:00:00',0.375,1.4634,'2023-05-05 07:05:14','2023-06-27 21:33:02',0.8239,0.7552,0.7209,0.6866,0.6179),
(1944,'XAU','USD',2038.9,2036.05,'2023-05-05','2023-05-05 00:00:00',2.85,0.1398,'2023-05-06 07:00:14','2023-06-27 21:33:02',65.5522,60.0895,57.3581,54.6268,49.1641),
(1945,'XAG','USD',25.84,25.625,'2023-05-05','2023-05-05 00:00:00',0.215,0.832,'2023-05-06 07:05:13','2023-06-27 21:33:02',0.8308,0.7615,0.7269,0.6923,0.6231),
(1946,'XAU','USD',2038.9,2038.9,'2023-05-08','2023-05-08 00:00:00',0,0,'2023-05-09 07:00:14','2023-06-27 21:33:02',65.5522,60.0895,57.3581,54.6268,49.1641),
(1947,'XAG','USD',25.84,25.84,'2023-05-08','2023-05-08 00:00:00',0,0,'2023-05-09 07:05:13','2023-06-27 21:33:02',0.8308,0.7615,0.7269,0.6923,0.6231),
(1948,'XAU','USD',2025.6,2038.9,'2023-05-09','2023-05-09 00:00:00',-13.3,-0.6566,'2023-05-10 07:00:14','2023-06-27 21:33:02',65.1246,59.6975,56.984,54.2705,48.8434),
(1949,'XAG','USD',25.565,25.84,'2023-05-09','2023-05-09 00:00:00',-0.275,-1.0757,'2023-05-10 07:05:14','2023-06-27 21:33:02',0.8219,0.7534,0.7192,0.6849,0.6165),
(1950,'XAU','USD',2029.6,2025.6,'2023-05-10','2023-05-10 00:00:00',4,0.1971,'2023-05-11 07:00:14','2023-06-27 21:33:02',65.2532,59.8154,57.0965,54.3776,48.9399),
(1951,'XAG','USD',25.52,25.565,'2023-05-10','2023-05-10 00:00:00',-0.045,-0.1763,'2023-05-11 07:05:14','2023-06-27 21:33:02',0.8205,0.7521,0.7179,0.6837,0.6154),
(1952,'XAU','USD',2025.75,2029.6,'2023-05-11','2023-05-11 00:00:00',-3.85,-0.1901,'2023-05-12 07:00:11','2023-06-27 21:33:02',65.1294,59.7019,56.9882,54.2745,48.847),
(1953,'XAG','USD',24.885,25.52,'2023-05-11','2023-05-11 00:00:00',-0.635,-2.5517,'2023-05-12 07:05:10','2023-06-27 21:33:02',0.8001,0.7334,0.7001,0.6667,0.6001),
(1954,'XAU','USD',2006.65,2025.75,'2023-05-12','2023-05-12 00:00:00',-19.1,-0.9518,'2023-05-13 07:00:14','2023-06-27 21:33:02',64.5153,59.139,56.4509,53.7627,48.3865),
(1955,'XAG','USD',23.855,24.885,'2023-05-12','2023-05-12 00:00:00',-1.03,-4.3178,'2023-05-13 07:05:15','2023-06-27 21:33:02',0.767,0.703,0.6711,0.6391,0.5752),
(1956,'XAU','USD',2015.3,2006.65,'2023-05-15','2023-05-15 00:00:00',8.65,0.4292,'2023-05-16 07:00:16','2023-06-27 21:33:02',64.7934,59.3939,56.6942,53.9945,48.595),
(1957,'XAG','USD',23.89,23.855,'2023-05-15','2023-05-15 00:00:00',0.035,0.1465,'2023-05-16 07:05:09','2023-06-27 21:33:02',0.7681,0.7041,0.6721,0.6401,0.5761),
(1958,'XAU','USD',2009.9,2015.3,'2023-05-16','2023-05-16 00:00:00',-5.4,-0.2687,'2023-05-17 07:00:21','2023-06-27 21:33:02',64.6198,59.2348,56.5423,53.8498,48.4648),
(1959,'XAG','USD',23.785,23.89,'2023-05-16','2023-05-16 00:00:00',-0.105,-0.4415,'2023-05-17 07:05:09','2023-06-27 21:33:02',0.7647,0.701,0.6691,0.6373,0.5735),
(1960,'XAU','USD',1985.75,2009.9,'2023-05-17','2023-05-17 00:00:00',-24.15,-1.2162,'2023-05-18 07:00:14','2023-06-27 21:33:02',63.8433,58.5231,55.8629,53.2028,47.8825),
(1961,'XAG','USD',23.685,23.785,'2023-05-17','2023-05-17 00:00:00',-0.1,-0.4222,'2023-05-18 07:05:17','2023-06-27 21:33:02',0.7615,0.698,0.6663,0.6346,0.5711),
(1962,'XAU','USD',1976.95,1985.75,'2023-05-18','2023-05-18 00:00:00',-8.8,-0.4451,'2023-05-19 07:00:09','2023-06-27 21:33:02',63.5604,58.2637,55.6154,52.967,47.6703),
(1963,'XAG','USD',23.52,23.685,'2023-05-18','2023-05-18 00:00:00',-0.165,-0.7015,'2023-05-19 07:05:14','2023-06-27 21:33:02',0.7562,0.6932,0.6617,0.6302,0.5671),
(1964,'XAU','USD',1965.55,1976.95,'2023-05-19','2023-05-19 00:00:00',-11.4,-0.58,'2023-05-20 07:00:09','2023-06-27 21:33:02',63.1939,57.9277,55.2947,52.6616,47.3954),
(1965,'XAG','USD',23.66,23.52,'2023-05-19','2023-05-19 00:00:00',0.14,0.5917,'2023-05-20 07:05:14','2023-06-27 21:33:02',0.7607,0.6973,0.6656,0.6339,0.5705),
(1966,'XAU','USD',1981.2,1965.55,'2023-05-22','2023-05-22 00:00:00',15.65,0.7899,'2023-05-23 07:00:14','2023-06-27 21:33:02',63.6971,58.389,55.7349,53.0809,47.7728),
(1967,'XAG','USD',23.85,23.66,'2023-05-22','2023-05-22 00:00:00',0.19,0.7966,'2023-05-23 07:05:09','2023-06-27 21:33:02',0.7668,0.7029,0.6709,0.639,0.5751),
(1968,'XAU','USD',1959.65,1981.2,'2023-05-23','2023-05-23 00:00:00',-21.55,-1.0997,'2023-05-24 07:00:14','2023-06-27 21:33:02',63.0042,57.7539,55.1287,52.5035,47.2532),
(1969,'XAG','USD',23.16,23.85,'2023-05-23','2023-05-23 00:00:00',-0.69,-2.9793,'2023-05-24 07:05:16','2023-06-27 21:33:02',0.7446,0.6826,0.6515,0.6205,0.5585),
(1970,'XAU','USD',1976.8,1959.65,'2023-05-24','2023-05-24 00:00:00',17.15,0.8676,'2023-05-25 07:00:14','2023-06-27 21:33:02',63.5556,58.2593,55.6111,52.963,47.6667),
(1971,'XAG','USD',23.415,23.16,'2023-05-24','2023-05-24 00:00:00',0.255,1.089,'2023-05-25 07:05:15','2023-06-27 21:33:02',0.7528,0.6901,0.6587,0.6273,0.5646),
(1972,'XAU','USD',1962.3,1976.8,'2023-05-25','2023-05-25 00:00:00',-14.5,-0.7389,'2023-05-26 07:00:12','2023-06-27 21:33:02',63.0894,57.832,55.2032,52.5745,47.3171),
(1973,'XAG','USD',23.005,23.415,'2023-05-25','2023-05-25 00:00:00',-0.41,-1.7822,'2023-05-26 07:05:15','2023-06-27 21:33:02',0.7396,0.678,0.6472,0.6164,0.5547),
(1974,'XAU','USD',1953.5,1962.3,'2023-05-26','2023-05-26 00:00:00',-8.8,-0.4505,'2023-05-27 07:00:08','2023-06-27 21:33:02',62.8065,57.5726,54.9557,52.3387,47.1049),
(1975,'XAG','USD',23.145,23.005,'2023-05-26','2023-05-26 00:00:00',0.14,0.6049,'2023-05-27 07:05:13','2023-06-27 21:33:02',0.7441,0.6821,0.6511,0.6201,0.5581),
(1976,'XAU','USD',1959,1949.5,'2023-05-31','2023-05-31 00:00:00',9.5,0.4849,'2023-06-01 07:00:10','2023-06-27 21:33:02',62.9833,57.7347,55.1104,52.4861,47.2375),
(1977,'XAG','USD',23.255,23.255,'2023-05-31','2023-05-31 00:00:00',0,0,'2023-06-01 07:05:10','2023-06-27 21:33:02',0.7477,0.6854,0.6542,0.6231,0.5607),
(1978,'XAU','USD',1949.5,1953.5,'2023-05-30','2023-05-30 00:00:00',-4,-0.2052,'2023-06-01 09:14:49','2023-06-27 21:33:02',62.6779,57.4547,54.8431,52.2316,47.0084),
(1979,'XAU','USD',1958.75,1959,'2023-06-01','2023-06-01 00:00:00',-0.25,-0.0128,'2023-06-02 07:00:14','2023-06-27 21:33:02',62.9753,57.7273,55.1034,52.4794,47.2315),
(1980,'XAG','USD',23.49,23.255,'2023-06-01','2023-06-01 00:00:00',0.235,1.0004,'2023-06-02 07:05:14','2023-06-27 21:33:02',0.7552,0.6923,0.6608,0.6294,0.5664),
(1981,'XAU','USD',1981,1958.75,'2023-06-02','2023-06-02 00:00:00',22.25,1.1232,'2023-06-03 07:00:13','2023-06-27 21:33:02',63.6906,58.3831,55.7293,53.0755,47.768),
(1982,'XAG','USD',23.885,23.49,'2023-06-02','2023-06-02 00:00:00',0.395,1.6538,'2023-06-03 07:05:09','2023-06-27 21:33:02',0.7679,0.7039,0.6719,0.6399,0.5759),
(1983,'XAU','USD',1942.5,1981,'2023-06-05','2023-06-05 00:00:00',-38.5,-1.982,'2023-06-06 07:00:20','2023-06-27 21:33:02',62.4528,57.2484,54.6462,52.044,46.8396),
(1984,'XAG','USD',23.475,23.885,'2023-06-05','2023-06-05 00:00:00',-0.41,-1.7465,'2023-06-06 07:05:17','2023-06-27 21:33:02',0.7547,0.6918,0.6604,0.6289,0.5661),
(1985,'XAU','USD',1961.9,1942.5,'2023-06-06','2023-06-06 00:00:00',19.4,0.9888,'2023-06-07 07:00:21','2023-06-27 21:33:02',63.0765,57.8202,55.192,52.5638,47.3074),
(1986,'XAG','USD',23.645,23.475,'2023-06-06','2023-06-06 00:00:00',0.17,0.719,'2023-06-07 07:05:22','2023-06-27 21:33:02',0.7602,0.6969,0.6652,0.6335,0.5702),
(1987,'XAU','USD',1963.05,1961.9,'2023-06-07','2023-06-07 00:00:00',1.15,0.0586,'2023-06-08 07:00:09','2023-06-27 21:33:02',63.1135,57.8541,55.2243,52.5946,47.3351),
(1988,'XAG','USD',23.585,23.645,'2023-06-07','2023-06-07 00:00:00',-0.06,-0.2544,'2023-06-08 07:05:15','2023-06-27 21:33:02',0.7583,0.6951,0.6635,0.6319,0.5687),
(1989,'XAU','USD',1947.25,1963.05,'2023-06-08','2023-06-08 00:00:00',-15.8,-0.8114,'2023-06-09 07:00:09','2023-06-27 21:33:02',62.6055,57.3884,54.7798,52.1713,46.9542),
(1990,'XAG','USD',23.67,23.585,'2023-06-08','2023-06-08 00:00:00',0.085,0.3591,'2023-06-09 07:05:09','2023-06-27 21:33:02',0.761,0.6976,0.6659,0.6342,0.5708),
(1991,'XAU','USD',1963.55,1947.25,'2023-06-09','2023-06-09 00:00:00',16.3,0.8301,'2023-06-10 07:00:14','2023-06-27 21:33:02',63.1296,57.8688,55.2384,52.608,47.3472),
(1992,'XAG','USD',24.315,23.67,'2023-06-09','2023-06-09 00:00:00',0.645,2.6527,'2023-06-10 07:05:14','2023-06-27 21:33:02',0.7817,0.7166,0.684,0.6515,0.5863),
(1993,'XAU','USD',1964.15,1963.55,'2023-06-12','2023-06-12 00:00:00',0.6,0.0305,'2023-06-13 07:00:14','2023-06-27 21:33:02',63.1489,57.8865,55.2553,52.6241,47.3617),
(1994,'XAG','USD',24.21,24.315,'2023-06-12','2023-06-12 00:00:00',-0.105,-0.4337,'2023-06-13 07:05:09','2023-06-27 21:33:02',0.7784,0.7135,0.6811,0.6486,0.5838),
(1995,'XAU','USD',1964,1964.15,'2023-06-13','2023-06-13 00:00:00',-0.15,-0.0076,'2023-06-14 07:00:14','2023-06-27 21:33:02',63.1441,57.8821,55.2511,52.6201,47.358),
(1996,'XAG','USD',24.19,24.21,'2023-06-13','2023-06-13 00:00:00',-0.02,-0.0827,'2023-06-14 07:05:20','2023-06-27 21:33:02',0.7777,0.7129,0.6805,0.6481,0.5833),
(1999,'XAU','USD',1951.9,1964,'2023-06-14','2023-06-14 00:00:00',-12.1,-0.6199,'2023-06-15 07:00:10','2023-06-27 21:33:02',62.755,57.5255,54.9107,52.2959,47.0663),
(2000,'XAG','USD',23.825,24.19,'2023-06-14','2023-06-14 00:00:00',-0.365,-1.532,'2023-06-15 07:05:12','2023-06-27 21:33:02',0.766,0.7022,0.6702,0.6383,0.5745),
(2001,'XAU','USD',1934.65,1951.9,'2023-06-15','2023-06-15 00:00:00',-17.25,-0.8916,'2023-06-16 07:00:12','2023-06-27 21:33:02',62.2004,57.0171,54.4254,51.8337,46.6503),
(2002,'XAG','USD',23.405,23.825,'2023-06-15','2023-06-15 00:00:00',-0.42,-1.7945,'2023-06-16 07:05:30','2023-06-27 21:33:02',0.7525,0.6898,0.6584,0.6271,0.5644),
(2003,'XAU','USD',1964.1,1934.65,'2023-06-16','2023-06-16 00:00:00',29.45,1.4994,'2023-06-20 18:44:13','2023-06-27 21:33:02',63.1473,57.885,55.2539,52.6227,47.3605),
(2004,'XAG','USD',23.99,23.405,'2023-06-16','2023-06-16 00:00:00',0.585,2.4385,'2023-06-20 18:44:54','2023-06-27 21:33:02',0.7713,0.707,0.6749,0.6427,0.5785),
(2005,'XAU','USD',1953.85,1954.35,'2023-06-20','2023-06-20 00:00:00',-0.5,-0.0256,'2023-06-21 07:00:34','2023-06-27 21:33:02',62.8177,57.5829,54.9655,52.3481,47.1133),
(2006,'XAG','USD',23.77,23.95,'2023-06-20','2023-06-20 00:00:00',-0.18,-0.7573,'2023-06-21 07:05:09','2023-06-27 21:33:02',0.7642,0.7005,0.6687,0.6369,0.5732),
(2007,'XAU','USD',1935.25,1953.85,'2023-06-21','2023-06-21 00:00:00',-18.6,-0.9611,'2023-06-22 07:00:17','2023-06-27 21:33:02',62.2197,57.0348,54.4423,51.8498,46.6648),
(2008,'XAG','USD',23.075,23.77,'2023-06-21','2023-06-21 00:00:00',-0.695,-3.0119,'2023-06-22 07:05:19','2023-06-27 21:33:02',0.7419,0.6801,0.6491,0.6182,0.5564),
(2009,'XAU','USD',1927.95,1935.25,'2023-06-22','2023-06-22 00:00:00',-7.3,-0.3786,'2023-06-23 07:00:14','2023-06-27 21:33:02',61.985,56.8196,54.2369,51.6542,46.4888),
(2010,'XAG','USD',22.62,23.075,'2023-06-22','2023-06-22 00:00:00',-0.455,-2.0115,'2023-06-23 07:05:10','2023-06-27 21:33:02',0.7272,0.6666,0.6363,0.606,0.5454),
(2011,'XAU','USD',1919.35,1927.95,'2023-06-23','2023-06-23 00:00:00',-8.6,-0.4481,'2023-06-24 18:52:46','2023-06-27 21:33:02',61.7085,56.5662,53.995,51.4238,46.2814),
(2012,'XAG','USD',22.34,22.62,'2023-06-23','2023-06-23 00:00:00',-0.28,-1.2534,'2023-06-24 18:53:01','2023-06-27 21:33:02',0.7182,0.6584,0.6285,0.5985,0.5387),
(2013,'XAU','USD',1930.55,1919.35,'2023-06-26','2023-06-26 00:00:00',11.2,0.5801,'2023-06-27 07:00:12','2023-06-27 21:33:02',62.0686,56.8962,54.31,51.7239,46.5515),
(2014,'XAG','USD',22.8,22.34,'2023-06-26','2023-06-26 00:00:00',0.46,2.0175,'2023-06-27 07:05:11','2023-06-27 21:33:02',0.733,0.672,0.6414,0.6109,0.5498),
(2015,'XAU','USD',1923.95,1930.55,'2023-06-27','2023-06-27 00:00:00',-6.6,-0.343,'2023-06-28 07:00:15','2023-06-28 07:00:15',61.8564,56.7017,54.1244,51.547,46.3923),
(2016,'XAG','USD',22.835,22.8,'2023-06-27','2023-06-27 00:00:00',0.035,0.1533,'2023-06-28 07:05:12','2023-06-28 07:05:12',0.7342,0.673,0.6424,0.6118,0.5506),
(2017,'XAU','USD',1909.85,1923.95,'2023-06-28','2023-06-28 00:00:00',-14.1,-0.7383,'2023-06-29 07:00:11','2023-06-29 07:00:11',61.4031,56.2862,53.7277,51.1693,46.0523),
(2018,'XAG','USD',22.61,22.835,'2023-06-28','2023-06-28 00:00:00',-0.225,-0.9951,'2023-06-29 07:05:09','2023-06-29 07:05:09',0.7269,0.6664,0.6361,0.6058,0.5452),
(2019,'XAU','USD',1909.85,1909.85,'2023-06-29','2023-06-29 00:00:00',0,0,'2023-06-30 07:00:11','2023-06-30 07:00:11',61.4031,56.2862,53.7277,51.1693,46.0523),
(2020,'XAG','USD',22.61,22.61,'2023-06-29','2023-06-29 00:00:00',0,0,'2023-06-30 07:05:12','2023-06-30 07:05:12',0.7269,0.6664,0.6361,0.6058,0.5452),
(2021,'XAU','USD',1903.55,1909.85,'2023-06-30','2023-06-30 00:00:00',-6.3,-0.331,'2023-07-01 07:00:13','2023-07-01 07:00:13',61.2006,56.1005,53.5505,51.0005,45.9004),
(2022,'XAG','USD',22.47,22.61,'2023-06-30','2023-06-30 00:00:00',-0.14,-0.6231,'2023-07-01 07:05:07','2023-07-01 07:05:07',0.7224,0.6622,0.6321,0.602,0.5418),
(2023,'XAU','USD',1913.75,1903.55,'2023-07-03','2023-07-03 00:00:00',10.2,0.533,'2023-07-04 19:21:56','2023-07-04 19:21:56',61.5285,56.4011,53.8374,51.2737,46.1464),
(2024,'XAG','USD',22.775,22.47,'2023-07-03','2023-07-03 00:00:00',0.305,1.3392,'2023-07-04 19:22:22','2023-07-04 19:22:22',0.7322,0.6712,0.6407,0.6102,0.5492),
(2025,'XAU','USD',1929.75,1929.75,'2023-07-05','2023-07-05 00:00:00',0,0,'2023-07-06 07:00:26','2023-07-06 07:00:26',62.0429,56.8727,54.2875,51.7024,46.5322),
(2026,'XAU','USD',1919.15,1929.75,'2023-07-06','2023-07-06 00:00:00',-10.6,-0.5523,'2023-07-07 07:00:09','2023-07-07 07:00:09',61.7021,56.5603,53.9893,51.4184,46.2766),
(2027,'XAG','USD',23.17,23.005,'2023-07-06','2023-07-06 00:00:00',0.165,0.7121,'2023-07-07 07:05:08','2023-07-07 07:05:08',0.7449,0.6829,0.6518,0.6208,0.5587),
(2028,'XAU','USD',1915.65,1919.15,'2023-07-07','2023-07-07 00:00:00',-3.5,-0.1827,'2023-07-08 07:00:19','2023-07-08 07:00:19',61.5896,56.4571,53.8909,51.3246,46.1922),
(2029,'XAG','USD',22.715,23.17,'2023-07-07','2023-07-07 00:00:00',-0.455,-2.0031,'2023-07-08 07:05:09','2023-07-08 07:05:09',0.7303,0.6694,0.639,0.6086,0.5477),
(2030,'XAG','USD',23.005,23.005,'2023-07-05','2023-07-05 00:00:00',0,0,'2023-07-08 07:57:54','2023-07-08 07:57:54',0.7396,0.678,0.6472,0.6164,0.5547),
(2031,'XAU','USD',1925.05,1915.65,'2023-07-10','2023-07-10 00:00:00',9.4,0.4883,'2023-07-11 07:00:10','2023-07-11 07:00:10',61.8918,56.7341,54.1553,51.5765,46.4188),
(2032,'XAG','USD',23.04,22.715,'2023-07-10','2023-07-10 00:00:00',0.325,1.4106,'2023-07-11 07:05:07','2023-07-11 07:05:07',0.7408,0.679,0.6482,0.6173,0.5556),
(2078,'XAG','USD',23.255,23.145,'2023-05-30','2023-05-30 00:00:00',0.11,0.473,'2023-07-11 16:16:59','2023-07-11 16:16:59',0.7477,0.6854,0.6542,0.6231,0.5607),
(2080,'XAU','USD',1936.2,1925.05,'2023-07-11','2023-07-11 00:00:00',11.15,0.5759,'2023-07-12 07:00:11','2023-07-12 07:00:11',62.2503,57.0628,54.469,51.8752,46.6877),
(2081,'XAG','USD',23.135,23.04,'2023-07-11','2023-07-11 00:00:00',0.095,0.4106,'2023-07-12 07:05:10','2023-07-12 07:05:10',0.7438,0.6818,0.6508,0.6198,0.5579),
(2082,'XAU','USD',1935.75,1936.2,'2023-07-12','2023-07-12 00:00:00',-0.45,-0.0232,'2023-07-13 07:00:12','2023-07-13 07:00:12',62.2358,57.0495,54.4563,51.8632,46.6769),
(2083,'XAG','USD',23.16,23.135,'2023-07-12','2023-07-12 00:00:00',0.025,0.1079,'2023-07-13 07:05:08','2023-07-13 07:05:08',0.7446,0.6826,0.6515,0.6205,0.5585),
(2084,'XAU','USD',1956.5,1959.6,'2023-07-14','2023-07-14 00:00:00',-3.1,-0.1584,'2023-07-15 07:00:12','2023-07-15 07:00:12',62.9029,57.661,55.0401,52.4191,47.1772),
(2085,'XAG','USD',24.77,24.26,'2023-07-14','2023-07-14 00:00:00',0.51,2.0589,'2023-07-15 07:05:12','2023-07-15 07:05:12',0.7964,0.73,0.6968,0.6636,0.5973),
(2086,'XAU','USD',1959.6,1935.75,'2023-07-13','2023-07-13 00:00:00',23.85,1.2171,'2023-07-15 08:02:43','2023-07-15 08:02:43',63.0026,57.7524,55.1273,52.5022,47.252),
(2087,'XAG','USD',24.26,23.16,'2023-07-13','2023-07-13 00:00:00',1.1,4.5342,'2023-07-15 08:03:08','2023-07-15 08:03:08',0.78,0.715,0.6825,0.65,0.585),
(2088,'XAG','USD',24.69,24.815,'2022-04-01','2022-04-01 00:00:00',-0.125,-0.5063,'2023-07-15 10:56:15','2023-07-15 10:56:15',0.7938,0.7277,0.6946,0.6615,0.5954),
(2089,'XAG','USD',24.665,24.69,'2022-04-04','2022-04-04 00:00:00',-0.025,-0.1014,'2023-07-15 10:56:16','2023-07-15 10:56:16',0.793,0.7269,0.6939,0.6608,0.5947),
(2090,'XAG','USD',24.665,24.665,'2022-04-05','2022-04-05 00:00:00',0,0,'2023-07-15 10:56:17','2023-07-15 10:56:17',0.793,0.7269,0.6939,0.6608,0.5947),
(2091,'XAG','USD',24.665,24.665,'2022-04-06','2022-04-06 00:00:00',0,0,'2023-07-15 10:56:18','2023-07-15 10:56:18',0.793,0.7269,0.6939,0.6608,0.5947),
(2092,'XAG','USD',24.665,24.665,'2022-04-07','2022-04-07 00:00:00',0,0,'2023-07-15 10:56:19','2023-07-15 10:56:19',0.793,0.7269,0.6939,0.6608,0.5947),
(2093,'XAG','USD',24.665,24.665,'2022-04-08','2022-04-08 00:00:00',0,0,'2023-07-15 10:56:20','2023-07-15 10:56:20',0.793,0.7269,0.6939,0.6608,0.5947),
(2094,'XAG','USD',24.665,24.665,'2022-04-11','2022-04-11 00:00:00',0,0,'2023-07-15 10:56:21','2023-07-15 10:56:21',0.793,0.7269,0.6939,0.6608,0.5947),
(2095,'XAG','USD',24.665,24.665,'2022-04-12','2022-04-12 00:00:00',0,0,'2023-07-15 10:56:21','2023-07-15 10:56:21',0.793,0.7269,0.6939,0.6608,0.5947),
(2096,'XAG','USD',24.665,24.665,'2022-04-13','2022-04-13 00:00:00',0,0,'2023-07-15 10:56:22','2023-07-15 10:56:22',0.793,0.7269,0.6939,0.6608,0.5947),
(2097,'XAG','USD',24.665,24.665,'2022-04-14','2022-04-14 00:00:00',0,0,'2023-07-15 10:56:23','2023-07-15 10:56:23',0.793,0.7269,0.6939,0.6608,0.5947),
(2098,'XAG','USD',24.665,24.665,'2022-04-15','2022-04-15 00:00:00',0,0,'2023-07-15 10:56:24','2023-07-15 10:56:24',0.793,0.7269,0.6939,0.6608,0.5947),
(2099,'XAG','USD',24.665,24.665,'2022-04-18','2022-04-18 00:00:00',0,0,'2023-07-15 10:56:25','2023-07-15 10:56:25',0.793,0.7269,0.6939,0.6608,0.5947),
(2100,'XAG','USD',24.665,24.665,'2022-04-19','2022-04-19 00:00:00',0,0,'2023-07-15 10:56:26','2023-07-15 10:56:26',0.793,0.7269,0.6939,0.6608,0.5947),
(2101,'XAG','USD',24.665,24.665,'2022-04-20','2022-04-20 00:00:00',0,0,'2023-07-15 10:56:27','2023-07-15 10:56:27',0.793,0.7269,0.6939,0.6608,0.5947),
(2102,'XAG','USD',24.665,24.665,'2022-04-21','2022-04-21 00:00:00',0,0,'2023-07-15 10:56:28','2023-07-15 10:56:28',0.793,0.7269,0.6939,0.6608,0.5947),
(2103,'XAG','USD',24.665,24.665,'2022-04-22','2022-04-22 00:00:00',0,0,'2023-07-15 10:56:29','2023-07-15 10:56:29',0.793,0.7269,0.6939,0.6608,0.5947),
(2104,'XAG','USD',24.665,24.665,'2022-04-25','2022-04-25 00:00:00',0,0,'2023-07-15 10:56:30','2023-07-15 10:56:30',0.793,0.7269,0.6939,0.6608,0.5947),
(2105,'XAG','USD',24.665,24.665,'2022-04-26','2022-04-26 00:00:00',0,0,'2023-07-15 10:56:31','2023-07-15 10:56:31',0.793,0.7269,0.6939,0.6608,0.5947),
(2106,'XAG','USD',24.665,24.665,'2022-04-27','2022-04-27 00:00:00',0,0,'2023-07-15 10:56:32','2023-07-15 10:56:32',0.793,0.7269,0.6939,0.6608,0.5947),
(2107,'XAG','USD',24.665,24.665,'2022-04-28','2022-04-28 00:00:00',0,0,'2023-07-15 10:56:33','2023-07-15 10:56:33',0.793,0.7269,0.6939,0.6608,0.5947),
(2108,'XAG','USD',24.665,24.665,'2022-04-29','2022-04-29 00:00:00',0,0,'2023-07-15 10:56:33','2023-07-15 10:56:33',0.793,0.7269,0.6939,0.6608,0.5947),
(2109,'XAG','USD',24.665,24.665,'2022-05-02','2022-05-02 00:00:00',0,0,'2023-07-15 10:56:34','2023-07-15 10:56:34',0.793,0.7269,0.6939,0.6608,0.5947),
(2110,'XAG','USD',24.665,24.665,'2022-05-03','2022-05-03 00:00:00',0,0,'2023-07-15 10:56:35','2023-07-15 10:56:35',0.793,0.7269,0.6939,0.6608,0.5947),
(2111,'XAG','USD',24.665,24.665,'2022-05-04','2022-05-04 00:00:00',0,0,'2023-07-15 10:56:36','2023-07-15 10:56:36',0.793,0.7269,0.6939,0.6608,0.5947),
(2112,'XAG','USD',24.665,24.665,'2022-05-05','2022-05-05 00:00:00',0,0,'2023-07-15 10:56:37','2023-07-15 10:56:37',0.793,0.7269,0.6939,0.6608,0.5947),
(2113,'XAG','USD',24.665,24.665,'2022-05-06','2022-05-06 00:00:00',0,0,'2023-07-15 10:56:38','2023-07-15 10:56:38',0.793,0.7269,0.6939,0.6608,0.5947),
(2114,'XAG','USD',24.665,24.665,'2022-05-09','2022-05-09 00:00:00',0,0,'2023-07-15 10:56:39','2023-07-15 10:56:39',0.793,0.7269,0.6939,0.6608,0.5947),
(2115,'XAG','USD',24.665,24.665,'2022-05-10','2022-05-10 00:00:00',0,0,'2023-07-15 10:56:40','2023-07-15 10:56:40',0.793,0.7269,0.6939,0.6608,0.5947),
(2116,'XAG','USD',24.665,24.665,'2022-05-11','2022-05-11 00:00:00',0,0,'2023-07-15 10:56:41','2023-07-15 10:56:41',0.793,0.7269,0.6939,0.6608,0.5947),
(2117,'XAG','USD',24.665,24.665,'2022-05-12','2022-05-12 00:00:00',0,0,'2023-07-15 10:56:42','2023-07-15 10:56:42',0.793,0.7269,0.6939,0.6608,0.5947),
(2118,'XAG','USD',24.665,24.665,'2022-05-13','2022-05-13 00:00:00',0,0,'2023-07-15 10:56:43','2023-07-15 10:56:43',0.793,0.7269,0.6939,0.6608,0.5947),
(2119,'XAG','USD',24.665,24.665,'2022-05-16','2022-05-16 00:00:00',0,0,'2023-07-15 10:56:44','2023-07-15 10:56:44',0.793,0.7269,0.6939,0.6608,0.5947),
(2120,'XAG','USD',24.665,24.665,'2022-05-17','2022-05-17 00:00:00',0,0,'2023-07-15 10:56:45','2023-07-15 10:56:45',0.793,0.7269,0.6939,0.6608,0.5947),
(2121,'XAG','USD',24.665,24.665,'2022-05-18','2022-05-18 00:00:00',0,0,'2023-07-15 10:56:46','2023-07-15 10:56:46',0.793,0.7269,0.6939,0.6608,0.5947),
(2122,'XAG','USD',24.665,24.665,'2022-05-19','2022-05-19 00:00:00',0,0,'2023-07-15 10:56:47','2023-07-15 10:56:47',0.793,0.7269,0.6939,0.6608,0.5947),
(2123,'XAG','USD',24.665,24.665,'2022-05-20','2022-05-20 00:00:00',0,0,'2023-07-15 10:56:48','2023-07-15 10:56:48',0.793,0.7269,0.6939,0.6608,0.5947),
(2124,'XAG','USD',24.665,24.665,'2022-05-23','2022-05-23 00:00:00',0,0,'2023-07-15 10:56:48','2023-07-15 10:56:48',0.793,0.7269,0.6939,0.6608,0.5947),
(2125,'XAG','USD',24.665,24.665,'2022-05-24','2022-05-24 00:00:00',0,0,'2023-07-15 10:56:49','2023-07-15 10:56:49',0.793,0.7269,0.6939,0.6608,0.5947),
(2126,'XAG','USD',24.665,24.665,'2022-05-25','2022-05-25 00:00:00',0,0,'2023-07-15 10:56:50','2023-07-15 10:56:50',0.793,0.7269,0.6939,0.6608,0.5947),
(2127,'XAG','USD',24.665,24.665,'2022-05-26','2022-05-26 00:00:00',0,0,'2023-07-15 10:56:51','2023-07-15 10:56:51',0.793,0.7269,0.6939,0.6608,0.5947),
(2128,'XAG','USD',24.665,24.665,'2022-05-27','2022-05-27 00:00:00',0,0,'2023-07-15 10:56:52','2023-07-15 10:56:52',0.793,0.7269,0.6939,0.6608,0.5947),
(2129,'XAG','USD',24.665,24.665,'2022-05-31','2022-05-31 00:00:00',0,0,'2023-07-15 10:56:53','2023-07-15 10:56:53',0.793,0.7269,0.6939,0.6608,0.5947),
(2130,'XAG','USD',24.665,24.665,'2022-06-01','2022-06-01 00:00:00',0,0,'2023-07-15 10:56:54','2023-07-15 10:56:54',0.793,0.7269,0.6939,0.6608,0.5947),
(2131,'XAG','USD',24.665,24.665,'2022-06-02','2022-06-02 00:00:00',0,0,'2023-07-15 10:56:55','2023-07-15 10:56:55',0.793,0.7269,0.6939,0.6608,0.5947),
(2132,'XAG','USD',24.665,24.665,'2022-06-03','2022-06-03 00:00:00',0,0,'2023-07-15 10:56:56','2023-07-15 10:56:56',0.793,0.7269,0.6939,0.6608,0.5947),
(2133,'XAG','USD',24.665,24.665,'2022-06-06','2022-06-06 00:00:00',0,0,'2023-07-15 10:56:57','2023-07-15 10:56:57',0.793,0.7269,0.6939,0.6608,0.5947),
(2134,'XAG','USD',24.665,24.665,'2022-06-07','2022-06-07 00:00:00',0,0,'2023-07-15 10:56:58','2023-07-15 10:56:58',0.793,0.7269,0.6939,0.6608,0.5947),
(2135,'XAG','USD',24.665,24.665,'2022-06-08','2022-06-08 00:00:00',0,0,'2023-07-15 10:56:59','2023-07-15 10:56:59',0.793,0.7269,0.6939,0.6608,0.5947),
(2136,'XAG','USD',21.93,24.665,'2022-06-09','2022-06-09 00:00:00',-2.735,-12.4715,'2023-07-15 10:57:00','2023-07-15 10:57:00',0.7051,0.6463,0.6169,0.5876,0.5288),
(2137,'XAG','USD',21.59,21.93,'2022-06-10','2022-06-10 00:00:00',-0.34,-1.5748,'2023-07-15 10:57:01','2023-07-15 10:57:01',0.6941,0.6363,0.6074,0.5784,0.5206),
(2138,'XAG','USD',21.56,21.59,'2022-06-13','2022-06-13 00:00:00',-0.03,-0.1391,'2023-07-15 10:57:02','2023-07-15 10:57:02',0.6932,0.6354,0.6065,0.5776,0.5199),
(2139,'XAG','USD',21.235,21.56,'2022-06-14','2022-06-14 00:00:00',-0.325,-1.5305,'2023-07-15 10:57:03','2023-07-15 10:57:03',0.6827,0.6258,0.5974,0.5689,0.512),
(2140,'XAG','USD',21.46,21.235,'2022-06-15','2022-06-15 00:00:00',0.225,1.0485,'2023-07-15 10:57:04','2023-07-15 10:57:04',0.69,0.6325,0.6037,0.575,0.5175),
(2141,'XAG','USD',21.435,21.46,'2022-06-16','2022-06-16 00:00:00',-0.025,-0.1166,'2023-07-15 10:57:05','2023-07-15 10:57:05',0.6892,0.6317,0.603,0.5743,0.5169),
(2142,'XAG','USD',21.845,21.435,'2022-06-17','2022-06-17 00:00:00',0.41,1.8769,'2023-07-15 10:57:06','2023-07-15 10:57:06',0.7023,0.6438,0.6145,0.5853,0.5267),
(2143,'XAG','USD',21.67,21.655,'2022-06-21','2022-06-21 00:00:00',0.015,0.0692,'2023-07-15 10:57:07','2023-07-15 10:57:07',0.6967,0.6386,0.6096,0.5806,0.5225),
(2144,'XAG','USD',21.42,21.67,'2022-06-22','2022-06-22 00:00:00',-0.25,-1.1671,'2023-07-15 10:57:08','2023-07-15 10:57:08',0.6887,0.6313,0.6026,0.5739,0.5165),
(2145,'XAG','USD',21.185,21.42,'2022-06-23','2022-06-23 00:00:00',-0.235,-1.1093,'2023-07-15 10:57:09','2023-07-15 10:57:09',0.6811,0.6244,0.596,0.5676,0.5108),
(2146,'XAG','USD',20.86,21.185,'2022-06-24','2022-06-24 00:00:00',-0.325,-1.558,'2023-07-15 10:57:10','2023-07-15 10:57:10',0.6707,0.6148,0.5868,0.5589,0.503),
(2147,'XAG','USD',21.46,20.86,'2022-06-27','2022-06-27 00:00:00',0.6,2.7959,'2023-07-15 10:57:11','2023-07-15 10:57:11',0.69,0.6325,0.6037,0.575,0.5175),
(2148,'XAG','USD',21.235,21.46,'2022-06-28','2022-06-28 00:00:00',-0.225,-1.0596,'2023-07-15 10:57:12','2023-07-15 10:57:12',0.6827,0.6258,0.5974,0.5689,0.512),
(2149,'XAG','USD',20.975,21.235,'2022-06-29','2022-06-29 00:00:00',-0.26,-1.2396,'2023-07-15 10:57:13','2023-07-15 10:57:13',0.6744,0.6182,0.5901,0.562,0.5058),
(2150,'XAG','USD',20.415,20.975,'2022-06-30','2022-06-30 00:00:00',-0.56,-2.7431,'2023-07-15 10:57:14','2023-07-15 10:57:14',0.6564,0.6017,0.5743,0.547,0.4923),
(2151,'XAG','USD',19.725,20.415,'2022-07-01','2022-07-01 00:00:00',-0.69,-3.4981,'2023-07-15 10:58:01','2023-07-15 10:58:01',0.6342,0.5813,0.5549,0.5285,0.4756),
(2152,'XAG','USD',19.84,19.855,'2022-07-05','2022-07-05 00:00:00',-0.015,-0.0756,'2023-07-15 10:58:02','2023-07-15 10:58:02',0.6379,0.5847,0.5581,0.5316,0.4784),
(2153,'XAG','USD',19.22,19.84,'2022-07-06','2022-07-06 00:00:00',-0.62,-3.2258,'2023-07-15 10:58:03','2023-07-15 10:58:03',0.6179,0.5664,0.5407,0.5149,0.4635),
(2154,'XAG','USD',19.425,19.22,'2022-07-07','2022-07-07 00:00:00',0.205,1.0553,'2023-07-15 10:58:04','2023-07-15 10:58:04',0.6245,0.5725,0.5465,0.5204,0.4684),
(2155,'XAG','USD',19.2,19.425,'2022-07-08','2022-07-08 00:00:00',-0.225,-1.1719,'2023-07-15 10:58:04','2023-07-15 10:58:04',0.6173,0.5659,0.5401,0.5144,0.463),
(2156,'XAG','USD',19.21,19.2,'2022-07-11','2022-07-11 00:00:00',0.01,0.0521,'2023-07-15 10:58:05','2023-07-15 10:58:05',0.6176,0.5661,0.5404,0.5147,0.4632),
(2157,'XAG','USD',18.865,19.21,'2022-07-12','2022-07-12 00:00:00',-0.345,-1.8288,'2023-07-15 10:58:06','2023-07-15 10:58:06',0.6065,0.556,0.5307,0.5054,0.4549),
(2158,'XAG','USD',18.955,18.865,'2022-07-13','2022-07-13 00:00:00',0.09,0.4748,'2023-07-15 10:58:07','2023-07-15 10:58:07',0.6094,0.5586,0.5332,0.5078,0.4571),
(2159,'XAG','USD',18.76,18.955,'2022-07-14','2022-07-14 00:00:00',-0.195,-1.0394,'2023-07-15 10:58:08','2023-07-15 10:58:08',0.6031,0.5529,0.5278,0.5026,0.4524),
(2160,'XAG','USD',24.64,24.35,'2022-03-01','2022-03-01 00:00:00',0.29,1.1769,'2023-07-15 10:59:10','2023-07-15 10:59:10',0.7922,0.7262,0.6932,0.6602,0.5941),
(2161,'XAG','USD',25.075,24.64,'2022-03-02','2022-03-02 00:00:00',0.435,1.7348,'2023-07-15 10:59:11','2023-07-15 10:59:11',0.8062,0.739,0.7054,0.6718,0.6046),
(2162,'XAG','USD',25.31,25.075,'2022-03-03','2022-03-03 00:00:00',0.235,0.9285,'2023-07-15 10:59:12','2023-07-15 10:59:12',0.8137,0.7459,0.712,0.6781,0.6103),
(2163,'XAG','USD',25.15,25.31,'2022-03-04','2022-03-04 00:00:00',-0.16,-0.6362,'2023-07-15 10:59:13','2023-07-15 10:59:13',0.8086,0.7412,0.7075,0.6738,0.6064),
(2164,'XAG','USD',25.74,25.15,'2022-03-07','2022-03-07 00:00:00',0.59,2.2922,'2023-07-15 10:59:14','2023-07-15 10:59:14',0.8276,0.7586,0.7241,0.6896,0.6207),
(2165,'XAG','USD',26.12,25.74,'2022-03-08','2022-03-08 00:00:00',0.38,1.4548,'2023-07-15 10:59:15','2023-07-15 10:59:15',0.8398,0.7698,0.7348,0.6998,0.6298),
(2166,'XAG','USD',26.175,26.12,'2022-03-09','2022-03-09 00:00:00',0.055,0.2101,'2023-07-15 10:59:16','2023-07-15 10:59:16',0.8415,0.7714,0.7364,0.7013,0.6312),
(2167,'XAG','USD',25.945,26.175,'2022-03-10','2022-03-10 00:00:00',-0.23,-0.8865,'2023-07-15 10:59:17','2023-07-15 10:59:17',0.8342,0.7646,0.7299,0.6951,0.6256),
(2168,'XAG','USD',25.655,25.945,'2022-03-11','2022-03-11 00:00:00',-0.29,-1.1304,'2023-07-15 10:59:17','2023-07-15 10:59:17',0.8248,0.7561,0.7217,0.6874,0.6186),
(2169,'XAG','USD',25.375,25.655,'2022-03-14','2022-03-14 00:00:00',-0.28,-1.1034,'2023-07-15 10:59:18','2023-07-15 10:59:18',0.8158,0.7478,0.7138,0.6799,0.6119),
(2170,'XAG','USD',24.635,25.375,'2022-03-15','2022-03-15 00:00:00',-0.74,-3.0039,'2023-07-15 10:59:19','2023-07-15 10:59:19',0.792,0.726,0.693,0.66,0.594),
(2171,'XAG','USD',24.945,24.635,'2022-03-16','2022-03-16 00:00:00',0.31,1.2427,'2023-07-15 10:59:20','2023-07-15 10:59:20',0.802,0.7352,0.7018,0.6683,0.6015),
(2172,'XAG','USD',25.34,24.945,'2022-03-17','2022-03-17 00:00:00',0.395,1.5588,'2023-07-15 10:59:21','2023-07-15 10:59:21',0.8147,0.7468,0.7129,0.6789,0.611),
(2173,'XAG','USD',25.235,25.34,'2022-03-18','2022-03-18 00:00:00',-0.105,-0.4161,'2023-07-15 10:59:22','2023-07-15 10:59:22',0.8113,0.7437,0.7099,0.6761,0.6085),
(2174,'XAG','USD',25.035,25.235,'2022-03-21','2022-03-21 00:00:00',-0.2,-0.7989,'2023-07-15 10:59:23','2023-07-15 10:59:23',0.8049,0.7378,0.7043,0.6707,0.6037),
(2175,'XAG','USD',25.085,25.035,'2022-03-22','2022-03-22 00:00:00',0.05,0.1993,'2023-07-15 10:59:24','2023-07-15 10:59:24',0.8065,0.7393,0.7057,0.6721,0.6049),
(2176,'XAG','USD',25.015,25.085,'2022-03-23','2022-03-23 00:00:00',-0.07,-0.2798,'2023-07-15 10:59:25','2023-07-15 10:59:25',0.8043,0.7372,0.7037,0.6702,0.6032),
(2177,'XAG','USD',25.315,25.015,'2022-03-24','2022-03-24 00:00:00',0.3,1.1851,'2023-07-15 10:59:26','2023-07-15 10:59:26',0.8139,0.7461,0.7122,0.6782,0.6104),
(2178,'XAG','USD',25.62,25.315,'2022-03-25','2022-03-25 00:00:00',0.305,1.1905,'2023-07-15 10:59:27','2023-07-15 10:59:27',0.8237,0.7551,0.7207,0.6864,0.6178),
(2179,'XAG','USD',24.905,25.62,'2022-03-28','2022-03-28 00:00:00',-0.715,-2.8709,'2023-07-15 10:59:28','2023-07-15 10:59:28',0.8007,0.734,0.7006,0.6673,0.6005),
(2180,'XAG','USD',24.64,24.905,'2022-03-29','2022-03-29 00:00:00',-0.265,-1.0755,'2023-07-15 10:59:29','2023-07-15 10:59:29',0.7922,0.7262,0.6932,0.6602,0.5941),
(2181,'XAG','USD',24.755,24.64,'2022-03-30','2022-03-30 00:00:00',0.115,0.4646,'2023-07-15 10:59:29','2023-07-15 10:59:29',0.7959,0.7296,0.6964,0.6632,0.5969),
(2182,'XAU','USD',1955.05,1956.5,'2023-07-17','2023-07-17 00:00:00',-1.45,-0.0742,'2023-07-18 07:00:17','2023-07-18 07:00:17',62.8563,57.6183,54.9993,52.3803,47.1422),
(2183,'XAG','USD',24.81,24.77,'2023-07-17','2023-07-17 00:00:00',0.04,0.1612,'2023-07-18 07:05:11','2023-07-18 07:05:11',0.7977,0.7312,0.698,0.6647,0.5982),
(2184,'XAU','USD',1961.95,1955.05,'2023-07-18','2023-07-18 00:00:00',6.9,0.3517,'2023-07-19 07:00:11','2023-07-19 07:00:11',63.0782,57.8216,55.1934,52.5651,47.3086),
(2185,'XAG','USD',24.885,24.81,'2023-07-18','2023-07-18 00:00:00',0.075,0.3014,'2023-07-19 07:05:09','2023-07-19 07:05:09',0.8001,0.7334,0.7001,0.6667,0.6001),
(2186,'XAU','USD',1978.15,1961.95,'2023-07-19','2023-07-19 00:00:00',16.2,0.8189,'2023-07-20 07:00:24','2023-07-20 07:00:24',63.599,58.2991,55.6491,52.9992,47.6992),
(2187,'XAG','USD',25.015,24.885,'2023-07-19','2023-07-19 00:00:00',0.13,0.5197,'2023-07-20 07:05:13','2023-07-20 07:05:13',0.8043,0.7372,0.7037,0.6702,0.6032),
(2188,'XAU','USD',1981.5,1978.15,'2023-07-20','2023-07-20 00:00:00',3.35,0.1691,'2023-07-21 07:00:12','2023-07-21 07:00:12',63.7067,58.3978,55.7434,53.0889,47.78),
(2189,'XAG','USD',25.175,25.015,'2023-07-20','2023-07-20 00:00:00',0.16,0.6356,'2023-07-21 07:05:13','2023-07-21 07:05:13',0.8094,0.7419,0.7082,0.6745,0.607),
(2190,'XAU','USD',1963.8,1981.5,'2023-07-21','2023-07-21 00:00:00',-17.7,-0.9013,'2023-07-22 04:30:10','2023-07-22 04:30:10',63.1376,57.8762,55.2454,52.6147,47.3532),
(2191,'XAG','USD',24.73,25.175,'2023-07-21','2023-07-21 00:00:00',-0.445,-1.7994,'2023-07-22 04:32:08','2023-07-22 04:32:08',0.7951,0.7288,0.6957,0.6626,0.5963),
(2194,'XAU','USD',1964.75,1963.8,'2023-07-24','2023-07-24 00:00:00',0.95,0.0484,'2023-07-25 06:00:13','2023-07-25 06:00:13',63.1682,57.9042,55.2722,52.6401,47.3761),
(2195,'XAG','USD',24.59,24.73,'2023-07-24','2023-07-24 00:00:00',-0.14,-0.5693,'2023-07-25 06:10:12','2023-07-25 06:10:12',0.7906,0.7247,0.6918,0.6588,0.5929),
(2196,'XAU','USD',1963.1,1964.75,'2023-07-25','2023-07-25 00:00:00',-1.65,-0.0841,'2023-07-26 06:00:10','2023-07-26 06:00:10',63.1151,57.8555,55.2257,52.5959,47.3363),
(2197,'XAG','USD',24.555,24.59,'2023-07-25','2023-07-25 00:00:00',-0.035,-0.1425,'2023-07-26 06:10:09','2023-07-26 06:10:09',0.7895,0.7237,0.6908,0.6579,0.5921),
(2198,'XAU','USD',1972,1963.1,'2023-07-26','2023-07-26 00:00:00',8.9,0.4513,'2023-07-27 06:00:12','2023-07-27 06:00:12',63.4013,58.1178,55.4761,52.8344,47.551),
(2199,'XAG','USD',24.67,24.555,'2023-07-26','2023-07-26 00:00:00',0.115,0.4662,'2023-07-27 06:10:12','2023-07-27 06:10:12',0.7932,0.7271,0.694,0.661,0.5949),
(2200,'XAU','USD',1975.2,1972,'2023-07-27','2023-07-27 00:00:00',3.2,0.162,'2023-07-28 06:00:14','2023-07-28 06:00:14',63.5042,58.2121,55.5661,52.9201,47.6281),
(2201,'XAG','USD',25.01,24.67,'2023-07-27','2023-07-27 00:00:00',0.34,1.3595,'2023-07-28 06:10:12','2023-07-28 06:10:12',0.8041,0.7371,0.7036,0.6701,0.6031),
(2202,'XAU','USD',1950.15,1975.2,'2023-07-28','2023-07-28 00:00:00',-25.05,-1.2845,'2023-07-29 06:00:11','2023-07-29 06:00:11',62.6988,57.4739,54.8614,52.249,47.0241),
(2203,'XAU','USD',1955.55,1950.15,'2023-07-31','2023-07-31 00:00:00',5.4,0.2761,'2023-08-01 06:00:12','2023-08-01 06:00:12',62.8724,57.633,55.0133,52.3937,47.1543),
(2204,'XAG','USD',24.355,24.225,'2023-07-31','2023-07-31 00:00:00',0.13,0.5338,'2023-08-01 06:10:12','2023-08-01 06:10:12',0.783,0.7178,0.6852,0.6525,0.5873),
(2205,'XAU','USD',1956.75,1955.55,'2023-08-01','2023-08-01 00:00:00',1.2,0.0613,'2023-08-02 06:00:13','2023-08-02 06:00:13',62.911,57.6684,55.0471,52.4258,47.1832),
(2206,'XAG','USD',24.515,24.355,'2023-08-01','2023-08-01 00:00:00',0.16,0.6527,'2023-08-02 06:10:09','2023-08-02 06:10:09',0.7882,0.7225,0.6897,0.6568,0.5911),
(2207,'XAU','USD',1949.7,1956.75,'2023-08-02','2023-08-02 00:00:00',-7.05,-0.3616,'2023-08-03 06:00:13','2023-08-03 06:00:13',62.6843,57.4606,54.8488,52.2369,47.0132),
(2208,'XAG','USD',24.41,24.515,'2023-08-02','2023-08-02 00:00:00',-0.105,-0.4302,'2023-08-03 06:10:13','2023-08-03 06:10:13',0.7848,0.7194,0.6867,0.654,0.5886),
(2209,'XAU','USD',1936.9,1949.7,'2023-08-03','2023-08-03 00:00:00',-12.8,-0.6608,'2023-08-04 06:00:12','2023-08-04 06:00:12',62.2728,57.0834,54.4887,51.894,46.7046),
(2210,'XAG','USD',23.555,24.41,'2023-08-03','2023-08-03 00:00:00',-0.855,-3.6298,'2023-08-04 06:10:13','2023-08-04 06:10:13',0.7573,0.6942,0.6626,0.6311,0.568),
(2211,'XAU','USD',1934,1936.9,'2023-08-04','2023-08-04 00:00:00',-2.9,-0.1499,'2023-08-05 06:00:17','2023-08-05 06:00:17',62.1795,56.9979,54.4071,51.8163,46.6347),
(2212,'XAG','USD',23.45,23.555,'2023-08-04','2023-08-04 00:00:00',-0.105,-0.4478,'2023-08-05 06:10:07','2023-08-05 06:10:07',0.7539,0.6911,0.6597,0.6283,0.5655),
(2213,'XAU','USD',1936.9,1934,'2023-08-07','2023-08-07 00:00:00',2.9,0.1497,'2023-08-08 06:00:13','2023-08-08 06:00:13',62.2728,57.0834,54.4887,51.894,46.7046),
(2214,'XAG','USD',23.395,23.45,'2023-08-07','2023-08-07 00:00:00',-0.055,-0.2351,'2023-08-08 06:10:12','2023-08-08 06:10:12',0.7522,0.6895,0.6581,0.6268,0.5641),
(2215,'XAU','USD',1934.8,1936.9,'2023-08-08','2023-08-08 00:00:00',-2.1,-0.1085,'2023-08-11 07:20:12','2023-08-11 07:20:12',62.2053,57.0215,54.4296,51.8377,46.6539),
(2216,'XAU','USD',1928.4,1934.8,'2023-08-09','2023-08-09 00:00:00',-6.4,-0.3319,'2023-08-11 07:20:14','2023-08-11 07:20:14',61.9995,56.8329,54.2496,51.6662,46.4996),
(2217,'XAU','USD',1920.1,1928.4,'2023-08-10','2023-08-10 00:00:00',-8.3,-0.4323,'2023-08-11 07:20:15','2023-08-11 07:20:15',61.7326,56.5883,54.0161,51.4439,46.2995),
(2218,'XAG','USD',23.04,23.395,'2023-08-08','2023-08-08 00:00:00',-0.355,-1.5408,'2023-08-11 07:23:45','2023-08-11 07:23:45',0.7408,0.679,0.6482,0.6173,0.5556),
(2219,'XAG','USD',22.705,23.04,'2023-08-09','2023-08-09 00:00:00',-0.335,-1.4754,'2023-08-11 07:23:47','2023-08-11 07:23:47',0.73,0.6692,0.6387,0.6083,0.5475),
(2220,'XAG','USD',22.8,22.705,'2023-08-10','2023-08-10 00:00:00',0.095,0.4167,'2023-08-11 07:23:48','2023-08-11 07:23:48',0.733,0.672,0.6414,0.6109,0.5498),
(2221,'XAG','USD',18.46,18.76,'2022-07-15','2022-07-15 00:00:00',-0.3,-1.6251,'2023-08-11 07:26:08','2023-08-11 07:26:08',0.5935,0.544,0.5193,0.4946,0.4451),
(2222,'XAG','USD',18.88,18.46,'2022-07-18','2022-07-18 00:00:00',0.42,2.2246,'2023-08-11 07:26:09','2023-08-11 07:26:09',0.607,0.5564,0.5311,0.5058,0.4553),
(2223,'XAG','USD',18.9,18.88,'2022-07-19','2022-07-19 00:00:00',0.02,0.1058,'2023-08-11 07:26:11','2023-08-11 07:26:11',0.6076,0.557,0.5317,0.5064,0.4557),
(2224,'XAG','USD',18.78,18.9,'2022-07-20','2022-07-20 00:00:00',-0.12,-0.639,'2023-08-11 07:26:12','2023-08-11 07:26:12',0.6038,0.5535,0.5283,0.5032,0.4528),
(2225,'XAG','USD',18.265,18.78,'2022-07-21','2022-07-21 00:00:00',-0.515,-2.8196,'2023-08-11 07:26:13','2023-08-11 07:26:13',0.5872,0.5383,0.5138,0.4894,0.4404),
(2226,'XAG','USD',18.81,18.265,'2022-07-22','2022-07-22 00:00:00',0.545,2.8974,'2023-08-11 07:26:14','2023-08-11 07:26:14',0.6048,0.5544,0.5292,0.504,0.4536),
(2227,'XAG','USD',18.755,18.81,'2022-07-25','2022-07-25 00:00:00',-0.055,-0.2933,'2023-08-11 07:26:16','2023-08-11 07:26:16',0.603,0.5527,0.5276,0.5025,0.4522),
(2228,'XAG','USD',18.54,18.755,'2022-07-26','2022-07-26 00:00:00',-0.215,-1.1597,'2023-08-11 07:26:17','2023-08-11 07:26:17',0.5961,0.5464,0.5216,0.4967,0.4471),
(2229,'XAG','USD',18.765,18.54,'2022-07-27','2022-07-27 00:00:00',0.225,1.199,'2023-08-11 07:26:18','2023-08-11 07:26:18',0.6033,0.553,0.5279,0.5028,0.4525),
(2230,'XAG','USD',19.325,18.765,'2022-07-28','2022-07-28 00:00:00',0.56,2.8978,'2023-08-11 07:26:20','2023-08-11 07:26:20',0.6213,0.5695,0.5436,0.5178,0.466),
(2231,'XAG','USD',20.065,19.325,'2022-07-29','2022-07-29 00:00:00',0.74,3.688,'2023-08-11 07:26:21','2023-08-11 07:26:21',0.6451,0.5913,0.5645,0.5376,0.4838),
(2232,'XAG','USD',20.405,20.065,'2022-08-01','2022-08-01 00:00:00',0.34,1.6663,'2023-08-11 07:26:22','2023-08-11 07:26:22',0.656,0.6014,0.574,0.5467,0.492),
(2233,'XAG','USD',20.335,20.405,'2022-08-02','2022-08-02 00:00:00',-0.07,-0.3442,'2023-08-11 07:26:23','2023-08-11 07:26:23',0.6538,0.5993,0.5721,0.5448,0.4903),
(2234,'XAG','USD',19.92,20.335,'2022-08-03','2022-08-03 00:00:00',-0.415,-2.0833,'2023-08-11 07:26:24','2023-08-11 07:26:24',0.6404,0.5871,0.5604,0.5337,0.4803),
(2235,'XAG','USD',20.265,19.92,'2022-08-04','2022-08-04 00:00:00',0.345,1.7024,'2023-08-11 07:26:26','2023-08-11 07:26:26',0.6515,0.5972,0.5701,0.5429,0.4887),
(2236,'XAG','USD',20.06,20.265,'2022-08-05','2022-08-05 00:00:00',-0.205,-1.0219,'2023-08-11 07:26:27','2023-08-11 07:26:27',0.6449,0.5912,0.5643,0.5375,0.4837),
(2237,'XAG','USD',20.195,20.06,'2022-08-08','2022-08-08 00:00:00',0.135,0.6685,'2023-08-11 07:26:28','2023-08-11 07:26:28',0.6493,0.5952,0.5681,0.5411,0.487),
(2238,'XAG','USD',20.6,20.195,'2022-08-09','2022-08-09 00:00:00',0.405,1.966,'2023-08-11 07:26:30','2023-08-11 07:26:30',0.6623,0.6071,0.5795,0.5519,0.4967),
(2239,'XAG','USD',20.435,20.6,'2022-08-10','2022-08-10 00:00:00',-0.165,-0.8074,'2023-08-11 07:26:31','2023-08-11 07:26:31',0.657,0.6023,0.5749,0.5475,0.4928),
(2240,'XAG','USD',20.54,20.435,'2022-08-11','2022-08-11 00:00:00',0.105,0.5112,'2023-08-11 07:26:32','2023-08-11 07:26:32',0.6604,0.6053,0.5778,0.5503,0.4953),
(2241,'XAG','USD',20.265,20.54,'2022-08-12','2022-08-12 00:00:00',-0.275,-1.357,'2023-08-11 07:26:34','2023-08-11 07:26:34',0.6515,0.5972,0.5701,0.5429,0.4887),
(2242,'XAG','USD',20.33,20.265,'2022-08-15','2022-08-15 00:00:00',0.065,0.3197,'2023-08-11 07:26:35','2023-08-11 07:26:35',0.6536,0.5992,0.5719,0.5447,0.4902),
(2243,'XAG','USD',20.125,20.33,'2022-08-16','2022-08-16 00:00:00',-0.205,-1.0186,'2023-08-11 07:26:36','2023-08-11 07:26:36',0.647,0.5931,0.5662,0.5392,0.4853),
(2244,'XAG','USD',20.125,20.125,'2022-08-17','2022-08-17 00:00:00',0,0,'2023-08-11 07:26:37','2023-08-11 07:26:37',0.647,0.5931,0.5662,0.5392,0.4853),
(2245,'XAG','USD',19.825,20.125,'2022-08-18','2022-08-18 00:00:00',-0.3,-1.5132,'2023-08-11 07:26:39','2023-08-11 07:26:39',0.6374,0.5843,0.5577,0.5312,0.478),
(2246,'XAG','USD',19.23,19.825,'2022-08-19','2022-08-19 00:00:00',-0.595,-3.0941,'2023-08-11 07:26:40','2023-08-11 07:26:40',0.6183,0.5667,0.541,0.5152,0.4637),
(2247,'XAG','USD',18.895,19.23,'2022-08-22','2022-08-22 00:00:00',-0.335,-1.773,'2023-08-11 07:26:41','2023-08-11 07:26:41',0.6075,0.5569,0.5316,0.5062,0.4556),
(2248,'XAG','USD',18.99,18.895,'2022-08-23','2022-08-23 00:00:00',0.095,0.5003,'2023-08-11 07:26:43','2023-08-11 07:26:43',0.6105,0.5597,0.5342,0.5088,0.4579),
(2249,'XAG','USD',19,18.99,'2022-08-24','2022-08-24 00:00:00',0.01,0.0526,'2023-08-11 07:26:44','2023-08-11 07:26:44',0.6109,0.56,0.5345,0.5091,0.4581),
(2250,'XAG','USD',19.325,19,'2022-08-25','2022-08-25 00:00:00',0.325,1.6818,'2023-08-11 07:26:45','2023-08-11 07:26:45',0.6213,0.5695,0.5436,0.5178,0.466),
(2251,'XAG','USD',19.215,19.325,'2022-08-26','2022-08-26 00:00:00',-0.11,-0.5725,'2023-08-11 07:26:47','2023-08-11 07:26:47',0.6178,0.5663,0.5406,0.5148,0.4633),
(2252,'XAG','USD',19.215,19.215,'2022-08-29','2022-08-29 00:00:00',0,0,'2023-08-11 07:26:48','2023-08-11 07:26:48',0.6178,0.5663,0.5406,0.5148,0.4633),
(2253,'XAG','USD',18.695,19.215,'2022-08-30','2022-08-30 00:00:00',-0.52,-2.7815,'2023-08-11 07:26:49','2023-08-11 07:26:49',0.6011,0.551,0.5259,0.5009,0.4508),
(2254,'XAG','USD',17.945,18.695,'2022-08-31','2022-08-31 00:00:00',-0.75,-4.1794,'2023-08-11 07:26:51','2023-08-11 07:26:51',0.5769,0.5289,0.5048,0.4808,0.4327),
(2255,'XAU','USD',1918.05,1920.1,'2023-08-11','2023-08-11 00:00:00',-2.05,-0.1069,'2023-08-12 06:00:12','2023-08-12 06:00:12',61.6667,56.5278,53.9584,51.3889,46.2501),
(2256,'XAG','USD',22.69,22.8,'2023-08-11','2023-08-11 00:00:00',-0.11,-0.4848,'2023-08-12 06:10:11','2023-08-12 06:10:11',0.7295,0.6687,0.6383,0.6079,0.5471),
(2257,'XAU','USD',1904.1,1913.5,'2023-08-15','2023-08-15 00:00:00',-9.4,-0.4937,'2023-08-16 07:31:44','2023-08-16 07:31:44',61.2182,56.1167,53.566,51.0152,45.9137),
(2258,'XAU','USD',1913.5,1918.05,'2023-08-14','2023-08-14 00:00:00',-4.55,-0.2378,'2023-08-16 07:32:35','2023-08-16 07:32:35',61.5205,56.3937,53.8304,51.267,46.1403),
(2259,'XAG','USD',22.725,22.69,'2023-08-14','2023-08-14 00:00:00',0.035,0.154,'2023-08-16 07:35:41','2023-08-16 07:35:41',0.7306,0.6697,0.6393,0.6089,0.548),
(2260,'XAG','USD',22.41,22.725,'2023-08-15','2023-08-15 00:00:00',-0.315,-1.4056,'2023-08-16 07:36:16','2023-08-16 07:36:16',0.7205,0.6605,0.6304,0.6004,0.5404),
(2261,'XAU','USD',1906.8,1904.1,'2023-08-16','2023-08-16 00:00:00',2.7,0.1416,'2023-08-17 06:00:11','2023-08-17 06:00:11',61.305,56.1963,53.6419,51.0875,45.9788),
(2262,'XAG','USD',22.695,22.41,'2023-08-16','2023-08-16 00:00:00',0.285,1.2558,'2023-08-17 06:10:16','2023-08-17 06:10:16',0.7297,0.6689,0.6385,0.6081,0.5472),
(2263,'XAU','USD',1893.95,1906.8,'2023-08-17','2023-08-17 00:00:00',-12.85,-0.6785,'2023-08-18 06:00:08','2023-08-18 06:00:08',60.8919,55.8176,53.2804,50.7433,45.6689),
(2264,'XAG','USD',22.705,22.695,'2023-08-17','2023-08-17 00:00:00',0.01,0.044,'2023-08-18 06:10:11','2023-08-18 06:10:11',0.73,0.6692,0.6387,0.6083,0.5475),
(2265,'XAU','USD',1891.75,1893.95,'2023-08-18','2023-08-18 00:00:00',-2.2,-0.1163,'2023-08-19 06:00:07','2023-08-19 06:00:07',60.8212,55.7527,53.2185,50.6843,45.6159),
(2266,'XAG','USD',22.79,22.705,'2023-08-18','2023-08-18 00:00:00',0.085,0.373,'2023-08-19 06:10:07','2023-08-19 06:10:07',0.7327,0.6717,0.6411,0.6106,0.5495),
(2267,'XAU','USD',1890.1,1891.75,'2023-08-21','2023-08-21 00:00:00',-1.65,-0.0873,'2023-08-22 06:00:13','2023-08-22 06:00:13',60.7681,55.7041,53.1721,50.6401,45.5761),
(2268,'XAG','USD',22.88,22.79,'2023-08-21','2023-08-21 00:00:00',0.09,0.3934,'2023-08-22 06:10:17','2023-08-22 06:10:17',0.7356,0.6743,0.6437,0.613,0.5517),
(2300,'XAU','USD',1901.85,1890.1,'2023-08-22','2023-08-22 00:00:00',11.75,0.6178,'2023-08-23 06:00:09','2023-08-23 06:00:09',61.1459,56.0504,53.5027,50.9549,45.8594),
(2301,'XAG','USD',23.39,22.88,'2023-08-22','2023-08-22 00:00:00',0.51,2.1804,'2023-08-23 06:10:08','2023-08-23 06:10:08',0.752,0.6893,0.658,0.6267,0.564),
(2302,'XAU','USD',1920.7,1904.55,'2023-08-24','2023-08-24 00:00:00',16.15,0.8408,'2023-08-25 06:00:07','2023-08-25 06:00:07',61.7519,56.6059,54.0329,51.4599,46.314),
(2303,'XAG','USD',24.185,23.75,'2023-08-24','2023-08-24 00:00:00',0.435,1.7986,'2023-08-25 06:10:07','2023-08-25 06:10:07',0.7776,0.7128,0.6804,0.648,0.5832),
(2304,'XAU','USD',1917.85,1920.7,'2023-08-25','2023-08-25 00:00:00',-2.85,-0.1486,'2023-08-26 06:00:13','2023-08-26 06:00:13',61.6603,56.522,53.9528,51.3836,46.2452),
(2305,'XAG','USD',24.185,24.185,'2023-08-25','2023-08-25 00:00:00',0,0,'2023-08-26 06:10:11','2023-08-26 06:10:11',0.7776,0.7128,0.6804,0.648,0.5832),
(2306,'XAG','USD',22.765,22.765,'2022-01-03','2022-01-03 00:00:00',0,0,'2023-08-27 06:50:36','2023-08-27 06:50:36',0.7319,0.6709,0.6404,0.6099,0.5489),
(2307,'XAG','USD',22.89,22.765,'2022-01-04','2022-01-04 00:00:00',0.125,0.5461,'2023-08-27 06:50:37','2023-08-27 06:50:37',0.7359,0.6746,0.6439,0.6133,0.5519),
(2308,'XAG','USD',23.055,22.89,'2022-01-05','2022-01-05 00:00:00',0.165,0.7157,'2023-08-27 06:50:38','2023-08-27 06:50:38',0.7412,0.6795,0.6486,0.6177,0.5559),
(2309,'XAG','USD',22.245,23.055,'2022-01-06','2022-01-06 00:00:00',-0.81,-3.6413,'2023-08-27 06:50:39','2023-08-27 06:50:39',0.7152,0.6556,0.6258,0.596,0.5364),
(2310,'XAG','USD',22.24,22.245,'2022-01-07','2022-01-07 00:00:00',-0.005,-0.0225,'2023-08-27 06:50:40','2023-08-27 06:50:40',0.715,0.6554,0.6257,0.5959,0.5363),
(2311,'XAG','USD',22.455,22.24,'2022-01-10','2022-01-10 00:00:00',0.215,0.9575,'2023-08-27 06:50:41','2023-08-27 06:50:41',0.7219,0.6618,0.6317,0.6016,0.5415),
(2312,'XAG','USD',22.59,22.455,'2022-01-11','2022-01-11 00:00:00',0.135,0.5976,'2023-08-27 06:50:41','2023-08-27 06:50:41',0.7263,0.6658,0.6355,0.6052,0.5447),
(2313,'XAG','USD',22.745,22.59,'2022-01-12','2022-01-12 00:00:00',0.155,0.6815,'2023-08-27 06:50:42','2023-08-27 06:50:42',0.7313,0.6703,0.6399,0.6094,0.5485),
(2314,'XAG','USD',23.245,22.745,'2022-01-13','2022-01-13 00:00:00',0.5,2.151,'2023-08-27 06:50:43','2023-08-27 06:50:43',0.7473,0.6851,0.6539,0.6228,0.5605),
(2315,'XAG','USD',23.1,23.245,'2022-01-14','2022-01-14 00:00:00',-0.145,-0.6277,'2023-08-27 06:50:44','2023-08-27 06:50:44',0.7427,0.6808,0.6498,0.6189,0.557),
(2316,'XAG','USD',22.915,23.015,'2022-01-18','2022-01-18 00:00:00',-0.1,-0.4364,'2023-08-27 06:50:45','2023-08-27 06:50:45',0.7367,0.6753,0.6446,0.6139,0.5526),
(2317,'XAG','USD',23.775,22.915,'2022-01-19','2022-01-19 00:00:00',0.86,3.6172,'2023-08-27 06:50:46','2023-08-27 06:50:46',0.7644,0.7007,0.6688,0.637,0.5733),
(2318,'XAG','USD',24.225,23.775,'2022-01-20','2022-01-20 00:00:00',0.45,1.8576,'2023-08-27 06:50:47','2023-08-27 06:50:47',0.7789,0.7139,0.6815,0.649,0.5841),
(2319,'XAG','USD',24.32,24.225,'2022-01-21','2022-01-21 00:00:00',0.095,0.3906,'2023-08-27 06:50:48','2023-08-27 06:50:48',0.7819,0.7167,0.6842,0.6516,0.5864),
(2320,'XAG','USD',24.065,24.32,'2022-01-24','2022-01-24 00:00:00',-0.255,-1.0596,'2023-08-27 06:50:49','2023-08-27 06:50:49',0.7737,0.7092,0.677,0.6448,0.5803),
(2321,'XAG','USD',23.665,24.065,'2022-01-25','2022-01-25 00:00:00',-0.4,-1.6903,'2023-08-27 06:50:50','2023-08-27 06:50:50',0.7608,0.6974,0.6657,0.634,0.5706),
(2322,'XAG','USD',23.86,23.665,'2022-01-26','2022-01-26 00:00:00',0.195,0.8173,'2023-08-27 06:50:50','2023-08-27 06:50:50',0.7671,0.7032,0.6712,0.6393,0.5753),
(2323,'XAG','USD',23.17,23.86,'2022-01-27','2022-01-27 00:00:00',-0.69,-2.978,'2023-08-27 06:50:51','2023-08-27 06:50:51',0.7449,0.6829,0.6518,0.6208,0.5587),
(2324,'XAG','USD',22.5,23.17,'2022-01-28','2022-01-28 00:00:00',-0.67,-2.9778,'2023-08-27 06:50:52','2023-08-27 06:50:52',0.7234,0.6631,0.633,0.6028,0.5425),
(2325,'XAG','USD',22.495,22.5,'2022-01-31','2022-01-31 00:00:00',-0.005,-0.0222,'2023-08-27 06:50:53','2023-08-27 06:50:53',0.7232,0.663,0.6328,0.6027,0.5424),
(2326,'XAG','USD',22.88,22.495,'2022-02-01','2022-02-01 00:00:00',0.385,1.6827,'2023-08-27 06:50:54','2023-08-27 06:50:54',0.7356,0.6743,0.6437,0.613,0.5517),
(2327,'XAG','USD',22.78,22.88,'2022-02-02','2022-02-02 00:00:00',-0.1,-0.439,'2023-08-27 06:50:55','2023-08-27 06:50:55',0.7324,0.6714,0.6408,0.6103,0.5493),
(2328,'XAG','USD',22.36,22.78,'2022-02-03','2022-02-03 00:00:00',-0.42,-1.8784,'2023-08-27 06:50:56','2023-08-27 06:50:56',0.7189,0.659,0.629,0.5991,0.5392),
(2329,'XAG','USD',22.505,22.36,'2022-02-04','2022-02-04 00:00:00',0.145,0.6443,'2023-08-27 06:50:57','2023-08-27 06:50:57',0.7236,0.6633,0.6331,0.603,0.5427),
(2330,'XAG','USD',22.86,22.505,'2022-02-07','2022-02-07 00:00:00',0.355,1.5529,'2023-08-27 06:50:58','2023-08-27 06:50:58',0.735,0.6737,0.6431,0.6125,0.5512),
(2331,'XAG','USD',22.86,22.86,'2022-02-08','2022-02-08 00:00:00',0,0,'2023-08-27 06:50:59','2023-08-27 06:50:59',0.735,0.6737,0.6431,0.6125,0.5512),
(2332,'XAG','USD',23.25,22.86,'2022-02-09','2022-02-09 00:00:00',0.39,1.6774,'2023-08-27 06:51:00','2023-08-27 06:51:00',0.7475,0.6852,0.6541,0.6229,0.5606),
(2333,'XAG','USD',23.355,23.25,'2022-02-10','2022-02-10 00:00:00',0.105,0.4496,'2023-08-27 06:51:01','2023-08-27 06:51:01',0.7509,0.6883,0.657,0.6257,0.5632),
(2334,'XAG','USD',22.895,23.355,'2022-02-11','2022-02-11 00:00:00',-0.46,-2.0092,'2023-08-27 06:51:02','2023-08-27 06:51:02',0.7361,0.6748,0.6441,0.6134,0.5521),
(2335,'XAG','USD',23.69,22.895,'2022-02-14','2022-02-14 00:00:00',0.795,3.3558,'2023-08-27 06:51:03','2023-08-27 06:51:03',0.7617,0.6982,0.6664,0.6347,0.5712),
(2336,'XAG','USD',23.285,23.69,'2022-02-15','2022-02-15 00:00:00',-0.405,-1.7393,'2023-08-27 06:51:04','2023-08-27 06:51:04',0.7486,0.6862,0.6551,0.6239,0.5615),
(2337,'XAG','USD',23.5,23.285,'2022-02-16','2022-02-16 00:00:00',0.215,0.9149,'2023-08-27 06:51:05','2023-08-27 06:51:05',0.7555,0.6926,0.6611,0.6296,0.5667),
(2338,'XAG','USD',23.585,23.5,'2022-02-17','2022-02-17 00:00:00',0.085,0.3604,'2023-08-27 06:51:06','2023-08-27 06:51:06',0.7583,0.6951,0.6635,0.6319,0.5687),
(2339,'XAG','USD',23.77,23.585,'2022-02-18','2022-02-18 00:00:00',0.185,0.7783,'2023-08-27 06:51:07','2023-08-27 06:51:07',0.7642,0.7005,0.6687,0.6369,0.5732),
(2340,'XAG','USD',24.01,23.735,'2022-02-22','2022-02-22 00:00:00',0.275,1.1454,'2023-08-27 06:51:07','2023-08-27 06:51:07',0.7719,0.7076,0.6754,0.6433,0.579),
(2341,'XAG','USD',24.105,24.01,'2022-02-23','2022-02-23 00:00:00',0.095,0.3941,'2023-08-27 06:51:08','2023-08-27 06:51:08',0.775,0.7104,0.6781,0.6458,0.5812),
(2342,'XAG','USD',25.315,24.105,'2022-02-24','2022-02-24 00:00:00',1.21,4.7798,'2023-08-27 06:51:09','2023-08-27 06:51:09',0.8139,0.7461,0.7122,0.6782,0.6104),
(2343,'XAG','USD',24.21,25.315,'2022-02-25','2022-02-25 00:00:00',-1.105,-4.5642,'2023-08-27 06:51:10','2023-08-27 06:51:10',0.7784,0.7135,0.6811,0.6486,0.5838),
(2344,'XAG','USD',24.35,24.21,'2022-02-28','2022-02-28 00:00:00',0.14,0.5749,'2023-08-27 06:51:11','2023-08-27 06:51:11',0.7829,0.7176,0.685,0.6524,0.5872),
(2345,'XAG','USD',17.77,17.945,'2022-09-01','2022-09-01 00:00:00',-0.175,-0.9848,'2023-08-27 06:52:51','2023-08-27 06:52:51',0.5713,0.5237,0.4999,0.4761,0.4285),
(2346,'XAG','USD',17.915,17.77,'2022-09-02','2022-09-02 00:00:00',0.145,0.8094,'2023-08-27 06:52:52','2023-08-27 06:52:52',0.576,0.528,0.504,0.48,0.432),
(2347,'XAG','USD',18.395,18.23,'2022-09-06','2022-09-06 00:00:00',0.165,0.897,'2023-08-27 06:52:53','2023-08-27 06:52:53',0.5914,0.5421,0.5175,0.4928,0.4436),
(2348,'XAG','USD',18.17,18.395,'2022-09-07','2022-09-07 00:00:00',-0.225,-1.2383,'2023-08-27 06:52:54','2023-08-27 06:52:54',0.5842,0.5355,0.5112,0.4868,0.4381),
(2349,'XAG','USD',18.17,18.17,'2022-09-08','2022-09-08 00:00:00',0,0,'2023-08-27 06:52:55','2023-08-27 06:52:55',0.5842,0.5355,0.5112,0.4868,0.4381),
(2350,'XAG','USD',18.765,18.17,'2022-09-09','2022-09-09 00:00:00',0.595,3.1708,'2023-08-27 06:52:56','2023-08-27 06:52:56',0.6033,0.553,0.5279,0.5028,0.4525),
(2351,'XAG','USD',19.215,18.765,'2022-09-12','2022-09-12 00:00:00',0.45,2.3419,'2023-08-27 06:52:57','2023-08-27 06:52:57',0.6178,0.5663,0.5406,0.5148,0.4633),
(2352,'XAG','USD',19.925,19.215,'2022-09-13','2022-09-13 00:00:00',0.71,3.5634,'2023-08-27 06:52:57','2023-08-27 06:52:57',0.6406,0.5872,0.5605,0.5338,0.4805),
(2353,'XAG','USD',19.505,19.925,'2022-09-14','2022-09-14 00:00:00',-0.42,-2.1533,'2023-08-27 06:52:58','2023-08-27 06:52:58',0.6271,0.5748,0.5487,0.5226,0.4703),
(2354,'XAG','USD',19.37,19.505,'2022-09-15','2022-09-15 00:00:00',-0.135,-0.697,'2023-08-27 06:52:59','2023-08-27 06:52:59',0.6228,0.5709,0.5449,0.519,0.4671),
(2355,'XAG','USD',18.995,19.37,'2022-09-16','2022-09-16 00:00:00',-0.375,-1.9742,'2023-08-27 06:53:00','2023-08-27 06:53:00',0.6107,0.5598,0.5344,0.5089,0.458),
(2356,'XAG','USD',18.995,18.995,'2022-09-19','2022-09-19 00:00:00',0,0,'2023-08-27 06:53:01','2023-08-27 06:53:01',0.6107,0.5598,0.5344,0.5089,0.458),
(2357,'XAG','USD',19.315,18.995,'2022-09-20','2022-09-20 00:00:00',0.32,1.6567,'2023-08-27 06:53:02','2023-08-27 06:53:02',0.621,0.5692,0.5434,0.5175,0.4657),
(2358,'XAG','USD',19.51,19.315,'2022-09-21','2022-09-21 00:00:00',0.195,0.9995,'2023-08-27 06:53:03','2023-08-27 06:53:03',0.6273,0.575,0.5489,0.5227,0.4704),
(2359,'XAG','USD',19.585,19.51,'2022-09-22','2022-09-22 00:00:00',0.075,0.3829,'2023-08-27 06:53:04','2023-08-27 06:53:04',0.6297,0.5772,0.551,0.5247,0.4723),
(2360,'XAG','USD',19,19.585,'2022-09-23','2022-09-23 00:00:00',-0.585,-3.0789,'2023-08-27 06:53:05','2023-08-27 06:53:05',0.6109,0.56,0.5345,0.5091,0.4581),
(2361,'XAG','USD',18.635,19,'2022-09-26','2022-09-26 00:00:00',-0.365,-1.9587,'2023-08-27 06:53:06','2023-08-27 06:53:06',0.5991,0.5492,0.5242,0.4993,0.4493),
(2362,'XAG','USD',18.68,18.635,'2022-09-27','2022-09-27 00:00:00',0.045,0.2409,'2023-08-27 06:53:07','2023-08-27 06:53:07',0.6006,0.5505,0.5255,0.5005,0.4504),
(2363,'XAG','USD',18.255,18.68,'2022-09-28','2022-09-28 00:00:00',-0.425,-2.3281,'2023-08-27 06:53:07','2023-08-27 06:53:07',0.5869,0.538,0.5135,0.4891,0.4402),
(2364,'XAG','USD',18.67,18.255,'2022-09-29','2022-09-29 00:00:00',0.415,2.2228,'2023-08-27 06:53:08','2023-08-27 06:53:08',0.6003,0.5502,0.5252,0.5002,0.4502),
(2365,'XAG','USD',19.02,18.67,'2022-09-30','2022-09-30 00:00:00',0.35,1.8402,'2023-08-27 06:53:09','2023-08-27 06:53:09',0.6115,0.5605,0.5351,0.5096,0.4586),
(2366,'XAG','USD',19.415,19.02,'2022-10-03','2022-10-03 00:00:00',0.395,2.0345,'2023-08-27 06:53:10','2023-08-27 06:53:10',0.6242,0.5722,0.5462,0.5202,0.4682),
(2367,'XAG','USD',20.925,19.415,'2022-10-04','2022-10-04 00:00:00',1.51,7.2162,'2023-08-27 06:53:11','2023-08-27 06:53:11',0.6728,0.6167,0.5887,0.5606,0.5046),
(2368,'XAG','USD',20.435,20.925,'2022-10-05','2022-10-05 00:00:00',-0.49,-2.3978,'2023-08-27 06:53:12','2023-08-27 06:53:12',0.657,0.6023,0.5749,0.5475,0.4928),
(2369,'XAG','USD',20.54,20.435,'2022-10-06','2022-10-06 00:00:00',0.105,0.5112,'2023-08-27 06:53:13','2023-08-27 06:53:13',0.6604,0.6053,0.5778,0.5503,0.4953),
(2370,'XAG','USD',20.625,20.54,'2022-10-07','2022-10-07 00:00:00',0.085,0.4121,'2023-08-27 06:53:14','2023-08-27 06:53:14',0.6631,0.6079,0.5802,0.5526,0.4973),
(2371,'XAG','USD',19.395,19.825,'2022-10-11','2022-10-11 00:00:00',-0.43,-2.2171,'2023-08-27 06:53:15','2023-08-27 06:53:15',0.6236,0.5716,0.5456,0.5196,0.4677),
(2372,'XAG','USD',19.185,19.395,'2022-10-12','2022-10-12 00:00:00',-0.21,-1.0946,'2023-08-27 06:53:16','2023-08-27 06:53:16',0.6168,0.5654,0.5397,0.514,0.4626),
(2373,'XAG','USD',19.175,19.185,'2022-10-13','2022-10-13 00:00:00',-0.01,-0.0522,'2023-08-27 06:53:17','2023-08-27 06:53:17',0.6165,0.5651,0.5394,0.5137,0.4624),
(2374,'XAG','USD',18.765,19.175,'2022-10-14','2022-10-14 00:00:00',-0.41,-2.1849,'2023-08-27 06:53:18','2023-08-27 06:53:18',0.6033,0.553,0.5279,0.5028,0.4525),
(2375,'XAG','USD',18.765,18.765,'2022-10-17','2022-10-17 00:00:00',0,0,'2023-08-27 06:53:19','2023-08-27 06:53:19',0.6033,0.553,0.5279,0.5028,0.4525),
(2376,'XAG','USD',18.695,18.765,'2022-10-18','2022-10-18 00:00:00',-0.07,-0.3744,'2023-08-27 06:53:19','2023-08-27 06:53:19',0.6011,0.551,0.5259,0.5009,0.4508),
(2377,'XAG','USD',18.435,18.695,'2022-10-19','2022-10-19 00:00:00',-0.26,-1.4104,'2023-08-27 06:53:20','2023-08-27 06:53:20',0.5927,0.5433,0.5186,0.4939,0.4445),
(2378,'XAG','USD',18.785,18.435,'2022-10-20','2022-10-20 00:00:00',0.35,1.8632,'2023-08-27 06:53:21','2023-08-27 06:53:21',0.604,0.5536,0.5285,0.5033,0.453),
(2379,'XAG','USD',18.385,18.785,'2022-10-21','2022-10-21 00:00:00',-0.4,-2.1757,'2023-08-27 06:53:22','2023-08-27 06:53:22',0.5911,0.5418,0.5172,0.4926,0.4433),
(2380,'XAG','USD',19.215,18.385,'2022-10-24','2022-10-24 00:00:00',0.83,4.3195,'2023-08-27 06:53:23','2023-08-27 06:53:23',0.6178,0.5663,0.5406,0.5148,0.4633),
(2381,'XAG','USD',18.88,19.215,'2022-10-25','2022-10-25 00:00:00',-0.335,-1.7744,'2023-08-27 06:53:24','2023-08-27 06:53:24',0.607,0.5564,0.5311,0.5058,0.4553),
(2382,'XAG','USD',19.59,18.88,'2022-10-26','2022-10-26 00:00:00',0.71,3.6243,'2023-08-27 06:53:25','2023-08-27 06:53:25',0.6298,0.5773,0.5511,0.5249,0.4724),
(2383,'XAG','USD',19.37,19.59,'2022-10-27','2022-10-27 00:00:00',-0.22,-1.1358,'2023-08-27 06:53:26','2023-08-27 06:53:26',0.6228,0.5709,0.5449,0.519,0.4671),
(2384,'XAG','USD',19.225,19.37,'2022-10-28','2022-10-28 00:00:00',-0.145,-0.7542,'2023-08-27 06:53:27','2023-08-27 06:53:27',0.6181,0.5666,0.5408,0.5151,0.4636),
(2385,'XAG','USD',19.165,19.225,'2022-10-31','2022-10-31 00:00:00',-0.06,-0.3131,'2023-08-27 06:53:28','2023-08-27 06:53:28',0.6162,0.5648,0.5391,0.5135,0.4621),
(2386,'XAG','USD',20,19.165,'2022-11-01','2022-11-01 00:00:00',0.835,4.175,'2023-08-27 06:56:15','2023-08-27 06:56:15',0.643,0.5894,0.5626,0.5358,0.4823),
(2387,'XAG','USD',19.78,20,'2022-11-02','2022-11-02 00:00:00',-0.22,-1.1122,'2023-08-27 06:56:16','2023-08-27 06:56:16',0.6359,0.5829,0.5564,0.53,0.477),
(2388,'XAG','USD',18.92,19.78,'2022-11-03','2022-11-03 00:00:00',-0.86,-4.5455,'2023-08-27 06:56:17','2023-08-27 06:56:17',0.6083,0.5576,0.5323,0.5069,0.4562),
(2389,'XAG','USD',19.965,18.92,'2022-11-04','2022-11-04 00:00:00',1.045,5.2342,'2023-08-27 06:56:18','2023-08-27 06:56:18',0.6419,0.5884,0.5617,0.5349,0.4814),
(2390,'XAG','USD',20.67,19.965,'2022-11-07','2022-11-07 00:00:00',0.705,3.4107,'2023-08-27 06:56:19','2023-08-27 06:56:19',0.6646,0.6092,0.5815,0.5538,0.4984),
(2391,'XAG','USD',20.75,20.67,'2022-11-08','2022-11-08 00:00:00',0.08,0.3855,'2023-08-27 06:56:20','2023-08-27 06:56:20',0.6671,0.6115,0.5837,0.5559,0.5003),
(2392,'XAG','USD',21.32,20.75,'2022-11-09','2022-11-09 00:00:00',0.57,2.6735,'2023-08-27 06:56:21','2023-08-27 06:56:21',0.6855,0.6283,0.5998,0.5712,0.5141),
(2393,'XAG','USD',21.09,21.32,'2022-11-10','2022-11-10 00:00:00',-0.23,-1.0906,'2023-08-27 06:56:21','2023-08-27 06:56:21',0.6781,0.6216,0.5933,0.565,0.5085),
(2394,'XAG','USD',21.47,21.48,'2022-11-14','2022-11-14 00:00:00',-0.01,-0.0466,'2023-08-27 06:56:22','2023-08-27 06:56:22',0.6903,0.6328,0.604,0.5752,0.5177),
(2395,'XAG','USD',21.94,21.47,'2022-11-15','2022-11-15 00:00:00',0.47,2.1422,'2023-08-27 06:56:23','2023-08-27 06:56:23',0.7054,0.6466,0.6172,0.5878,0.529),
(2396,'XAG','USD',21.95,21.94,'2022-11-16','2022-11-16 00:00:00',0.01,0.0456,'2023-08-27 06:56:24','2023-08-27 06:56:24',0.7057,0.6469,0.6175,0.5881,0.5293),
(2397,'XAG','USD',21.075,21.95,'2022-11-17','2022-11-17 00:00:00',-0.875,-4.1518,'2023-08-27 06:56:25','2023-08-27 06:56:25',0.6776,0.6211,0.5929,0.5646,0.5082),
(2398,'XAG','USD',21.095,21.075,'2022-11-18','2022-11-18 00:00:00',0.02,0.0948,'2023-08-27 06:56:26','2023-08-27 06:56:26',0.6782,0.6217,0.5934,0.5652,0.5087),
(2399,'XAG','USD',20.64,21.095,'2022-11-21','2022-11-21 00:00:00',-0.455,-2.2045,'2023-08-27 06:56:27','2023-08-27 06:56:27',0.6636,0.6083,0.5806,0.553,0.4977),
(2400,'XAG','USD',21.27,20.64,'2022-11-22','2022-11-22 00:00:00',0.63,2.9619,'2023-08-27 06:56:28','2023-08-27 06:56:28',0.6838,0.6269,0.5984,0.5699,0.5129),
(2401,'XAG','USD',21.265,21.27,'2022-11-23','2022-11-23 00:00:00',-0.005,-0.0235,'2023-08-27 06:56:29','2023-08-27 06:56:29',0.6837,0.6267,0.5982,0.5697,0.5128),
(2402,'XAG','USD',21.335,21.56,'2022-11-25','2022-11-25 00:00:00',-0.225,-1.0546,'2023-08-27 06:56:30','2023-08-27 06:56:30',0.6859,0.6288,0.6002,0.5716,0.5145),
(2403,'XAG','USD',21.475,21.335,'2022-11-28','2022-11-28 00:00:00',0.14,0.6519,'2023-08-27 06:56:30','2023-08-27 06:56:30',0.6904,0.6329,0.6041,0.5754,0.5178),
(2404,'XAG','USD',21.365,21.475,'2022-11-29','2022-11-29 00:00:00',-0.11,-0.5149,'2023-08-27 06:56:31','2023-08-27 06:56:31',0.6869,0.6297,0.601,0.5724,0.5152),
(2405,'XAG','USD',21.56,21.365,'2022-11-30','2022-11-30 00:00:00',0.195,0.9045,'2023-08-27 06:56:32','2023-08-27 06:56:32',0.6932,0.6354,0.6065,0.5776,0.5199),
(2406,'XAG','USD',22.135,21.56,'2022-12-01','2022-12-01 00:00:00',0.575,2.5977,'2023-08-27 06:56:33','2023-08-27 06:56:33',0.7117,0.6524,0.6227,0.593,0.5337),
(2407,'XAG','USD',22.605,22.135,'2022-12-02','2022-12-02 00:00:00',0.47,2.0792,'2023-08-27 06:56:34','2023-08-27 06:56:34',0.7268,0.6662,0.6359,0.6056,0.5451),
(2408,'XAG','USD',22.985,22.605,'2022-12-05','2022-12-05 00:00:00',0.38,1.6533,'2023-08-27 06:56:35','2023-08-27 06:56:35',0.739,0.6774,0.6466,0.6158,0.5542),
(2409,'XAG','USD',22.54,22.985,'2022-12-06','2022-12-06 00:00:00',-0.445,-1.9743,'2023-08-27 06:56:36','2023-08-27 06:56:36',0.7247,0.6643,0.6341,0.6039,0.5435),
(2410,'XAG','USD',22.385,22.54,'2022-12-07','2022-12-07 00:00:00',-0.155,-0.6924,'2023-08-27 06:56:37','2023-08-27 06:56:37',0.7197,0.6597,0.6297,0.5997,0.5398),
(2411,'XAG','USD',22.695,22.385,'2022-12-08','2022-12-08 00:00:00',0.31,1.3659,'2023-08-27 06:56:38','2023-08-27 06:56:38',0.7297,0.6689,0.6385,0.6081,0.5472),
(2412,'XAG','USD',23.11,22.695,'2022-12-09','2022-12-09 00:00:00',0.415,1.7958,'2023-08-27 06:56:39','2023-08-27 06:56:39',0.743,0.6811,0.6501,0.6192,0.5573),
(2413,'XAG','USD',23.39,23.11,'2022-12-12','2022-12-12 00:00:00',0.28,1.1971,'2023-08-27 06:56:40','2023-08-27 06:56:40',0.752,0.6893,0.658,0.6267,0.564),
(2414,'XAG','USD',23.395,23.39,'2022-12-13','2022-12-13 00:00:00',0.005,0.0214,'2023-08-27 06:56:41','2023-08-27 06:56:41',0.7522,0.6895,0.6581,0.6268,0.5641),
(2415,'XAG','USD',23.395,23.395,'2022-12-14','2022-12-14 00:00:00',0,0,'2023-08-27 06:56:42','2023-08-27 06:56:42',0.7522,0.6895,0.6581,0.6268,0.5641),
(2416,'XAG','USD',23.165,23.395,'2022-12-15','2022-12-15 00:00:00',-0.23,-0.9929,'2023-08-27 06:56:42','2023-08-27 06:56:42',0.7448,0.6827,0.6517,0.6206,0.5586),
(2417,'XAG','USD',22.83,23.165,'2022-12-16','2022-12-16 00:00:00',-0.335,-1.4674,'2023-08-27 06:56:43','2023-08-27 06:56:43',0.734,0.6728,0.6423,0.6117,0.5505),
(2418,'XAG','USD',23.24,22.83,'2022-12-19','2022-12-19 00:00:00',0.41,1.7642,'2023-08-27 06:56:44','2023-08-27 06:56:44',0.7472,0.6849,0.6538,0.6227,0.5604),
(2419,'XAG','USD',23.74,23.24,'2022-12-20','2022-12-20 00:00:00',0.5,2.1061,'2023-08-27 06:56:45','2023-08-27 06:56:45',0.7633,0.6997,0.6679,0.636,0.5724),
(2420,'XAG','USD',23.89,23.74,'2022-12-21','2022-12-21 00:00:00',0.15,0.6279,'2023-08-27 06:56:46','2023-08-27 06:56:46',0.7681,0.7041,0.6721,0.6401,0.5761),
(2421,'XAG','USD',23.735,23.89,'2022-12-22','2022-12-22 00:00:00',-0.155,-0.653,'2023-08-27 06:56:47','2023-08-27 06:56:47',0.7631,0.6995,0.6677,0.6359,0.5723),
(2422,'XAG','USD',23.735,23.735,'2022-12-23','2022-12-23 00:00:00',0,0,'2023-08-27 06:56:48','2023-08-27 06:56:48',0.7631,0.6995,0.6677,0.6359,0.5723),
(2423,'XAG','USD',23.735,23.735,'2022-12-27','2022-12-27 00:00:00',0,0,'2023-08-27 06:56:49','2023-08-27 06:56:49',0.7631,0.6995,0.6677,0.6359,0.5723),
(2424,'XAG','USD',23.855,23.735,'2022-12-28','2022-12-28 00:00:00',0.12,0.503,'2023-08-27 06:56:50','2023-08-27 06:56:50',0.767,0.703,0.6711,0.6391,0.5752),
(2425,'XAG','USD',23.855,23.855,'2022-12-29','2022-12-29 00:00:00',0,0,'2023-08-27 06:56:51','2023-08-27 06:56:51',0.767,0.703,0.6711,0.6391,0.5752),
(2426,'XAG','USD',23.855,23.855,'2022-12-30','2022-12-30 00:00:00',0,0,'2023-08-27 06:56:52','2023-08-27 06:56:52',0.767,0.703,0.6711,0.6391,0.5752),
(2427,'XAG','USD',27.27,26.485,'2021-01-04','2021-01-04 00:00:00',0.785,2.8786,'2023-08-27 06:59:30','2023-08-27 06:59:30',0.8768,0.8037,0.7672,0.7306,0.6576),
(2428,'XAG','USD',27.51,27.27,'2021-01-05','2021-01-05 00:00:00',0.24,0.8724,'2023-08-27 06:59:31','2023-08-27 06:59:31',0.8845,0.8108,0.7739,0.7371,0.6634),
(2429,'XAG','USD',27.525,27.51,'2021-01-06','2021-01-06 00:00:00',0.015,0.0545,'2023-08-27 06:59:32','2023-08-27 06:59:32',0.8849,0.8112,0.7743,0.7375,0.6637),
(2430,'XAG','USD',27.13,27.525,'2021-01-07','2021-01-07 00:00:00',-0.395,-1.456,'2023-08-27 06:59:33','2023-08-27 06:59:33',0.8722,0.7996,0.7632,0.7269,0.6542),
(2431,'XAG','USD',26.645,27.13,'2021-01-08','2021-01-08 00:00:00',-0.485,-1.8202,'2023-08-27 06:59:34','2023-08-27 06:59:34',0.8567,0.7853,0.7496,0.7139,0.6425),
(2432,'XAG','USD',25.02,26.645,'2021-01-11','2021-01-11 00:00:00',-1.625,-6.4948,'2023-08-27 06:59:35','2023-08-27 06:59:35',0.8044,0.7374,0.7039,0.6703,0.6033),
(2433,'XAG','USD',25.525,25.02,'2021-01-12','2021-01-12 00:00:00',0.505,1.9785,'2023-08-27 06:59:35','2023-08-27 06:59:35',0.8206,0.7523,0.7181,0.6839,0.6155),
(2434,'XAG','USD',25.335,25.525,'2021-01-13','2021-01-13 00:00:00',-0.19,-0.75,'2023-08-27 06:59:36','2023-08-27 06:59:36',0.8145,0.7467,0.7127,0.6788,0.6109),
(2435,'XAG','USD',25.25,25.335,'2021-01-14','2021-01-14 00:00:00',-0.085,-0.3366,'2023-08-27 06:59:37','2023-08-27 06:59:37',0.8118,0.7442,0.7103,0.6765,0.6089),
(2436,'XAG','USD',25.245,25.25,'2021-01-15','2021-01-15 00:00:00',-0.005,-0.0198,'2023-08-27 06:59:38','2023-08-27 06:59:38',0.8116,0.744,0.7102,0.6764,0.6087),
(2437,'XAG','USD',25.295,24.865,'2021-01-19','2021-01-19 00:00:00',0.43,1.6999,'2023-08-27 06:59:39','2023-08-27 06:59:39',0.8133,0.7455,0.7116,0.6777,0.6099),
(2438,'XAG','USD',25.295,25.295,'2021-01-20','2021-01-20 00:00:00',0,0,'2023-08-27 06:59:40','2023-08-27 06:59:40',0.8133,0.7455,0.7116,0.6777,0.6099),
(2439,'XAG','USD',25.865,25.295,'2021-01-21','2021-01-21 00:00:00',0.57,2.2038,'2023-08-27 06:59:41','2023-08-27 06:59:41',0.8316,0.7623,0.7276,0.693,0.6237),
(2440,'XAG','USD',25.32,25.865,'2021-01-22','2021-01-22 00:00:00',-0.545,-2.1524,'2023-08-27 06:59:42','2023-08-27 06:59:42',0.8141,0.7462,0.7123,0.6784,0.6105),
(2441,'XAG','USD',25.635,25.32,'2021-01-25','2021-01-25 00:00:00',0.315,1.2288,'2023-08-27 06:59:43','2023-08-27 06:59:43',0.8242,0.7555,0.7212,0.6868,0.6181),
(2442,'XAG','USD',25.4,25.635,'2021-01-26','2021-01-26 00:00:00',-0.235,-0.9252,'2023-08-27 06:59:44','2023-08-27 06:59:44',0.8166,0.7486,0.7146,0.6805,0.6125),
(2443,'XAG','USD',25.185,25.4,'2021-01-27','2021-01-27 00:00:00',-0.215,-0.8537,'2023-08-27 06:59:44','2023-08-27 06:59:44',0.8097,0.7422,0.7085,0.6748,0.6073),
(2444,'XAG','USD',25.205,25.185,'2021-01-28','2021-01-28 00:00:00',0.02,0.0793,'2023-08-27 06:59:45','2023-08-27 06:59:45',0.8104,0.7428,0.7091,0.6753,0.6078),
(2445,'XAG','USD',27.415,25.205,'2021-01-29','2021-01-29 00:00:00',2.21,8.0613,'2023-08-27 06:59:46','2023-08-27 06:59:46',0.8814,0.808,0.7712,0.7345,0.6611),
(2446,'XAG','USD',29.585,27.415,'2021-02-01','2021-02-01 00:00:00',2.17,7.3348,'2023-08-27 06:59:47','2023-08-27 06:59:47',0.9512,0.8719,0.8323,0.7926,0.7134),
(2447,'XAG','USD',27.325,29.585,'2021-02-02','2021-02-02 00:00:00',-2.26,-8.2708,'2023-08-27 06:59:48','2023-08-27 06:59:48',0.8785,0.8053,0.7687,0.7321,0.6589),
(2448,'XAG','USD',26.8,27.325,'2021-02-03','2021-02-03 00:00:00',-0.525,-1.959,'2023-08-27 06:59:49','2023-08-27 06:59:49',0.8616,0.7898,0.7539,0.718,0.6462),
(2449,'XAG','USD',26.4,26.8,'2021-02-04','2021-02-04 00:00:00',-0.4,-1.5152,'2023-08-27 06:59:50','2023-08-27 06:59:50',0.8488,0.778,0.7427,0.7073,0.6366),
(2450,'XAG','USD',26.53,26.4,'2021-02-05','2021-02-05 00:00:00',0.13,0.49,'2023-08-27 06:59:51','2023-08-27 06:59:51',0.853,0.7819,0.7463,0.7108,0.6397),
(2451,'XAG','USD',27.18,26.53,'2021-02-08','2021-02-08 00:00:00',0.65,2.3915,'2023-08-27 06:59:52','2023-08-27 06:59:52',0.8739,0.801,0.7646,0.7282,0.6554),
(2452,'XAG','USD',27.635,27.18,'2021-02-09','2021-02-09 00:00:00',0.455,1.6465,'2023-08-27 06:59:53','2023-08-27 06:59:53',0.8885,0.8144,0.7774,0.7404,0.6664),
(2453,'XAG','USD',27.23,27.635,'2021-02-10','2021-02-10 00:00:00',-0.405,-1.4873,'2023-08-27 06:59:54','2023-08-27 06:59:54',0.8755,0.8025,0.766,0.7296,0.6566),
(2454,'XAG','USD',27.125,27.23,'2021-02-11','2021-02-11 00:00:00',-0.105,-0.3871,'2023-08-27 06:59:55','2023-08-27 06:59:55',0.8721,0.7994,0.7631,0.7267,0.6541),
(2455,'XAG','USD',27.07,27.125,'2021-02-12','2021-02-12 00:00:00',-0.055,-0.2032,'2023-08-27 06:59:56','2023-08-27 06:59:56',0.8703,0.7978,0.7615,0.7253,0.6527),
(2456,'XAG','USD',27.575,27.57,'2021-02-16','2021-02-16 00:00:00',0.005,0.0181,'2023-08-27 06:59:56','2023-08-27 06:59:56',0.8866,0.8127,0.7757,0.7388,0.6649),
(2457,'XAG','USD',27.115,27.575,'2021-02-17','2021-02-17 00:00:00',-0.46,-1.6965,'2023-08-27 06:59:57','2023-08-27 06:59:57',0.8718,0.7991,0.7628,0.7265,0.6538),
(2458,'XAG','USD',27.165,27.115,'2021-02-18','2021-02-18 00:00:00',0.05,0.1841,'2023-08-27 06:59:58','2023-08-27 06:59:58',0.8734,0.8006,0.7642,0.7278,0.655),
(2459,'XAG','USD',26.95,27.165,'2021-02-19','2021-02-19 00:00:00',-0.215,-0.7978,'2023-08-27 06:59:59','2023-08-27 06:59:59',0.8665,0.7943,0.7582,0.7221,0.6498),
(2460,'XAG','USD',27.445,26.95,'2021-02-22','2021-02-22 00:00:00',0.495,1.8036,'2023-08-27 07:00:00','2023-08-27 07:00:00',0.8824,0.8088,0.7721,0.7353,0.6618),
(2461,'XAG','USD',27.965,27.445,'2021-02-23','2021-02-23 00:00:00',0.52,1.8595,'2023-08-27 07:00:01','2023-08-27 07:00:01',0.8991,0.8242,0.7867,0.7492,0.6743),
(2462,'XAG','USD',27.745,27.965,'2021-02-24','2021-02-24 00:00:00',-0.22,-0.7929,'2023-08-27 07:00:02','2023-08-27 07:00:02',0.892,0.8177,0.7805,0.7434,0.669),
(2463,'XAG','USD',27.925,27.745,'2021-02-25','2021-02-25 00:00:00',0.18,0.6446,'2023-08-27 07:00:03','2023-08-27 07:00:03',0.8978,0.823,0.7856,0.7482,0.6734),
(2464,'XAG','USD',26.685,27.925,'2021-02-26','2021-02-26 00:00:00',-1.24,-4.6468,'2023-08-27 07:00:04','2023-08-27 07:00:04',0.8579,0.7864,0.7507,0.715,0.6435),
(2465,'XAU','USD',1923.5,1917.85,'2023-08-29','2023-08-29 00:00:00',5.65,0.2937,'2023-08-30 06:00:15','2023-08-30 06:00:15',61.842,56.6885,54.1117,51.535,46.3815),
(2466,'XAG','USD',24.22,24.185,'2023-08-29','2023-08-29 00:00:00',0.035,0.1445,'2023-08-30 06:10:12','2023-08-30 06:10:12',0.7787,0.7138,0.6814,0.6489,0.584),
(2467,'XAU','USD',1917.85,1917.85,'2023-08-28','2023-08-28 00:00:00',0,0,'2023-08-30 17:19:20','2023-08-30 17:19:20',61.6603,56.522,53.9528,51.3836,46.2452),
(2468,'XAG','USD',24.185,24.185,'2023-08-28','2023-08-28 00:00:00',0,0,'2023-08-30 17:19:44','2023-08-30 17:19:44',0.7776,0.7128,0.6804,0.648,0.5832),
(2469,'XAU','USD',1938.35,1923.5,'2023-08-30','2023-08-30 00:00:00',14.85,0.7661,'2023-08-31 06:00:10','2023-08-31 06:00:10',62.3194,57.1261,54.5295,51.9328,46.7395),
(2470,'XAG','USD',24.62,24.22,'2023-08-30','2023-08-30 00:00:00',0.4,1.6247,'2023-08-31 06:10:10','2023-08-31 06:10:10',0.7916,0.7256,0.6926,0.6596,0.5937),
(2471,'XAU','USD',1944.2,1938.35,'2023-08-31','2023-08-31 00:00:00',5.85,0.3009,'2023-09-01 06:00:14','2023-09-01 06:00:14',62.5075,57.2985,54.694,52.0896,46.8806),
(2472,'XAG','USD',24.535,24.62,'2023-08-31','2023-08-31 00:00:00',-0.085,-0.3464,'2023-09-01 06:10:13','2023-09-01 06:10:13',0.7888,0.7231,0.6902,0.6573,0.5916),
(2473,'XAU','USD',1944.3,1944.2,'2023-09-01','2023-09-01 00:00:00',0.1,0.0051,'2023-09-02 06:00:16','2023-09-02 06:00:16',62.5107,57.3015,54.6969,52.0922,46.883),
(2474,'XAG','USD',24.645,24.535,'2023-09-01','2023-09-01 00:00:00',0.11,0.4463,'2023-09-02 06:10:12','2023-09-02 06:10:12',0.7924,0.7263,0.6933,0.6603,0.5943),
(2475,'XAU','USD',1931.8,1942.05,'2023-09-05','2023-09-05 00:00:00',-10.25,-0.5306,'2023-09-06 06:00:09','2023-09-06 06:00:09',62.1088,56.9331,54.3452,51.7573,46.5816),
(2476,'XAG','USD',23.545,24.035,'2023-09-05','2023-09-05 00:00:00',-0.49,-2.0811,'2023-09-06 06:10:10','2023-09-06 06:10:10',0.757,0.6939,0.6624,0.6308,0.5677),
(2477,'XAU','USD',1923.45,1931.8,'2023-09-06','2023-09-06 00:00:00',-8.35,-0.4341,'2023-09-07 06:00:09','2023-09-07 06:00:09',61.8404,56.687,54.1103,51.5336,46.3803),
(2478,'XAG','USD',23.475,23.545,'2023-09-06','2023-09-06 00:00:00',-0.07,-0.2982,'2023-09-07 06:10:13','2023-09-07 06:10:13',0.7547,0.6918,0.6604,0.6289,0.5661),
(2479,'XAU','USD',1919.85,1923.45,'2023-09-07','2023-09-07 00:00:00',-3.6,-0.1875,'2023-09-08 06:00:10','2023-09-08 06:00:10',61.7246,56.5809,54.009,51.4372,46.2935),
(2480,'XAG','USD',23.01,23.475,'2023-09-07','2023-09-07 00:00:00',-0.465,-2.0209,'2023-09-08 06:10:09','2023-09-08 06:10:09',0.7398,0.6781,0.6473,0.6165,0.5548),
(2481,'XAU','USD',1925.55,1919.85,'2023-09-08','2023-09-08 00:00:00',5.7,0.296,'2023-09-09 06:00:08','2023-09-09 06:00:08',61.9079,56.7489,54.1694,51.5899,46.4309),
(2482,'XAG','USD',23.01,23.01,'2023-09-08','2023-09-08 00:00:00',0,0,'2023-09-09 06:10:12','2023-09-09 06:10:12',0.7398,0.6781,0.6473,0.6165,0.5548),
(2483,'XAU','USD',1926.6,1925.55,'2023-09-11','2023-09-11 00:00:00',1.05,0.0545,'2023-09-12 06:00:12','2023-09-12 06:00:12',61.9416,56.7798,54.1989,51.618,46.4562),
(2484,'XAG','USD',23.105,23.01,'2023-09-11','2023-09-11 00:00:00',0.095,0.4112,'2023-09-12 06:10:10','2023-09-12 06:10:10',0.7428,0.6809,0.65,0.619,0.5571),
(2485,'XAU','USD',1918.9,1926.6,'2023-09-12','2023-09-12 00:00:00',-7.7,-0.4013,'2023-09-13 06:00:12','2023-09-13 06:00:12',61.6941,56.5529,53.9823,51.4117,46.2706),
(2486,'XAG','USD',22.9,23.105,'2023-09-12','2023-09-12 00:00:00',-0.205,-0.8952,'2023-09-13 06:10:09','2023-09-13 06:10:09',0.7363,0.6749,0.6442,0.6135,0.5522),
(2487,'XAU','USD',1912.15,1918.9,'2023-09-13','2023-09-13 00:00:00',-6.75,-0.353,'2023-09-14 06:00:07','2023-09-14 06:00:07',61.4771,56.354,53.7924,51.2309,46.1078),
(2488,'XAG','USD',22.905,22.9,'2023-09-13','2023-09-13 00:00:00',0.005,0.0218,'2023-09-14 06:10:08','2023-09-14 06:10:08',0.7364,0.675,0.6444,0.6137,0.5523),
(2489,'XAU','USD',1906.45,1912.15,'2023-09-14','2023-09-14 00:00:00',-5.7,-0.299,'2023-09-15 06:00:09','2023-09-15 06:00:09',61.2938,56.186,53.6321,51.0782,45.9703),
(2490,'XAG','USD',22.64,22.905,'2023-09-14','2023-09-14 00:00:00',-0.265,-1.1705,'2023-09-15 06:10:10','2023-09-15 06:10:10',0.7279,0.6672,0.6369,0.6066,0.5459),
(2491,'XAU','USD',1918.7,1906.45,'2023-09-15','2023-09-15 00:00:00',12.25,0.6385,'2023-09-16 06:00:10','2023-09-16 06:00:10',61.6876,56.547,53.9767,51.4064,46.2657),
(2492,'XAG','USD',23.06,22.64,'2023-09-15','2023-09-15 00:00:00',0.42,1.8213,'2023-09-16 06:10:09','2023-09-16 06:10:09',0.7414,0.6796,0.6487,0.6178,0.556),
(2493,'XAU','USD',1904.55,1901.85,'2023-08-23','2023-08-23 00:00:00',2.7,0.1418,'2023-09-18 06:08:44','2023-09-18 06:08:44',61.2327,56.13,53.5786,51.0273,45.9245),
(2494,'XAG','USD',23.75,23.39,'2023-08-23','2023-08-23 00:00:00',0.36,1.5158,'2023-09-18 06:08:44','2023-09-18 06:08:44',0.7636,0.6999,0.6681,0.6363,0.5727),
(2497,'XAU','USD',1926.4,1918.7,'2023-09-18','2023-09-18 00:00:00',7.7,0.3997,'2023-09-19 06:00:10','2023-09-19 06:00:10',61.9352,56.7739,54.1933,51.6127,46.4514),
(2498,'XAG','USD',23.195,23.06,'2023-09-18','2023-09-18 00:00:00',0.135,0.582,'2023-09-19 06:10:08','2023-09-19 06:10:08',0.7457,0.6836,0.6525,0.6214,0.5593),
(2499,'XAU','USD',1935,1926.4,'2023-09-19','2023-09-19 00:00:00',8.6,0.4444,'2023-09-20 06:00:10','2023-09-20 06:00:10',62.2117,57.0274,54.4352,51.8431,46.6588),
(2500,'XAG','USD',23.33,23.195,'2023-09-19','2023-09-19 00:00:00',0.135,0.5787,'2023-09-20 06:10:10','2023-09-20 06:10:10',0.7501,0.6876,0.6563,0.6251,0.5626),
(2501,'XAU','USD',1930.15,1935,'2023-09-20','2023-09-20 00:00:00',-4.85,-0.2513,'2023-09-21 06:00:11','2023-09-21 06:00:11',62.0558,56.8844,54.2988,51.7131,46.5418),
(2502,'XAG','USD',23.275,23.33,'2023-09-20','2023-09-20 00:00:00',-0.055,-0.2363,'2023-09-21 06:10:07','2023-09-21 06:10:07',0.7483,0.6859,0.6548,0.6236,0.5612),
(2510,'XAU','USD',1923.4,1930.15,'2023-09-21','2023-09-21 00:00:00',-6.75,-0.3509,'2023-09-22 06:00:14','2023-09-22 06:00:14',61.8387,56.6855,54.1089,51.5323,46.3791),
(2511,'XAG','USD',23.24,23.275,'2023-09-21','2023-09-21 00:00:00',-0.035,-0.1506,'2023-09-22 06:10:12','2023-09-22 06:10:12',0.7472,0.6849,0.6538,0.6227,0.5604),
(2512,'XAU','USD',1926.2,1923.4,'2023-09-22','2023-09-22 00:00:00',2.8,0.1454,'2023-09-23 06:00:09','2023-09-23 06:00:09',61.9288,56.768,54.1877,51.6073,46.4466),
(2513,'XAG','USD',23.65,23.24,'2023-09-22','2023-09-22 00:00:00',0.41,1.7336,'2023-09-23 06:10:09','2023-09-23 06:10:09',0.7604,0.697,0.6653,0.6336,0.5703),
(2514,'XAU','USD',1828.3,1831.85,'2023-10-03','2023-10-03 00:00:00',-3.55,-0.1942,'2023-10-04 06:00:10','2023-10-04 06:00:10',58.7812,53.8828,51.4336,48.9843,44.0859),
(2515,'XAG','USD',21.055,21.62,'2023-10-03','2023-10-03 00:00:00',-0.565,-2.6834,'2023-10-04 06:10:10','2023-10-04 06:10:10',0.6769,0.6205,0.5923,0.5641,0.5077),
(2516,'XAU','USD',1823.25,1828.3,'2023-10-04','2023-10-04 00:00:00',-5.05,-0.277,'2023-10-05 06:00:11','2023-10-05 06:00:11',58.6188,53.7339,51.2915,48.849,43.9641),
(2517,'XAG','USD',21.105,21.055,'2023-10-04','2023-10-04 00:00:00',0.05,0.2369,'2023-10-05 06:10:13','2023-10-05 06:10:13',0.6785,0.622,0.5937,0.5655,0.5089),
(2518,'XAU','USD',1822.75,1823.25,'2023-10-05','2023-10-05 00:00:00',-0.5,-0.0274,'2023-10-06 06:00:14','2023-10-06 06:00:14',58.6028,53.7192,51.2774,48.8356,43.9521),
(2519,'XAG','USD',21.13,21.105,'2023-10-05','2023-10-05 00:00:00',0.025,0.1183,'2023-10-06 06:10:11','2023-10-06 06:10:11',0.6793,0.6227,0.5944,0.5661,0.5095),
(2520,'XAU','USD',1821.9,1822.75,'2023-10-06','2023-10-06 00:00:00',-0.85,-0.0467,'2023-10-07 12:07:26','2023-10-07 12:07:26',58.5754,53.6942,51.2535,48.8129,43.9316),
(2521,'XAG','USD',21.115,21.13,'2023-10-06','2023-10-06 00:00:00',-0.015,-0.071,'2023-10-07 12:07:44','2023-10-07 12:07:44',0.6789,0.6223,0.594,0.5657,0.5091),
(2522,'XAG','USD',21.62,23.075,'2023-10-02','2023-10-02 00:00:00',-1.455,-6.7299,'2023-10-07 12:08:12','2023-10-07 12:08:12',0.6951,0.6372,0.6082,0.5792,0.5213),
(2523,'XAU','USD',1831.85,1871.6,'2023-10-02','2023-10-02 00:00:00',-39.75,-2.1699,'2023-10-07 12:08:28','2023-10-07 12:08:28',58.8953,53.9874,51.5334,49.0795,44.1715),
(2524,'XAU','USD',1859.7,1852.3,'2023-10-10','2023-10-10 00:00:00',7.4,0.3979,'2023-10-11 06:00:11','2023-10-11 06:00:11',59.7907,54.8082,52.3169,49.8256,44.8431),
(2525,'XAG','USD',21.715,21.65,'2023-10-10','2023-10-10 00:00:00',0.065,0.2993,'2023-10-11 06:10:10','2023-10-11 06:10:10',0.6982,0.64,0.6109,0.5818,0.5236),
(2526,'XAU','USD',1923.45,1914.65,'2023-10-17','2023-10-17 00:00:00',8.8,0.4575,'2023-10-18 06:00:15','2023-10-18 06:00:15',61.8404,56.687,54.1103,51.5336,46.3803),
(2527,'XAG','USD',22.68,22.595,'2023-10-17','2023-10-17 00:00:00',0.085,0.3748,'2023-10-18 06:10:16','2023-10-18 06:10:16',0.7292,0.6684,0.638,0.6076,0.5469),
(2528,'XAU','USD',1943.85,1923.45,'2023-10-18','2023-10-18 00:00:00',20.4,1.0495,'2023-10-19 06:00:12','2023-10-19 06:00:12',62.4962,57.2882,54.6842,52.0802,46.8722),
(2529,'XAG','USD',23.21,22.68,'2023-10-18','2023-10-18 00:00:00',0.53,2.2835,'2023-10-19 06:10:08','2023-10-19 06:10:08',0.7462,0.684,0.6529,0.6218,0.5597),
(2530,'XAU','USD',1948.65,1943.85,'2023-10-19','2023-10-19 00:00:00',4.8,0.2463,'2023-10-20 06:00:12','2023-10-20 06:00:12',62.6506,57.4297,54.8192,52.2088,46.9879),
(2531,'XAG','USD',22.885,23.21,'2023-10-19','2023-10-19 00:00:00',-0.325,-1.4201,'2023-10-20 06:10:12','2023-10-20 06:10:12',0.7358,0.6745,0.6438,0.6131,0.5518),
(2532,'XAU','USD',1984.2,1948.65,'2023-10-20','2023-10-20 00:00:00',35.55,1.7917,'2023-10-21 06:00:08','2023-10-21 06:00:08',63.7935,58.4774,55.8193,53.1613,47.8451),
(2533,'XAG','USD',23.215,22.885,'2023-10-20','2023-10-20 00:00:00',0.33,1.4215,'2023-10-21 06:10:07','2023-10-21 06:10:07',0.7464,0.6842,0.6531,0.622,0.5598),
(2534,'XAU','USD',1980.95,1984.2,'2023-10-23','2023-10-23 00:00:00',-3.25,-0.1641,'2023-10-24 06:00:14','2023-10-24 06:00:14',63.689,58.3816,55.7279,53.0742,47.7668),
(2535,'XAG','USD',23.185,23.215,'2023-10-23','2023-10-23 00:00:00',-0.03,-0.1294,'2023-10-24 06:10:12','2023-10-24 06:10:12',0.7454,0.6833,0.6522,0.6212,0.5591),
(2536,'XAU','USD',1967.4,1980.95,'2023-10-24','2023-10-24 00:00:00',-13.55,-0.6887,'2023-10-25 06:00:08','2023-10-25 06:00:08',63.2534,57.9823,55.3467,52.7111,47.44),
(2537,'XAG','USD',22.74,23.185,'2023-10-24','2023-10-24 00:00:00',-0.445,-1.9569,'2023-10-25 06:10:08','2023-10-25 06:10:08',0.7311,0.6702,0.6397,0.6093,0.5483),
(2538,'XAU','USD',1970.15,1967.4,'2023-10-25','2023-10-25 00:00:00',2.75,0.1396,'2023-10-26 06:00:12','2023-10-26 06:00:12',63.3418,58.0633,55.4241,52.7848,47.5063),
(2539,'XAG','USD',22.81,22.74,'2023-10-25','2023-10-25 00:00:00',0.07,0.3069,'2023-10-26 06:10:10','2023-10-26 06:10:10',0.7334,0.6722,0.6417,0.6111,0.55),
(2540,'XAU','USD',1991.45,1970.15,'2023-10-26','2023-10-26 00:00:00',21.3,1.0696,'2023-10-27 06:00:11','2023-10-27 06:00:11',64.0266,58.6911,56.0233,53.3555,48.02),
(2541,'XAG','USD',22.97,22.81,'2023-10-26','2023-10-26 00:00:00',0.16,0.6966,'2023-10-27 06:10:09','2023-10-27 06:10:09',0.7385,0.677,0.6462,0.6154,0.5539),
(2542,'XAU','USD',1987.6,1991.45,'2023-10-27','2023-10-27 00:00:00',-3.85,-0.1937,'2023-10-28 06:00:10','2023-10-28 06:00:10',63.9028,58.5776,55.915,53.2524,47.9271),
(2543,'XAG','USD',22.755,22.97,'2023-10-27','2023-10-27 00:00:00',-0.215,-0.9448,'2023-10-28 06:10:07','2023-10-28 06:10:07',0.7316,0.6706,0.6401,0.6097,0.5487),
(2544,'XAU','USD',1996.15,1987.6,'2023-10-30','2023-10-30 00:00:00',8.55,0.4283,'2023-10-31 06:00:08','2023-10-31 06:00:08',64.1777,58.8296,56.1555,53.4814,48.1333),
(2545,'XAG','USD',23.15,22.755,'2023-10-30','2023-10-30 00:00:00',0.395,1.7063,'2023-10-31 06:10:08','2023-10-31 06:10:08',0.7443,0.6823,0.6513,0.6202,0.5582),
(2546,'XAU','USD',1997.6,1996.15,'2023-10-31','2023-10-31 00:00:00',1.45,0.0726,'2023-11-01 06:00:07','2023-11-01 06:00:07',64.2243,58.8723,56.1963,53.5203,48.1682),
(2547,'XAG','USD',23.2,23.15,'2023-10-31','2023-10-31 00:00:00',0.05,0.2155,'2023-11-01 06:10:07','2023-11-01 06:10:07',0.7459,0.6837,0.6527,0.6216,0.5594),
(2548,'XAU','USD',1997.6,1997.6,'2023-11-01','2023-11-01 00:00:00',0,0,'2023-11-02 06:00:11','2023-11-02 06:00:11',64.2243,58.8723,56.1963,53.5203,48.1682),
(2549,'XAG','USD',23.2,23.2,'2023-11-01','2023-11-01 00:00:00',0,0,'2023-11-02 06:10:08','2023-11-02 06:10:08',0.7459,0.6837,0.6527,0.6216,0.5594),
(2550,'XAU','USD',1986.7,1997.6,'2023-11-02','2023-11-02 00:00:00',-10.9,-0.5486,'2023-11-03 06:00:11','2023-11-03 06:00:11',63.8739,58.5511,55.8897,53.2282,47.9054),
(2551,'XAG','USD',23.035,23.2,'2023-11-02','2023-11-02 00:00:00',-0.165,-0.7163,'2023-11-03 06:10:10','2023-11-03 06:10:10',0.7406,0.6789,0.648,0.6172,0.5554),
(2552,'XAU','USD',1960.1,1967.8,'2023-11-08','2023-11-08 00:00:00',-7.7,-0.3928,'2023-11-09 06:00:07','2023-11-09 06:00:07',63.0187,57.7671,55.1413,52.5156,47.264),
(2553,'XAG','USD',22.44,22.535,'2023-11-08','2023-11-08 00:00:00',-0.095,-0.4234,'2023-11-09 06:10:08','2023-11-09 06:10:08',0.7215,0.6613,0.6313,0.6012,0.5411),
(2554,'XAU','USD',1946.75,1960.1,'2023-11-09','2023-11-09 00:00:00',-13.35,-0.6858,'2023-11-10 06:00:07','2023-11-10 06:00:07',62.5895,57.3737,54.7658,52.1579,46.9421),
(2555,'XAG','USD',22.55,22.44,'2023-11-09','2023-11-09 00:00:00',0.11,0.4878,'2023-11-10 06:10:06','2023-11-10 06:10:06',0.725,0.6646,0.6344,0.6042,0.5437),
(2556,'XAU','USD',1937.45,1953.45,'2023-11-13','2023-11-13 00:00:00',-16,-0.8258,'2023-11-14 06:00:07','2023-11-14 06:00:07',62.2905,57.0996,54.5042,51.9087,46.7178),
(2557,'XAG','USD',22.075,22.495,'2023-11-13','2023-11-13 00:00:00',-0.42,-1.9026,'2023-11-14 06:10:06','2023-11-14 06:10:06',0.7097,0.6506,0.621,0.5914,0.5323),
(2558,'XAU','USD',1946.55,1937.45,'2023-11-14','2023-11-14 00:00:00',9.1,0.4675,'2023-11-15 06:00:07','2023-11-15 06:00:07',62.583,57.3678,54.7602,52.1525,46.9373),
(2559,'XAG','USD',22.35,22.075,'2023-11-14','2023-11-14 00:00:00',0.275,1.2304,'2023-11-15 06:10:06','2023-11-15 06:10:06',0.7186,0.6587,0.6287,0.5988,0.5389),
(2560,'XAU','USD',1973.4,1946.55,'2023-11-15','2023-11-15 00:00:00',26.85,1.3606,'2023-11-16 06:00:07','2023-11-16 06:00:07',63.4463,58.1591,55.5155,52.8719,47.5847),
(2561,'XAG','USD',23.41,22.35,'2023-11-15','2023-11-15 00:00:00',1.06,4.528,'2023-11-16 06:10:07','2023-11-16 06:10:07',0.7526,0.6899,0.6586,0.6272,0.5645),
(2562,'XAU','USD',1966.5,1973.4,'2023-11-16','2023-11-16 00:00:00',-6.9,-0.3509,'2023-11-17 06:00:10','2023-11-17 06:00:10',63.2244,57.9557,55.3214,52.687,47.4183),
(2563,'XAG','USD',23.67,23.41,'2023-11-16','2023-11-16 00:00:00',0.26,1.0984,'2023-11-17 06:10:10','2023-11-17 06:10:10',0.761,0.6976,0.6659,0.6342,0.5708),
(2564,'XAU','USD',1992.15,1966.5,'2023-11-17','2023-11-17 00:00:00',25.65,1.2876,'2023-11-18 06:00:07','2023-11-18 06:00:07',64.0491,58.7117,56.043,53.3743,48.0368),
(2565,'XAG','USD',23.995,23.67,'2023-11-17','2023-11-17 00:00:00',0.325,1.3544,'2023-11-18 06:10:06','2023-11-18 06:10:06',0.7715,0.7072,0.675,0.6429,0.5786),
(2566,'XAU','USD',1976.05,1992.15,'2023-11-20','2023-11-20 00:00:00',-16.1,-0.8148,'2023-11-21 06:00:06','2023-11-21 06:00:06',63.5315,58.2372,55.59,52.9429,47.6486),
(2567,'XAG','USD',23.385,23.995,'2023-11-20','2023-11-20 00:00:00',-0.61,-2.6085,'2023-11-21 06:10:06','2023-11-21 06:10:06',0.7518,0.6892,0.6579,0.6265,0.5639),
(2568,'XAU','USD',1988.55,1976.05,'2023-11-21','2023-11-21 00:00:00',12.5,0.6286,'2023-11-22 06:00:08','2023-11-22 06:00:08',63.9334,58.6056,55.9417,53.2778,47.95),
(2569,'XAG','USD',23.53,23.385,'2023-11-21','2023-11-21 00:00:00',0.145,0.6162,'2023-11-22 06:10:07','2023-11-22 06:10:07',0.7565,0.6935,0.6619,0.6304,0.5674),
(2570,'XAU','USD',1999.9,1988.55,'2023-11-22','2023-11-22 00:00:00',11.35,0.5675,'2023-11-23 06:00:08','2023-11-23 06:00:08',64.2983,58.9401,56.261,53.5819,48.2237),
(2571,'XAU','USD',1995.2,1992.6,'2023-11-24','2023-11-24 00:00:00',2.6,0.1303,'2023-11-25 06:00:07','2023-11-25 06:00:07',64.1472,58.8016,56.1288,53.456,48.1104),
(2572,'XAG','USD',23.705,23.655,'2023-11-24','2023-11-24 00:00:00',0.05,0.2109,'2023-11-25 06:10:07','2023-11-25 06:10:07',0.7621,0.6986,0.6669,0.6351,0.5716),
(2573,'XAU','USD',1922.55,1926.2,'2023-09-25','2023-09-25 00:00:00',-3.65,-0.1899,'2023-11-27 20:27:58','2023-11-27 20:27:58',61.8114,56.6605,54.085,51.5095,46.3586),
(2574,'XAG','USD',23.56,23.65,'2023-09-25','2023-09-25 00:00:00',-0.09,-0.382,'2023-11-27 20:27:59','2023-11-27 20:27:59',0.7575,0.6943,0.6628,0.6312,0.5681),
(2575,'XAU','USD',1912.3,1922.55,'2023-09-26','2023-09-26 00:00:00',-10.25,-0.536,'2023-11-27 20:27:59','2023-11-27 20:27:59',61.4819,56.3584,53.7966,51.2349,46.1114),
(2576,'XAG','USD',23.015,23.56,'2023-09-26','2023-09-26 00:00:00',-0.545,-2.368,'2023-11-27 20:27:59','2023-11-27 20:27:59',0.7399,0.6783,0.6475,0.6166,0.555),
(2577,'XAU','USD',1895.55,1912.3,'2023-09-27','2023-09-27 00:00:00',-16.75,-0.8836,'2023-11-27 20:28:00','2023-11-27 20:28:00',60.9433,55.8647,53.3254,50.7861,45.7075),
(2578,'XAG','USD',22.79,23.015,'2023-09-27','2023-09-27 00:00:00',-0.225,-0.9873,'2023-11-27 20:28:00','2023-11-27 20:28:00',0.7327,0.6717,0.6411,0.6106,0.5495),
(2579,'XAU','USD',1874.1,1895.55,'2023-09-28','2023-09-28 00:00:00',-21.45,-1.1445,'2023-11-27 20:28:00','2023-11-27 20:28:00',60.2537,55.2326,52.722,50.2114,45.1903),
(2580,'XAG','USD',22.55,22.79,'2023-09-28','2023-09-28 00:00:00',-0.24,-1.0643,'2023-11-27 20:28:00','2023-11-27 20:28:00',0.725,0.6646,0.6344,0.6042,0.5437),
(2581,'XAU','USD',1871.6,1874.1,'2023-09-29','2023-09-29 00:00:00',-2.5,-0.1336,'2023-11-27 20:28:01','2023-11-27 20:28:01',60.1733,55.1589,52.6517,50.1444,45.13),
(2582,'XAG','USD',23.075,22.55,'2023-09-29','2023-09-29 00:00:00',0.525,2.2752,'2023-11-27 20:28:01','2023-11-27 20:28:01',0.7419,0.6801,0.6491,0.6182,0.5564),
(2587,'XAU','USD',1870,1859.7,'2023-10-11','2023-10-11 00:00:00',10.3,0.5508,'2023-11-27 20:28:02','2023-11-27 20:28:02',60.1219,55.1117,52.6067,50.1016,45.0914),
(2588,'XAG','USD',22.07,21.715,'2023-10-11','2023-10-11 00:00:00',0.355,1.6085,'2023-11-27 20:28:02','2023-11-27 20:28:02',0.7096,0.6504,0.6209,0.5913,0.5322),
(2589,'XAU','USD',1881.15,1870,'2023-10-12','2023-10-12 00:00:00',11.15,0.5927,'2023-11-27 20:28:03','2023-11-27 20:28:03',60.4804,55.4403,52.9203,50.4003,45.3603),
(2590,'XAG','USD',22.14,22.07,'2023-10-12','2023-10-12 00:00:00',0.07,0.3162,'2023-11-27 20:28:03','2023-11-27 20:28:03',0.7118,0.6525,0.6228,0.5932,0.5339),
(2591,'XAU','USD',1887,1881.15,'2023-10-13','2023-10-13 00:00:00',5.85,0.31,'2023-11-27 20:28:03','2023-11-27 20:28:03',60.6685,55.6128,53.0849,50.557,45.5013),
(2592,'XAG','USD',22.08,22.14,'2023-10-13','2023-10-13 00:00:00',-0.06,-0.2717,'2023-11-27 20:28:03','2023-11-27 20:28:03',0.7099,0.6507,0.6212,0.5916,0.5324),
(2593,'XAU','USD',1914.65,1887,'2023-10-16','2023-10-16 00:00:00',27.65,1.4441,'2023-11-27 20:28:04','2023-11-27 20:28:04',61.5574,56.4276,53.8627,51.2979,46.1681),
(2594,'XAG','USD',22.595,22.08,'2023-10-16','2023-10-16 00:00:00',0.515,2.2793,'2023-11-27 20:28:04','2023-11-27 20:28:04',0.7264,0.6659,0.6356,0.6054,0.5448),
(2595,'XAU','USD',1988.5,1986.7,'2023-11-03','2023-11-03 00:00:00',1.8,0.0905,'2023-11-27 20:28:04','2023-11-27 20:28:04',63.9318,58.6041,55.9403,53.2765,47.9488),
(2596,'XAG','USD',22.64,23.035,'2023-11-03','2023-11-03 00:00:00',-0.395,-1.7447,'2023-11-27 20:28:05','2023-11-27 20:28:05',0.7279,0.6672,0.6369,0.6066,0.5459),
(2597,'XAU','USD',1987.1,1988.5,'2023-11-06','2023-11-06 00:00:00',-1.4,-0.0705,'2023-11-27 20:28:05','2023-11-27 20:28:05',63.8867,58.5629,55.9009,53.239,47.9151),
(2598,'XAG','USD',23.21,22.64,'2023-11-06','2023-11-06 00:00:00',0.57,2.4558,'2023-11-27 20:28:05','2023-11-27 20:28:05',0.7462,0.684,0.6529,0.6218,0.5597),
(2599,'XAU','USD',1967.8,1987.1,'2023-11-07','2023-11-07 00:00:00',-19.3,-0.9808,'2023-11-27 20:28:05','2023-11-27 20:28:05',63.2662,57.9941,55.358,52.7219,47.4497),
(2600,'XAG','USD',22.535,23.21,'2023-11-07','2023-11-07 00:00:00',-0.675,-2.9953,'2023-11-27 20:28:06','2023-11-27 20:28:06',0.7245,0.6641,0.634,0.6038,0.5434),
(2601,'XAU','USD',2011.7,1995.2,'2023-11-27','2023-11-27 00:00:00',16.5,0.8202,'2023-11-28 06:00:06','2023-11-28 06:00:06',64.6777,59.2879,56.5929,53.898,48.5082),
(2602,'XAG','USD',24.755,23.705,'2023-11-27','2023-11-27 00:00:00',1.05,4.2416,'2023-11-28 06:10:06','2023-11-28 06:10:06',0.7959,0.7296,0.6964,0.6632,0.5969),
(2603,'XAU','USD',2014,2011.7,'2023-11-28','2023-11-28 00:00:00',2.3,0.1142,'2023-11-29 06:00:07','2023-11-29 06:00:07',64.7516,59.3556,56.6577,53.9597,48.5637),
(2604,'XAG','USD',24.65,24.755,'2023-11-28','2023-11-28 00:00:00',-0.105,-0.426,'2023-11-29 06:10:07','2023-11-29 06:10:07',0.7925,0.7265,0.6935,0.6604,0.5944),
(2605,'XAU','USD',2037.6,2014,'2023-11-29','2023-11-29 00:00:00',23.6,1.1582,'2023-11-30 06:00:06','2023-11-30 06:00:06',65.5104,60.0512,57.3216,54.592,49.1328),
(2606,'XAG','USD',24.965,24.65,'2023-11-29','2023-11-29 00:00:00',0.315,1.2618,'2023-11-30 06:10:06','2023-11-30 06:10:06',0.8026,0.7358,0.7023,0.6689,0.602),
(2607,'XAU','USD',2037.85,2037.6,'2023-11-30','2023-11-30 00:00:00',0.25,0.0123,'2023-12-01 06:00:07','2023-12-01 06:00:07',65.5184,60.0585,57.3286,54.5987,49.1388),
(2608,'XAG','USD',25.02,24.965,'2023-11-30','2023-11-30 00:00:00',0.055,0.2198,'2023-12-01 06:10:07','2023-12-01 06:10:07',0.8044,0.7374,0.7039,0.6703,0.6033),
(2609,'XAU','USD',2044.55,2037.85,'2023-12-01','2023-12-01 00:00:00',6.7,0.3277,'2023-12-02 06:00:07','2023-12-02 06:00:07',65.7338,60.256,57.5171,54.7782,49.3004),
(2610,'XAG','USD',25.16,25.02,'2023-12-01','2023-12-01 00:00:00',0.14,0.5564,'2023-12-02 06:10:07','2023-12-02 06:10:07',0.8089,0.7415,0.7078,0.6741,0.6067),
(2611,'XAU','USD',2066.95,2044.55,'2023-12-04','2023-12-04 00:00:00',22.4,1.0837,'2023-12-05 06:00:08','2023-12-05 06:00:08',66.454,60.9162,58.1472,55.3783,49.8405),
(2612,'XAG','USD',25.165,25.16,'2023-12-04','2023-12-04 00:00:00',0.005,0.0199,'2023-12-05 06:10:08','2023-12-05 06:10:08',0.8091,0.7417,0.7079,0.6742,0.6068),
(2613,'XAU','USD',2023.45,2066.95,'2023-12-05','2023-12-05 00:00:00',-43.5,-2.1498,'2023-12-06 06:00:08','2023-12-06 06:00:08',65.0554,59.6341,56.9235,54.2129,48.7916),
(2614,'XAG','USD',24.27,25.165,'2023-12-05','2023-12-05 00:00:00',-0.895,-3.6877,'2023-12-06 06:10:08','2023-12-06 06:10:08',0.7803,0.7153,0.6828,0.6502,0.5852),
(2615,'XAU','USD',2021.4,2023.45,'2023-12-06','2023-12-06 00:00:00',-2.05,-0.1014,'2023-12-07 06:00:06','2023-12-07 06:00:06',64.9895,59.5737,56.8658,54.1579,48.7421),
(2616,'XAG','USD',24.095,24.27,'2023-12-06','2023-12-06 00:00:00',-0.175,-0.7263,'2023-12-07 06:10:06','2023-12-07 06:10:06',0.7747,0.7101,0.6778,0.6456,0.581),
(2617,'XAU','USD',2033.3,2021.4,'2023-12-07','2023-12-07 00:00:00',11.9,0.5853,'2023-12-08 06:00:12','2023-12-08 06:00:12',65.3721,59.9244,57.2006,54.4768,49.0291),
(2618,'XAG','USD',23.91,24.095,'2023-12-07','2023-12-07 00:00:00',-0.185,-0.7737,'2023-12-08 06:10:15','2023-12-08 06:10:15',0.7687,0.7047,0.6726,0.6406,0.5765),
(2619,'XAU','USD',2030,2033.3,'2023-12-08','2023-12-08 00:00:00',-3.3,-0.1626,'2023-12-09 06:00:08','2023-12-09 06:00:08',65.266,59.8272,57.1078,54.3883,48.9495),
(2620,'XAG','USD',23.79,23.91,'2023-12-08','2023-12-08 00:00:00',-0.12,-0.5044,'2023-12-09 06:10:07','2023-12-09 06:10:07',0.7649,0.7011,0.6693,0.6374,0.5736),
(2621,'XAU','USD',1991.95,2030,'2023-12-11','2023-12-11 00:00:00',-38.05,-1.9102,'2023-12-12 06:00:07','2023-12-12 06:00:07',64.0427,58.7058,56.0373,53.3689,48.032),
(2622,'XAG','USD',22.92,23.79,'2023-12-11','2023-12-11 00:00:00',-0.87,-3.7958,'2023-12-12 06:10:06','2023-12-12 06:10:06',0.7369,0.6755,0.6448,0.6141,0.5527),
(2623,'XAU','USD',1986.9,1991.95,'2023-12-12','2023-12-12 00:00:00',-5.05,-0.2542,'2023-12-13 06:00:08','2023-12-13 06:00:08',63.8803,58.557,55.8953,53.2336,47.9102),
(2624,'XAG','USD',22.955,22.92,'2023-12-12','2023-12-12 00:00:00',0.035,0.1525,'2023-12-13 06:10:06','2023-12-13 06:10:06',0.738,0.6765,0.6458,0.615,0.5535),
(2625,'XAU','USD',2055.6,2055.6,'2023-12-26','2023-12-26 00:00:00',0,0,'2023-12-28 06:00:09','2023-12-28 06:00:09',66.0891,60.5817,57.8279,55.0742,49.5668),
(2626,'XAG','USD',24.185,24.185,'2023-12-26','2023-12-26 00:00:00',0,0,'2023-12-28 06:10:09','2023-12-28 06:10:09',0.7776,0.7128,0.6804,0.648,0.5832),
(2627,'XAU','USD',1981.55,1986.9,'2023-12-13','2023-12-13 00:00:00',-5.35,-0.27,'2023-12-31 00:10:08','2023-12-31 00:10:08',63.7083,58.3993,55.7448,53.0903,47.7812),
(2628,'XAU','USD',2034.1,1981.55,'2023-12-14','2023-12-14 00:00:00',52.55,2.5835,'2023-12-31 00:10:09','2023-12-31 00:10:09',65.3978,59.948,57.2231,54.4982,49.0484),
(2629,'XAU','USD',2043.65,2034.1,'2023-12-15','2023-12-15 00:00:00',9.55,0.4673,'2023-12-31 00:10:09','2023-12-31 00:10:09',65.7049,60.2295,57.4918,54.7541,49.2787),
(2630,'XAU','USD',2020.95,2043.65,'2023-12-18','2023-12-18 00:00:00',-22.7,-1.1232,'2023-12-31 00:10:10','2023-12-31 00:10:10',64.9751,59.5605,56.8532,54.1459,48.7313),
(2631,'XAU','USD',2020.95,2020.95,'2023-12-19','2023-12-19 00:00:00',0,0,'2023-12-31 00:10:11','2023-12-31 00:10:11',64.9751,59.5605,56.8532,54.1459,48.7313),
(2632,'XAU','USD',2036.35,2020.95,'2023-12-20','2023-12-20 00:00:00',15.4,0.7563,'2023-12-31 00:10:12','2023-12-31 00:10:12',65.4702,60.0143,57.2864,54.5585,49.1026),
(2633,'XAU','USD',2034.3,2036.35,'2023-12-21','2023-12-21 00:00:00',-2.05,-0.1008,'2023-12-31 00:10:12','2023-12-31 00:10:12',65.4043,59.9539,57.2287,54.5036,49.0532),
(2634,'XAU','USD',2055.6,2034.3,'2023-12-22','2023-12-22 00:00:00',21.3,1.0362,'2023-12-31 00:10:13','2023-12-31 00:10:13',66.0891,60.5817,57.8279,55.0742,49.5668),
(2635,'XAG','USD',22.725,22.955,'2023-12-13','2023-12-13 00:00:00',-0.23,-1.0121,'2023-12-31 00:10:33','2023-12-31 00:10:33',0.7306,0.6697,0.6393,0.6089,0.548),
(2636,'XAG','USD',23.99,22.725,'2023-12-14','2023-12-14 00:00:00',1.265,5.273,'2023-12-31 00:10:33','2023-12-31 00:10:33',0.7713,0.707,0.6749,0.6427,0.5785),
(2637,'XAG','USD',24.19,23.99,'2023-12-15','2023-12-15 00:00:00',0.2,0.8268,'2023-12-31 00:10:34','2023-12-31 00:10:34',0.7777,0.7129,0.6805,0.6481,0.5833),
(2638,'XAG','USD',23.935,24.19,'2023-12-18','2023-12-18 00:00:00',-0.255,-1.0654,'2023-12-31 00:10:35','2023-12-31 00:10:35',0.7695,0.7054,0.6733,0.6413,0.5771),
(2639,'XAG','USD',23.935,23.935,'2023-12-19','2023-12-19 00:00:00',0,0,'2023-12-31 00:10:36','2023-12-31 00:10:36',0.7695,0.7054,0.6733,0.6413,0.5771),
(2640,'XAG','USD',23.97,23.935,'2023-12-20','2023-12-20 00:00:00',0.035,0.146,'2023-12-31 00:10:36','2023-12-31 00:10:36',0.7707,0.7064,0.6743,0.6422,0.578),
(2641,'XAG','USD',24.185,23.97,'2023-12-21','2023-12-21 00:00:00',0.215,0.889,'2023-12-31 00:10:37','2023-12-31 00:10:37',0.7776,0.7128,0.6804,0.648,0.5832),
(2642,'XAG','USD',24.185,24.185,'2023-12-22','2023-12-22 00:00:00',0,0,'2023-12-31 00:10:38','2023-12-31 00:10:38',0.7776,0.7128,0.6804,0.648,0.5832),
(2643,'XAU','USD',2061.7,2055.6,'2023-12-27','2023-12-27 00:00:00',6.1,0.2959,'2023-12-31 00:11:20','2023-12-31 00:11:20',66.2852,60.7614,57.9995,55.2377,49.7139),
(2644,'XAU','USD',2077.8,2061.7,'2023-12-28','2023-12-28 00:00:00',16.1,0.7749,'2023-12-31 00:11:20','2023-12-31 00:11:20',66.8028,61.2359,58.4525,55.669,50.1021),
(2645,'XAU','USD',2077.8,2077.8,'2023-12-29','2023-12-29 00:00:00',0,0,'2023-12-31 00:11:21','2023-12-31 00:11:21',66.8028,61.2359,58.4525,55.669,50.1021),
(2646,'XAG','USD',24.04,24.185,'2023-12-27','2023-12-27 00:00:00',-0.145,-0.6032,'2023-12-31 00:11:38','2023-12-31 00:11:38',0.7729,0.7085,0.6763,0.6441,0.5797),
(2647,'XAG','USD',24.255,24.04,'2023-12-28','2023-12-28 00:00:00',0.215,0.8864,'2023-12-31 00:11:39','2023-12-31 00:11:39',0.7798,0.7148,0.6823,0.6498,0.5849),
(2648,'XAG','USD',24.255,24.255,'2023-12-29','2023-12-29 00:00:00',0,0,'2023-12-31 00:11:40','2023-12-31 00:11:40',0.7798,0.7148,0.6823,0.6498,0.5849),
(2883,'XAU','USD',2077.8,2077.8,'2024-01-02','2024-01-02 00:00:00',0,0,'2024-01-03 16:00:11','2024-01-03 16:00:11',66.8028,61.2359,58.4525,55.669,50.1021),
(2884,'XAG','USD',24.255,24.255,'2024-01-02','2024-01-02 00:00:00',0,0,'2024-01-03 16:10:12','2024-01-03 16:10:12',0.7798,0.7148,0.6823,0.6498,0.5849),
(2885,'XAU','USD',2077.8,2077.8,'2024-01-03','2024-01-03 00:00:00',0,0,'2024-01-04 16:00:12','2024-01-04 16:00:12',66.8028,61.2359,58.4525,55.669,50.1021),
(2886,'XAG','USD',24.255,24.255,'2024-01-03','2024-01-03 00:00:00',0,0,'2024-01-04 16:05:10','2024-01-04 16:05:10',0.7798,0.7148,0.6823,0.6498,0.5849),
(2887,'XAU','USD',2077.8,2077.8,'2024-01-04','2024-01-04 00:00:00',0,0,'2024-01-05 16:00:07','2024-01-05 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2888,'XAG','USD',24.255,24.255,'2024-01-04','2024-01-04 00:00:00',0,0,'2024-01-05 16:05:08','2024-01-05 16:05:08',0.7798,0.7148,0.6823,0.6498,0.5849),
(2889,'XAU','USD',2077.8,2077.8,'2024-01-05','2024-01-05 00:00:00',0,0,'2024-01-06 16:00:08','2024-01-06 16:00:08',66.8028,61.2359,58.4525,55.669,50.1021),
(2890,'XAG','USD',24.255,24.255,'2024-01-05','2024-01-05 00:00:00',0,0,'2024-01-06 16:05:06','2024-01-06 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2891,'XAU','USD',2077.8,2077.8,'2024-01-08','2024-01-08 00:00:00',0,0,'2024-01-09 16:00:13','2024-01-09 16:00:13',66.8028,61.2359,58.4525,55.669,50.1021),
(2892,'XAG','USD',24.255,24.255,'2024-01-08','2024-01-08 00:00:00',0,0,'2024-01-09 16:05:14','2024-01-09 16:05:14',0.7798,0.7148,0.6823,0.6498,0.5849),
(2895,'XAU','USD',2077.8,2077.8,'2024-01-12','2024-01-12 00:00:00',0,0,'2024-01-15 00:58:50','2024-01-15 00:58:50',66.8028,61.2359,58.4525,55.669,50.1021),
(2906,'XAU','USD',2077.8,2077.8,'2024-01-09','2024-01-09 00:00:00',0,0,'2024-01-16 02:05:55','2024-01-16 02:05:55',66.8028,61.2359,58.4525,55.669,50.1021),
(2907,'XAG','USD',24.255,24.255,'2024-01-09','2024-01-09 00:00:00',0,0,'2024-01-16 02:05:55','2024-01-16 02:05:55',0.7798,0.7148,0.6823,0.6498,0.5849),
(2908,'XAU','USD',2077.8,2077.8,'2024-01-10','2024-01-10 00:00:00',0,0,'2024-01-16 02:05:55','2024-01-16 02:05:55',66.8028,61.2359,58.4525,55.669,50.1021),
(2909,'XAG','USD',24.255,24.255,'2024-01-10','2024-01-10 00:00:00',0,0,'2024-01-16 02:05:56','2024-01-16 02:05:56',0.7798,0.7148,0.6823,0.6498,0.5849),
(2910,'XAU','USD',2077.8,2077.8,'2024-01-11','2024-01-11 00:00:00',0,0,'2024-01-16 02:05:56','2024-01-16 02:05:56',66.8028,61.2359,58.4525,55.669,50.1021),
(2911,'XAG','USD',24.255,24.255,'2024-01-11','2024-01-11 00:00:00',0,0,'2024-01-16 02:05:56','2024-01-16 02:05:56',0.7798,0.7148,0.6823,0.6498,0.5849),
(2913,'XAG','USD',24.255,24.255,'2024-01-12','2024-01-12 00:00:00',0,0,'2024-01-16 02:05:57','2024-01-16 02:05:57',0.7798,0.7148,0.6823,0.6498,0.5849),
(2923,'XAU','USD',2077.8,2077.8,'2024-01-16','2024-01-16 00:00:00',0,0,'2024-01-17 16:00:09','2024-01-17 16:00:09',66.8028,61.2359,58.4525,55.669,50.1021),
(2924,'XAG','USD',24.255,24.255,'2024-01-16','2024-01-16 00:00:00',0,0,'2024-01-17 16:05:10','2024-01-17 16:05:10',0.7798,0.7148,0.6823,0.6498,0.5849),
(2925,'XAU','USD',2077.8,2077.8,'2024-01-17','2024-01-17 00:00:00',0,0,'2024-01-18 16:00:07','2024-01-18 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2926,'XAG','USD',24.255,24.255,'2024-01-17','2024-01-17 00:00:00',0,0,'2024-01-18 16:05:07','2024-01-18 16:05:07',0.7798,0.7148,0.6823,0.6498,0.5849),
(2927,'XAU','USD',2077.8,2077.8,'2024-01-18','2024-01-18 00:00:00',0,0,'2024-01-19 16:00:07','2024-01-19 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2928,'XAG','USD',24.255,24.255,'2024-01-18','2024-01-18 00:00:00',0,0,'2024-01-19 16:05:10','2024-01-19 16:05:10',0.7798,0.7148,0.6823,0.6498,0.5849),
(2929,'XAU','USD',2077.8,2077.8,'2024-01-19','2024-01-19 00:00:00',0,0,'2024-01-20 16:00:06','2024-01-20 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2930,'XAG','USD',24.255,24.255,'2024-01-19','2024-01-19 00:00:00',0,0,'2024-01-20 16:05:06','2024-01-20 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2931,'XAU','USD',2077.8,2077.8,'2024-01-22','2024-01-22 00:00:00',0,0,'2024-01-23 16:00:07','2024-01-23 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2932,'XAG','USD',24.255,24.255,'2024-01-22','2024-01-22 00:00:00',0,0,'2024-01-23 16:05:06','2024-01-23 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2933,'XAU','USD',2077.8,2077.8,'2024-01-23','2024-01-23 00:00:00',0,0,'2024-01-24 16:00:10','2024-01-24 16:00:10',66.8028,61.2359,58.4525,55.669,50.1021),
(2934,'XAG','USD',24.255,24.255,'2024-01-23','2024-01-23 00:00:00',0,0,'2024-01-24 16:05:07','2024-01-24 16:05:07',0.7798,0.7148,0.6823,0.6498,0.5849),
(2935,'XAU','USD',2077.8,2077.8,'2024-01-24','2024-01-24 00:00:00',0,0,'2024-01-25 16:00:07','2024-01-25 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2936,'XAG','USD',24.255,24.255,'2024-01-24','2024-01-24 00:00:00',0,0,'2024-01-25 16:05:06','2024-01-25 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2937,'XAU','USD',2077.8,2077.8,'2024-01-25','2024-01-25 00:00:00',0,0,'2024-01-26 16:00:08','2024-01-26 16:00:08',66.8028,61.2359,58.4525,55.669,50.1021),
(2938,'XAG','USD',24.255,24.255,'2024-01-25','2024-01-25 00:00:00',0,0,'2024-01-26 16:05:10','2024-01-26 16:05:10',0.7798,0.7148,0.6823,0.6498,0.5849),
(2939,'XAU','USD',2077.8,2077.8,'2024-01-26','2024-01-26 00:00:00',0,0,'2024-01-27 16:00:06','2024-01-27 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2940,'XAG','USD',24.255,24.255,'2024-01-26','2024-01-26 00:00:00',0,0,'2024-01-27 16:05:06','2024-01-27 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2959,'XAU','USD',2077.8,2077.8,'2024-01-29','2024-01-29 00:00:00',0,0,'2024-02-08 06:15:53','2024-02-08 06:15:53',66.8028,61.2359,58.4525,55.669,50.1021),
(2960,'XAU','USD',2077.8,2077.8,'2024-01-30','2024-01-30 00:00:00',0,0,'2024-02-08 06:15:53','2024-02-08 06:15:53',66.8028,61.2359,58.4525,55.669,50.1021),
(2961,'XAU','USD',2077.8,2077.8,'2024-01-31','2024-01-31 00:00:00',0,0,'2024-02-08 06:15:54','2024-02-08 06:15:54',66.8028,61.2359,58.4525,55.669,50.1021),
(2962,'XAU','USD',2077.8,2077.8,'2024-02-01','2024-02-01 00:00:00',0,0,'2024-02-08 06:15:55','2024-02-08 06:15:55',66.8028,61.2359,58.4525,55.669,50.1021),
(2963,'XAU','USD',2077.8,2077.8,'2024-02-02','2024-02-02 00:00:00',0,0,'2024-02-08 06:15:55','2024-02-08 06:15:55',66.8028,61.2359,58.4525,55.669,50.1021),
(2964,'XAU','USD',2077.8,2077.8,'2024-02-05','2024-02-05 00:00:00',0,0,'2024-02-08 06:15:56','2024-02-08 06:15:56',66.8028,61.2359,58.4525,55.669,50.1021),
(2965,'XAU','USD',2077.8,2077.8,'2024-02-06','2024-02-06 00:00:00',0,0,'2024-02-08 06:15:57','2024-02-08 06:15:57',66.8028,61.2359,58.4525,55.669,50.1021),
(2966,'XAG','USD',24.255,24.255,'2024-01-29','2024-01-29 00:00:00',0,0,'2024-02-08 06:18:19','2024-02-08 06:18:19',0.7798,0.7148,0.6823,0.6498,0.5849),
(2967,'XAG','USD',24.255,24.255,'2024-01-30','2024-01-30 00:00:00',0,0,'2024-02-08 06:18:19','2024-02-08 06:18:19',0.7798,0.7148,0.6823,0.6498,0.5849),
(2968,'XAG','USD',24.255,24.255,'2024-01-31','2024-01-31 00:00:00',0,0,'2024-02-08 06:18:20','2024-02-08 06:18:20',0.7798,0.7148,0.6823,0.6498,0.5849),
(2969,'XAG','USD',24.255,24.255,'2024-02-01','2024-02-01 00:00:00',0,0,'2024-02-08 06:18:21','2024-02-08 06:18:21',0.7798,0.7148,0.6823,0.6498,0.5849),
(2970,'XAG','USD',24.255,24.255,'2024-02-02','2024-02-02 00:00:00',0,0,'2024-02-08 06:18:21','2024-02-08 06:18:21',0.7798,0.7148,0.6823,0.6498,0.5849),
(2971,'XAG','USD',24.255,24.255,'2024-02-05','2024-02-05 00:00:00',0,0,'2024-02-08 06:18:22','2024-02-08 06:18:22',0.7798,0.7148,0.6823,0.6498,0.5849),
(2972,'XAG','USD',24.255,24.255,'2024-02-06','2024-02-06 00:00:00',0,0,'2024-02-08 06:18:23','2024-02-08 06:18:23',0.7798,0.7148,0.6823,0.6498,0.5849),
(2973,'XAU','USD',2077.8,2077.8,'2024-02-07','2024-02-07 00:00:00',0,0,'2024-02-08 16:00:06','2024-02-08 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2974,'XAG','USD',24.255,24.255,'2024-02-07','2024-02-07 00:00:00',0,0,'2024-02-08 16:05:05','2024-02-08 16:05:05',0.7798,0.7148,0.6823,0.6498,0.5849),
(2975,'XAU','USD',2077.8,2077.8,'2024-02-08','2024-02-08 00:00:00',0,0,'2024-02-09 16:00:06','2024-02-09 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2976,'XAG','USD',24.255,24.255,'2024-02-08','2024-02-08 00:00:00',0,0,'2024-02-09 16:05:06','2024-02-09 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2977,'XAU','USD',2077.8,2077.8,'2024-02-09','2024-02-09 00:00:00',0,0,'2024-02-10 16:00:06','2024-02-10 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2978,'XAG','USD',24.255,24.255,'2024-02-09','2024-02-09 00:00:00',0,0,'2024-02-10 16:05:06','2024-02-10 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2979,'XAU','USD',2077.8,2077.8,'2024-02-12','2024-02-12 00:00:00',0,0,'2024-02-13 16:00:07','2024-02-13 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2980,'XAG','USD',24.255,24.255,'2024-02-12','2024-02-12 00:00:00',0,0,'2024-02-13 16:05:07','2024-02-13 16:05:07',0.7798,0.7148,0.6823,0.6498,0.5849),
(2981,'XAU','USD',2077.8,2077.8,'2024-02-13','2024-02-13 00:00:00',0,0,'2024-02-14 16:00:07','2024-02-14 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2982,'XAG','USD',24.255,24.255,'2024-02-13','2024-02-13 00:00:00',0,0,'2024-02-14 16:05:06','2024-02-14 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2983,'XAU','USD',2077.8,2077.8,'2024-02-14','2024-02-14 00:00:00',0,0,'2024-02-15 16:00:07','2024-02-15 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2984,'XAG','USD',24.255,24.255,'2024-02-14','2024-02-14 00:00:00',0,0,'2024-02-15 16:05:06','2024-02-15 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2985,'XAU','USD',2077.8,2077.8,'2024-02-15','2024-02-15 00:00:00',0,0,'2024-02-16 16:00:07','2024-02-16 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2986,'XAG','USD',24.255,24.255,'2024-02-15','2024-02-15 00:00:00',0,0,'2024-02-16 16:05:06','2024-02-16 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2987,'XAU','USD',2077.8,2077.8,'2024-02-16','2024-02-16 00:00:00',0,0,'2024-02-17 16:00:08','2024-02-17 16:00:08',66.8028,61.2359,58.4525,55.669,50.1021),
(2988,'XAG','USD',24.255,24.255,'2024-02-16','2024-02-16 00:00:00',0,0,'2024-02-17 16:05:07','2024-02-17 16:05:07',0.7798,0.7148,0.6823,0.6498,0.5849),
(2989,'XAU','USD',2077.8,2077.8,'2024-02-20','2024-02-20 00:00:00',0,0,'2024-02-21 16:00:09','2024-02-21 16:00:09',66.8028,61.2359,58.4525,55.669,50.1021),
(2990,'XAG','USD',24.255,24.255,'2024-02-20','2024-02-20 00:00:00',0,0,'2024-02-21 16:05:07','2024-02-21 16:05:07',0.7798,0.7148,0.6823,0.6498,0.5849),
(2991,'XAU','USD',2077.8,2077.8,'2024-02-21','2024-02-21 00:00:00',0,0,'2024-02-22 16:00:06','2024-02-22 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2992,'XAG','USD',24.255,24.255,'2024-02-21','2024-02-21 00:00:00',0,0,'2024-02-22 16:05:06','2024-02-22 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2993,'XAU','USD',2077.8,2077.8,'2024-02-22','2024-02-22 00:00:00',0,0,'2024-02-23 16:00:07','2024-02-23 16:00:07',66.8028,61.2359,58.4525,55.669,50.1021),
(2994,'XAG','USD',24.255,24.255,'2024-02-22','2024-02-22 00:00:00',0,0,'2024-02-23 16:05:06','2024-02-23 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2995,'XAU','USD',2077.8,2077.8,'2024-02-23','2024-02-23 00:00:00',0,0,'2024-02-24 16:00:05','2024-02-24 16:00:05',66.8028,61.2359,58.4525,55.669,50.1021),
(2996,'XAG','USD',24.255,24.255,'2024-02-23','2024-02-23 00:00:00',0,0,'2024-02-24 16:05:05','2024-02-24 16:05:05',0.7798,0.7148,0.6823,0.6498,0.5849),
(2997,'XAU','USD',2077.8,2077.8,'2024-02-26','2024-02-26 00:00:00',0,0,'2024-02-27 16:00:06','2024-02-27 16:00:06',66.8028,61.2359,58.4525,55.669,50.1021),
(2998,'XAG','USD',24.255,24.255,'2024-02-26','2024-02-26 00:00:00',0,0,'2024-02-27 16:05:06','2024-02-27 16:05:06',0.7798,0.7148,0.6823,0.6498,0.5849),
(2999,'XAU','USD',2036,2035.15,'2024-02-27','2024-02-27 00:00:00',0.85,0.0417,'2024-02-28 16:00:06','2024-02-28 16:00:06',65.4589,60.004,57.2766,54.5491,49.0942),
(3000,'XAG','USD',22.67,22.51,'2024-02-27','2024-02-27 00:00:00',0.16,0.7058,'2024-02-28 16:05:06','2024-02-28 16:05:06',0.7289,0.6681,0.6378,0.6074,0.5466),
(3001,'XAU','USD',2025.25,2036,'2024-02-28','2024-02-28 00:00:00',-10.75,-0.5308,'2024-02-29 16:00:07','2024-02-29 16:00:07',65.1133,59.6872,56.9741,54.2611,48.835),
(3002,'XAG','USD',22.345,22.67,'2024-02-28','2024-02-28 00:00:00',-0.325,-1.4545,'2024-02-29 16:05:06','2024-02-29 16:05:06',0.7184,0.6585,0.6286,0.5987,0.5388),
(3003,'XAU','USD',2032.8,2025.25,'2024-02-29','2024-02-29 00:00:00',7.55,0.3714,'2024-03-01 16:00:07','2024-03-01 16:00:07',65.356,59.9097,57.1865,54.4634,49.017),
(3004,'XAG','USD',22.34,22.345,'2024-02-29','2024-02-29 00:00:00',-0.005,-0.0224,'2024-03-01 16:05:06','2024-03-01 16:05:06',0.7182,0.6584,0.6285,0.5985,0.5387),
(3005,'XAU','USD',2050.3,2032.8,'2024-03-01','2024-03-01 00:00:00',17.5,0.8535,'2024-03-02 16:00:06','2024-03-02 16:00:06',65.9187,60.4255,57.6788,54.9322,49.439),
(3006,'XAG','USD',22.72,22.34,'2024-03-01','2024-03-01 00:00:00',0.38,1.6725,'2024-03-02 16:05:05','2024-03-02 16:05:05',0.7305,0.6696,0.6392,0.6087,0.5478),
(3007,'XAU','USD',2083.15,2050.3,'2024-03-04','2024-03-04 00:00:00',32.85,1.5769,'2024-03-05 16:00:11','2024-03-05 16:00:11',66.9748,61.3936,58.603,55.8124,50.2311),
(3008,'XAG','USD',23.1,22.72,'2024-03-04','2024-03-04 00:00:00',0.38,1.645,'2024-03-05 16:05:06','2024-03-05 16:05:06',0.7427,0.6808,0.6498,0.6189,0.557),
(3009,'XAU','USD',2126.25,2083.15,'2024-03-05','2024-03-05 00:00:00',43.1,2.027,'2024-03-06 16:00:06','2024-03-06 16:00:06',68.3605,62.6638,59.8155,56.9671,51.2704),
(3010,'XAG','USD',23.93,23.1,'2024-03-05','2024-03-05 00:00:00',0.83,3.4684,'2024-03-06 16:05:06','2024-03-06 16:05:06',0.7694,0.7053,0.6732,0.6411,0.577),
(3011,'XAU','USD',2127.35,2126.25,'2024-03-06','2024-03-06 00:00:00',1.1,0.0517,'2024-03-07 16:00:07','2024-03-07 16:00:07',68.3959,62.6962,59.8464,56.9966,51.2969),
(3012,'XAG','USD',23.795,23.93,'2024-03-06','2024-03-06 00:00:00',-0.135,-0.5673,'2024-03-07 16:05:07','2024-03-07 16:05:07',0.765,0.7013,0.6694,0.6375,0.5738),
(3013,'XAU','USD',2156.85,2127.35,'2024-03-07','2024-03-07 00:00:00',29.5,1.3677,'2024-03-08 16:00:07','2024-03-08 16:00:07',69.3443,63.5656,60.6763,57.7869,52.0083),
(3014,'XAG','USD',24.155,23.795,'2024-03-07','2024-03-07 00:00:00',0.36,1.4904,'2024-03-08 16:05:06','2024-03-08 16:05:06',0.7766,0.7119,0.6795,0.6472,0.5825),
(3015,'XAU','USD',2168.65,2156.85,'2024-03-08','2024-03-08 00:00:00',11.8,0.5441,'2024-03-09 16:00:05','2024-03-09 16:00:05',69.7237,63.9134,61.0083,58.1031,52.2928),
(3016,'XAG','USD',24.495,24.155,'2024-03-08','2024-03-08 00:00:00',0.34,1.388,'2024-03-09 16:05:05','2024-03-09 16:05:05',0.7875,0.7219,0.6891,0.6563,0.5906),
(3017,'XAU','USD',2178.45,2168.65,'2024-03-11','2024-03-11 00:00:00',9.8,0.4499,'2024-03-12 16:00:06','2024-03-12 16:00:06',70.0388,64.2022,61.2839,58.3657,52.5291),
(3018,'XAG','USD',24.355,24.495,'2024-03-11','2024-03-11 00:00:00',-0.14,-0.5748,'2024-03-12 16:05:05','2024-03-12 16:05:05',0.783,0.7178,0.6852,0.6525,0.5873),
(3019,'XAU','USD',2176.4,2178.45,'2024-03-12','2024-03-12 00:00:00',-2.05,-0.0942,'2024-03-13 16:00:06','2024-03-13 16:00:06',69.9729,64.1418,61.2263,58.3107,52.4797),
(3020,'XAG','USD',24.375,24.355,'2024-03-12','2024-03-12 00:00:00',0.02,0.0821,'2024-03-13 16:05:06','2024-03-13 16:05:06',0.7837,0.7184,0.6857,0.6531,0.5878),
(3021,'XAU','USD',2160.85,2176.4,'2024-03-13','2024-03-13 00:00:00',-15.55,-0.7196,'2024-03-14 16:00:08','2024-03-14 16:00:08',69.4729,63.6835,60.7888,57.8941,52.1047),
(3022,'XAG','USD',24.3,24.375,'2024-03-13','2024-03-13 00:00:00',-0.075,-0.3086,'2024-03-14 16:05:06','2024-03-14 16:05:06',0.7813,0.7162,0.6836,0.6511,0.5859),
(3023,'XAU','USD',2169.8,2160.85,'2024-03-14','2024-03-14 00:00:00',8.95,0.4125,'2024-03-15 16:00:07','2024-03-15 16:00:07',69.7607,63.9473,61.0406,58.1339,52.3205),
(3024,'XAG','USD',24.97,24.3,'2024-03-14','2024-03-14 00:00:00',0.67,2.6832,'2024-03-15 16:05:06','2024-03-15 16:05:06',0.8028,0.7359,0.7025,0.669,0.6021),
(3025,'XAU','USD',2170.35,2169.8,'2024-03-15','2024-03-15 00:00:00',0.55,0.0253,'2024-03-16 16:00:05','2024-03-16 16:00:05',69.7784,63.9635,61.0561,58.1486,52.3338),
(3026,'XAG','USD',25.22,24.97,'2024-03-15','2024-03-15 00:00:00',0.25,0.9913,'2024-03-16 16:05:06','2024-03-16 16:05:06',0.8108,0.7433,0.7095,0.6757,0.6081),
(3027,'XAU','USD',2155.3,2170.35,'2024-03-18','2024-03-18 00:00:00',-15.05,-0.6983,'2024-03-19 16:00:12','2024-03-19 16:00:12',69.2945,63.52,60.6327,57.7454,51.9709),
(3028,'XAG','USD',25.175,25.22,'2024-03-18','2024-03-18 00:00:00',-0.045,-0.1787,'2024-03-19 16:05:06','2024-03-19 16:05:06',0.8094,0.7419,0.7082,0.6745,0.607),
(3029,'XAU','USD',2154.3,2155.3,'2024-03-19','2024-03-19 00:00:00',-1,-0.0464,'2024-03-20 16:00:06','2024-03-20 16:00:06',69.2624,63.4905,60.6046,57.7186,51.9468),
(3030,'XAG','USD',24.93,25.175,'2024-03-19','2024-03-19 00:00:00',-0.245,-0.9828,'2024-03-20 16:05:06','2024-03-20 16:05:06',0.8015,0.7347,0.7013,0.6679,0.6011),
(3031,'XAU','USD',2153.4,2154.3,'2024-03-20','2024-03-20 00:00:00',-0.9,-0.0418,'2024-03-21 16:00:06','2024-03-21 16:00:06',69.2334,63.464,60.5792,57.6945,51.9251),
(3032,'XAG','USD',24.855,24.93,'2024-03-20','2024-03-20 00:00:00',-0.075,-0.3018,'2024-03-21 16:05:07','2024-03-21 16:05:07',0.7991,0.7325,0.6992,0.6659,0.5993),
(3033,'XAU','USD',2210.65,2153.4,'2024-03-21','2024-03-21 00:00:00',57.25,2.5897,'2024-03-22 16:00:06','2024-03-22 16:00:06',71.074,65.1512,62.1898,59.2284,53.3055),
(3034,'XAG','USD',25.43,24.855,'2024-03-21','2024-03-21 00:00:00',0.575,2.2611,'2024-03-22 16:05:06','2024-03-22 16:05:06',0.8176,0.7495,0.7154,0.6813,0.6132),
(3035,'XAU','USD',2166.25,2210.65,'2024-03-22','2024-03-22 00:00:00',-44.4,-2.0496,'2024-03-23 16:00:06','2024-03-23 16:00:06',69.6466,63.8427,60.9407,58.0388,52.2349),
(3036,'XAG','USD',24.59,25.43,'2024-03-22','2024-03-22 00:00:00',-0.84,-3.416,'2024-03-23 16:05:06','2024-03-23 16:05:06',0.7906,0.7247,0.6918,0.6588,0.5929),
(3037,'XAU','USD',2168.35,2166.25,'2024-03-25','2024-03-25 00:00:00',2.1,0.0968,'2024-03-26 16:00:19','2024-03-26 16:00:19',69.7141,63.9046,60.9998,58.0951,52.2856),
(3038,'XAG','USD',24.665,24.59,'2024-03-25','2024-03-25 00:00:00',0.075,0.3041,'2024-03-26 16:05:06','2024-03-26 16:05:06',0.793,0.7269,0.6939,0.6608,0.5947),
(3039,'XAU','USD',2193.45,2168.35,'2024-03-26','2024-03-26 00:00:00',25.1,1.1443,'2024-03-27 16:00:07','2024-03-27 16:00:07',70.5211,64.6443,61.7059,58.7675,52.8908),
(3040,'XAG','USD',24.825,24.665,'2024-03-26','2024-03-26 00:00:00',0.16,0.6445,'2024-03-27 16:05:06','2024-03-27 16:05:06',0.7981,0.7316,0.6984,0.6651,0.5986),
(3041,'XAU','USD',2192.05,2193.45,'2024-03-27','2024-03-27 00:00:00',-1.4,-0.0639,'2024-03-28 16:00:06','2024-03-28 16:00:06',70.476,64.603,61.6665,58.73,52.857),
(3042,'XAG','USD',24.515,24.825,'2024-03-27','2024-03-27 00:00:00',-0.31,-1.2645,'2024-03-28 16:05:06','2024-03-28 16:05:06',0.7882,0.7225,0.6897,0.6568,0.5911),
(3043,'XAU','USD',2207,2192.05,'2024-03-28','2024-03-28 00:00:00',14.95,0.6774,'2024-03-29 16:00:06','2024-03-29 16:00:06',70.9567,65.0436,62.0871,59.1306,53.2175),
(3044,'XAG','USD',24.54,24.515,'2024-03-28','2024-03-28 00:00:00',0.025,0.1019,'2024-03-29 16:05:06','2024-03-29 16:05:06',0.789,0.7232,0.6904,0.6575,0.5917),
(3045,'XAU','USD',2207,2207,'2024-03-29','2024-03-29 00:00:00',0,0,'2024-03-30 16:00:05','2024-03-30 16:00:05',70.9567,65.0436,62.0871,59.1306,53.2175),
(3046,'XAG','USD',24.54,24.54,'2024-03-29','2024-03-29 00:00:00',0,0,'2024-03-30 16:05:05','2024-03-30 16:05:05',0.789,0.7232,0.6904,0.6575,0.5917),
(3047,'XAU','USD',2394.8,2331.75,'2024-04-12','2024-04-12 00:00:00',63.05,2.6328,'2024-04-13 16:00:05','2024-04-13 16:00:05',76.9946,70.5784,67.3703,64.1622,57.746),
(3048,'XAG','USD',29.025,28.015,'2024-04-12','2024-04-12 00:00:00',1.01,3.4798,'2024-04-13 16:05:04','2024-04-13 16:05:04',0.9332,0.8554,0.8165,0.7776,0.6999),
(3077,'XAU','USD',2347.15,2394.8,'2024-04-15','2024-04-15 00:00:00',-47.65,-2.0301,'2024-04-16 16:00:09','2024-04-16 16:00:09',75.4626,69.1741,66.0298,62.8855,56.597),
(3078,'XAG','USD',28.44,29.025,'2024-04-15','2024-04-15 00:00:00',-0.585,-2.057,'2024-04-16 16:05:05','2024-04-16 16:05:05',0.9144,0.8382,0.8001,0.762,0.6858),
(3079,'XAU','USD',2369,2347.15,'2024-04-16','2024-04-16 00:00:00',21.85,0.9223,'2024-04-17 16:00:06','2024-04-17 16:00:06',76.1651,69.818,66.6445,63.4709,57.1238),
(3080,'XAG','USD',28.255,28.44,'2024-04-16','2024-04-16 00:00:00',-0.185,-0.6548,'2024-04-17 16:05:05','2024-04-17 16:05:05',0.9084,0.8327,0.7949,0.757,0.6813),
(3081,'XAU','USD',2393.75,2369,'2024-04-17','2024-04-17 00:00:00',24.75,1.0339,'2024-04-18 16:00:07','2024-04-18 16:00:07',76.9608,70.5474,67.3407,64.134,57.7206),
(3082,'XAG','USD',28.47,28.255,'2024-04-17','2024-04-17 00:00:00',0.215,0.7552,'2024-04-18 16:05:06','2024-04-18 16:05:06',0.9153,0.8391,0.8009,0.7628,0.6865),
(3083,'XAU','USD',2379.85,2393.75,'2024-04-18','2024-04-18 00:00:00',-13.9,-0.5841,'2024-04-19 16:00:13','2024-04-19 16:00:13',76.514,70.1378,66.9497,63.7616,57.3855),
(3084,'XAG','USD',28.47,28.47,'2024-04-18','2024-04-18 00:00:00',0,0,'2024-04-19 16:05:07','2024-04-19 16:05:07',0.9153,0.8391,0.8009,0.7628,0.6865),
(3085,'XAU','USD',2381.8,2379.85,'2024-04-19','2024-04-19 00:00:00',1.95,0.0819,'2024-04-20 16:00:04','2024-04-20 16:00:04',76.5766,70.1953,67.0046,63.8139,57.4325),
(3086,'XAG','USD',28.24,28.47,'2024-04-19','2024-04-19 00:00:00',-0.23,-0.8144,'2024-04-20 16:05:04','2024-04-20 16:05:04',0.9079,0.8323,0.7944,0.7566,0.681),
(3087,'XAU','USD',2337.55,2340.9,'2024-05-30','2024-05-30 00:00:00',-3.35,-0.1433,'2024-05-31 16:00:11','2024-05-31 16:00:11',75.154,68.8911,65.7597,62.6283,56.3655),
(3088,'XAG','USD',31.515,32.01,'2024-05-30','2024-05-30 00:00:00',-0.495,-1.5707,'2024-05-31 16:05:16','2024-05-31 16:05:16',1.0132,0.9288,0.8866,0.8444,0.7599),
(3089,'XAU','USD',2342.9,2337.55,'2024-05-31','2024-05-31 00:00:00',5.35,0.2283,'2024-06-01 16:00:04','2024-06-01 16:00:04',75.326,69.0488,65.9102,62.7717,56.4945),
(3090,'XAG','USD',31.265,31.515,'2024-05-31','2024-05-31 00:00:00',-0.25,-0.7996,'2024-06-01 16:05:05','2024-06-01 16:05:05',1.0052,0.9214,0.8795,0.8377,0.7539),
(3091,'XAU','USD',2324.7,2342.9,'2024-06-03','2024-06-03 00:00:00',-18.2,-0.7829,'2024-06-04 16:00:17','2024-06-04 16:00:17',74.7408,68.5124,65.3982,62.284,56.0556),
(3092,'XAG','USD',30.37,31.265,'2024-06-03','2024-06-03 00:00:00',-0.895,-2.947,'2024-06-04 16:05:16','2024-06-04 16:05:16',0.9764,0.895,0.8544,0.8137,0.7323),
(3093,'XAU','USD',2330.5,2324.7,'2024-06-04','2024-06-04 00:00:00',5.8,0.2489,'2024-06-05 16:00:07','2024-06-05 16:00:07',74.9273,68.6834,65.5614,62.4394,56.1955),
(3094,'XAG','USD',29.705,30.37,'2024-06-04','2024-06-04 00:00:00',-0.665,-2.2387,'2024-06-05 16:05:05','2024-06-05 16:05:05',0.955,0.8755,0.8357,0.7959,0.7163),
(3095,'XAU','USD',2332.25,2330.5,'2024-06-05','2024-06-05 00:00:00',1.75,0.075,'2024-06-06 16:00:13','2024-06-06 16:00:13',74.9836,68.7349,65.6106,62.4863,56.2377),
(3096,'XAG','USD',29.61,29.705,'2024-06-05','2024-06-05 00:00:00',-0.095,-0.3208,'2024-06-06 16:05:08','2024-06-06 16:05:08',0.952,0.8727,0.833,0.7933,0.714),
(3097,'XAG','USD',30.295,29.61,'2024-06-06','2024-06-06 00:00:00',0.685,2.2611,'2024-06-07 16:05:06','2024-06-07 16:05:06',0.974,0.8928,0.8523,0.8117,0.7305),
(3098,'XAU','USD',2338,2360.85,'2024-06-07','2024-06-07 00:00:00',-22.85,-0.9773,'2024-06-08 16:00:04','2024-06-08 16:00:04',75.1684,68.9044,65.7724,62.6404,56.3763),
(3099,'XAG','USD',30.265,30.295,'2024-06-07','2024-06-07 00:00:00',-0.03,-0.0991,'2024-06-08 16:05:05','2024-06-08 16:05:05',0.973,0.892,0.8514,0.8109,0.7298),
(3100,'XAU','USD',2297.65,2338,'2024-06-10','2024-06-10 00:00:00',-40.35,-1.7561,'2024-06-11 16:00:32','2024-06-11 16:00:32',73.8712,67.7152,64.6373,61.5593,55.4034),
(3101,'XAG','USD',29.68,30.265,'2024-06-10','2024-06-10 00:00:00',-0.585,-1.971,'2024-06-11 16:05:10','2024-06-11 16:05:10',0.9542,0.8747,0.835,0.7952,0.7157),
(3102,'XAU','USD',2302.5,2297.65,'2024-06-11','2024-06-11 00:00:00',4.85,0.2106,'2024-06-12 16:00:19','2024-06-12 16:00:19',74.0271,67.8582,64.7737,61.6892,55.5203),
(3103,'XAG','USD',29.245,29.68,'2024-06-11','2024-06-11 00:00:00',-0.435,-1.4874,'2024-06-12 16:05:11','2024-06-12 16:05:11',0.9402,0.8619,0.8227,0.7835,0.7052),
(3104,'XAU','USD',2314.9,2302.5,'2024-06-12','2024-06-12 00:00:00',12.4,0.5357,'2024-06-13 16:00:34','2024-06-13 16:00:34',74.4258,68.2236,65.1225,62.0215,55.8193),
(3105,'XAU','USD',2316.35,2314.9,'2024-06-13','2024-06-13 00:00:00',1.45,0.0626,'2024-06-14 16:00:12','2024-06-14 16:00:12',74.4724,68.2663,65.1633,62.0603,55.8543),
(3106,'XAG','USD',29.24,29.38,'2024-06-13','2024-06-13 00:00:00',-0.14,-0.4788,'2024-06-14 16:05:15','2024-06-14 16:05:15',0.9401,0.8617,0.8226,0.7834,0.7051),
(3107,'XAU','USD',2316.9,2316.35,'2024-06-14','2024-06-14 00:00:00',0.55,0.0237,'2024-06-15 16:00:05','2024-06-15 16:00:05',74.4901,68.2826,65.1788,62.0751,55.8675),
(3108,'XAG','USD',29.21,29.24,'2024-06-14','2024-06-14 00:00:00',-0.03,-0.1027,'2024-06-15 16:05:04','2024-06-15 16:05:04',0.9391,0.8609,0.8217,0.7826,0.7043),
(3109,'XAU','USD',2327.6,2310.55,'2024-06-28','2024-06-28 00:00:00',17.05,0.7325,'2024-06-29 16:00:05','2024-06-29 16:00:05',74.8341,68.5979,65.4798,62.3617,56.1256),
(3110,'XAG','USD',29.37,28.87,'2024-06-28','2024-06-28 00:00:00',0.5,1.7024,'2024-06-29 16:05:04','2024-06-29 16:05:04',0.9443,0.8656,0.8262,0.7869,0.7082),
(3111,'XAU','USD',2434,2419.6,'2024-08-01','2024-08-17 04:21:18',14.4,0.5916,'2024-08-17 04:21:18','2024-08-17 04:21:18',78.2549,71.7337,68.4731,65.2124,58.6912),
(3114,'XAU','USD',2327.8,2327.6,'2024-07-01','2024-07-01 16:30:00',0.2,0.0086,'2024-09-14 00:22:32','2024-09-14 00:22:32',74.8405,68.6038,65.4854,62.3671,56.1304),
(3115,'XAU','USD',2329,2327.8,'2024-07-02','2024-07-02 16:30:00',1.2,0.0515,'2024-09-14 00:22:32','2024-09-14 00:22:32',74.8791,68.6392,65.5192,62.3992,56.1593),
(3116,'XAU','USD',2342.55,2329,'2024-07-03','2024-07-03 16:30:00',13.55,0.5784,'2024-09-14 00:22:32','2024-09-14 00:22:32',75.3147,69.0385,65.9004,62.7623,56.486),
(3117,'XAU','USD',2365.35,2357.2,'2024-07-05','2024-07-05 16:30:00',8.15,0.3446,'2024-09-14 00:22:32','2024-09-14 00:22:32',76.0478,69.7105,66.5418,63.3731,57.0358),
(3118,'XAU','USD',2371.65,2365.35,'2024-07-08','2024-07-08 16:30:00',6.3,0.2656,'2024-09-14 00:22:33','2024-09-14 00:22:33',76.2503,69.8961,66.719,63.5419,57.1877),
(3119,'XAU','USD',2362.4,2371.65,'2024-07-09','2024-07-09 16:30:00',-9.25,-0.3916,'2024-09-14 00:22:33','2024-09-14 00:22:33',75.9529,69.6235,66.4588,63.2941,56.9647),
(3120,'XAU','USD',2372.9,2362.4,'2024-07-10','2024-07-10 16:30:00',10.5,0.4425,'2024-09-14 00:22:33','2024-09-14 00:22:33',76.2905,69.933,66.7542,63.5754,57.2179),
(3121,'XAU','USD',2383.55,2372.9,'2024-07-11','2024-07-11 16:30:00',10.65,0.4468,'2024-09-14 00:22:33','2024-09-14 00:22:33',76.6329,70.2468,67.0538,63.8608,57.4747),
(3122,'XAU','USD',2404.15,2383.55,'2024-07-12','2024-07-12 16:30:00',20.6,0.8569,'2024-09-14 00:22:34','2024-09-14 00:22:34',77.2952,70.8539,67.6333,64.4127,57.9714),
(3123,'XAU','USD',2408.5,2404.15,'2024-07-15','2024-07-15 16:30:00',4.35,0.1806,'2024-09-14 00:22:34','2024-09-14 00:22:34',77.4351,70.9822,67.7557,64.5292,58.0763),
(3124,'XAU','USD',2439.35,2408.5,'2024-07-16','2024-07-16 16:30:00',30.85,1.2647,'2024-09-14 00:22:34','2024-09-14 00:22:34',78.4269,71.8913,68.6236,65.3558,58.8202),
(3125,'XAU','USD',2470.35,2439.35,'2024-07-17','2024-07-17 16:30:00',31,1.2549,'2024-09-14 00:22:34','2024-09-14 00:22:34',79.4236,72.805,69.4956,66.1863,59.5677),
(3126,'XAU','USD',2466.95,2470.35,'2024-07-18','2024-07-18 16:30:00',-3.4,-0.1378,'2024-09-14 00:22:34','2024-09-14 00:22:34',79.3143,72.7048,69.4,66.0952,59.4857),
(3127,'XAU','USD',2415.8,2466.95,'2024-07-19','2024-07-19 16:30:00',-51.15,-2.1173,'2024-09-14 00:22:35','2024-09-14 00:22:35',77.6698,71.1973,67.9611,64.7248,58.2523),
(3128,'XAU','USD',2401.4,2415.8,'2024-07-22','2024-07-22 16:30:00',-14.4,-0.5997,'2024-09-14 00:22:35','2024-09-14 00:22:35',77.2068,70.7729,67.556,64.339,57.9051),
(3129,'XAU','USD',2404.45,2401.4,'2024-07-23','2024-07-23 16:30:00',3.05,0.1268,'2024-09-14 00:22:35','2024-09-14 00:22:35',77.3049,70.8628,67.6418,64.4207,57.9786),
(3130,'XAU','USD',2411.3,2404.45,'2024-07-24','2024-07-24 16:30:00',6.85,0.2841,'2024-09-14 00:22:35','2024-09-14 00:22:35',77.5251,71.0647,67.8345,64.6042,58.1438),
(3131,'XAU','USD',2371.25,2411.3,'2024-07-25','2024-07-25 16:30:00',-40.05,-1.689,'2024-09-14 00:22:36','2024-09-14 00:22:36',76.2375,69.8843,66.7078,63.5312,57.1781),
(3132,'XAU','USD',2374.55,2371.25,'2024-07-26','2024-07-26 16:30:00',3.3,0.139,'2024-09-14 00:22:36','2024-09-14 00:22:36',76.3436,69.9816,66.8006,63.6196,57.2577),
(3133,'XAU','USD',2392.1,2374.55,'2024-07-29','2024-07-29 16:30:00',17.55,0.7337,'2024-09-14 00:22:36','2024-09-14 00:22:36',76.9078,70.4988,67.2943,64.0898,57.6809),
(3134,'XAU','USD',2389.15,2392.1,'2024-07-30','2024-07-30 16:30:00',-2.95,-0.1235,'2024-09-14 00:22:36','2024-09-14 00:22:36',76.813,70.4119,67.2113,64.0108,57.6097),
(3135,'XAU','USD',2419.6,2389.15,'2024-07-31','2024-07-31 16:30:00',30.45,1.2585,'2024-09-14 00:22:37','2024-09-14 00:22:37',77.7919,71.3093,68.068,64.8266,58.344),
(3137,'XAU','USD',2461.75,2434,'2024-08-02','2024-08-02 16:30:00',27.75,1.1272,'2024-09-14 00:22:37','2024-09-14 00:22:37',79.1471,72.5515,69.2537,65.9559,59.3603),
(3138,'XAU','USD',2421.75,2461.75,'2024-08-05','2024-08-05 16:30:00',-40,-1.6517,'2024-09-14 00:22:37','2024-09-14 00:22:37',77.8611,71.3726,68.1284,64.8842,58.3958),
(3139,'XAU','USD',2414.15,2421.75,'2024-08-06','2024-08-06 16:30:00',-7.6,-0.3148,'2024-09-14 00:22:37','2024-09-14 00:22:37',77.6167,71.1487,67.9146,64.6806,58.2125),
(3140,'XAU','USD',2392.85,2414.15,'2024-08-07','2024-08-07 16:30:00',-21.3,-0.8902,'2024-09-14 00:22:38','2024-09-14 00:22:38',76.9319,70.5209,67.3154,64.1099,57.6989),
(3141,'XAU','USD',2396.3,2392.85,'2024-08-08','2024-08-08 16:30:00',3.45,0.144,'2024-09-14 00:22:38','2024-09-14 00:22:38',77.0428,70.6226,67.4125,64.2024,57.7821),
(3142,'XAU','USD',2396.3,2396.3,'2024-08-09','2024-08-09 16:30:00',0,0,'2024-09-14 00:22:38','2024-09-14 00:22:38',77.0428,70.6226,67.4125,64.2024,57.7821),
(3143,'XAU','USD',2442.1,2396.3,'2024-08-12','2024-08-12 16:30:00',45.8,1.8754,'2024-09-14 00:22:38','2024-09-14 00:22:38',78.5153,71.9724,68.7009,65.4294,58.8865),
(3144,'XAU','USD',2460.55,2442.1,'2024-08-13','2024-08-13 16:30:00',18.45,0.7498,'2024-09-14 00:22:39','2024-09-14 00:22:39',79.1085,72.5161,69.22,65.9238,59.3314),
(3178,'XAG','USD',29.245,29.37,'2024-07-01','2024-07-01 16:30:00',-0.125,-0.4274,'2024-09-14 00:22:47','2024-09-14 00:22:47',0.9402,0.8619,0.8227,0.7835,0.7052),
(3179,'XAG','USD',29.31,29.245,'2024-07-02','2024-07-02 16:30:00',0.065,0.2218,'2024-09-14 00:22:47','2024-09-14 00:22:47',0.9423,0.8638,0.8245,0.7853,0.7068),
(3180,'XAG','USD',30.13,29.31,'2024-07-03','2024-07-03 16:30:00',0.82,2.7215,'2024-09-14 00:22:47','2024-09-14 00:22:47',0.9687,0.888,0.8476,0.8073,0.7265),
(3181,'XAG','USD',30.58,30.335,'2024-07-05','2024-07-05 16:30:00',0.245,0.8012,'2024-09-14 00:22:47','2024-09-14 00:22:47',0.9832,0.9012,0.8603,0.8193,0.7374),
(3182,'XAG','USD',30.99,30.58,'2024-07-08','2024-07-08 16:30:00',0.41,1.323,'2024-09-14 00:22:47','2024-09-14 00:22:47',0.9964,0.9133,0.8718,0.8303,0.7473),
(3183,'XAG','USD',31.055,30.99,'2024-07-09','2024-07-09 16:30:00',0.065,0.2093,'2024-09-14 00:22:48','2024-09-14 00:22:48',0.9984,0.9152,0.8736,0.832,0.7488),
(3184,'XAG','USD',30.935,31.055,'2024-07-10','2024-07-10 16:30:00',-0.12,-0.3879,'2024-09-14 00:22:48','2024-09-14 00:22:48',0.9946,0.9117,0.8703,0.8288,0.7459),
(3185,'XAG','USD',31.015,30.935,'2024-07-11','2024-07-11 16:30:00',0.08,0.2579,'2024-09-14 00:22:48','2024-09-14 00:22:48',0.9972,0.9141,0.8725,0.831,0.7479),
(3186,'XAG','USD',30.72,31.015,'2024-07-12','2024-07-12 16:30:00',-0.295,-0.9603,'2024-09-14 00:22:48','2024-09-14 00:22:48',0.9877,0.9054,0.8642,0.8231,0.7408),
(3187,'XAG','USD',30.74,30.72,'2024-07-15','2024-07-15 16:30:00',0.02,0.0651,'2024-09-14 00:22:49','2024-09-14 00:22:49',0.9883,0.906,0.8648,0.8236,0.7412),
(3188,'XAG','USD',30.865,30.74,'2024-07-16','2024-07-16 16:30:00',0.125,0.405,'2024-09-14 00:22:49','2024-09-14 00:22:49',0.9923,0.9096,0.8683,0.8269,0.7442),
(3189,'XAG','USD',30.915,30.865,'2024-07-17','2024-07-17 16:30:00',0.05,0.1617,'2024-09-14 00:22:49','2024-09-14 00:22:49',0.9939,0.9111,0.8697,0.8283,0.7455),
(3190,'XAG','USD',30.47,30.915,'2024-07-18','2024-07-18 16:30:00',-0.445,-1.4605,'2024-09-14 00:22:49','2024-09-14 00:22:49',0.9796,0.898,0.8572,0.8164,0.7347),
(3191,'XAG','USD',29.105,30.47,'2024-07-19','2024-07-19 16:30:00',-1.365,-4.6899,'2024-09-14 00:22:50','2024-09-14 00:22:50',0.9357,0.8578,0.8188,0.7798,0.7018),
(3192,'XAG','USD',29.065,29.105,'2024-07-22','2024-07-22 16:30:00',-0.04,-0.1376,'2024-09-14 00:22:50','2024-09-14 00:22:50',0.9345,0.8566,0.8177,0.7787,0.7008),
(3193,'XAG','USD',29.055,29.065,'2024-07-23','2024-07-23 16:30:00',-0.01,-0.0344,'2024-09-14 00:22:50','2024-09-14 00:22:50',0.9341,0.8563,0.8174,0.7784,0.7006),
(3194,'XAG','USD',29.29,29.055,'2024-07-24','2024-07-24 16:30:00',0.235,0.8023,'2024-09-14 00:22:50','2024-09-14 00:22:50',0.9417,0.8632,0.824,0.7847,0.7063),
(3195,'XAG','USD',27.99,29.29,'2024-07-25','2024-07-25 16:30:00',-1.3,-4.6445,'2024-09-14 00:22:51','2024-09-14 00:22:51',0.8999,0.8249,0.7874,0.7499,0.6749),
(3196,'XAG','USD',27.755,27.99,'2024-07-26','2024-07-26 16:30:00',-0.235,-0.8467,'2024-09-14 00:22:51','2024-09-14 00:22:51',0.8923,0.818,0.7808,0.7436,0.6693),
(3197,'XAG','USD',28.14,27.755,'2024-07-29','2024-07-29 16:30:00',0.385,1.3682,'2024-09-14 00:22:51','2024-09-14 00:22:51',0.9047,0.8293,0.7916,0.7539,0.6785),
(3198,'XAG','USD',27.88,28.14,'2024-07-30','2024-07-30 16:30:00',-0.26,-0.9326,'2024-09-14 00:22:51','2024-09-14 00:22:51',0.8964,0.8217,0.7843,0.747,0.6723),
(3199,'XAG','USD',28.56,27.88,'2024-07-31','2024-07-31 16:30:00',0.68,2.381,'2024-09-14 00:22:52','2024-09-14 00:22:52',0.9182,0.8417,0.8034,0.7652,0.6887),
(3200,'XAG','USD',28.88,28.56,'2024-08-01','2024-08-01 16:30:00',0.32,1.108,'2024-09-14 00:22:52','2024-09-14 00:22:52',0.9285,0.8511,0.8124,0.7738,0.6964),
(3201,'XAG','USD',28.95,28.88,'2024-08-02','2024-08-02 16:30:00',0.07,0.2418,'2024-09-14 00:22:52','2024-09-14 00:22:52',0.9308,0.8532,0.8144,0.7756,0.6981),
(3202,'XAG','USD',27.105,28.95,'2024-08-05','2024-08-05 16:30:00',-1.845,-6.8069,'2024-09-14 00:22:52','2024-09-14 00:22:52',0.8714,0.7988,0.7625,0.7262,0.6536),
(3203,'XAG','USD',27.065,27.105,'2024-08-06','2024-08-06 16:30:00',-0.04,-0.1478,'2024-09-14 00:22:53','2024-09-14 00:22:53',0.8702,0.7976,0.7614,0.7251,0.6526),
(3204,'XAG','USD',27.15,27.065,'2024-08-07','2024-08-07 16:30:00',0.085,0.3131,'2024-09-14 00:22:53','2024-09-14 00:22:53',0.8729,0.8002,0.7638,0.7274,0.6547),
(3205,'XAG','USD',26.93,27.15,'2024-08-08','2024-08-08 16:30:00',-0.22,-0.8169,'2024-09-14 00:22:53','2024-09-14 00:22:53',0.8658,0.7937,0.7576,0.7215,0.6494),
(3206,'XAG','USD',26.93,26.93,'2024-08-09','2024-08-09 16:30:00',0,0,'2024-09-14 00:22:53','2024-09-14 00:22:53',0.8658,0.7937,0.7576,0.7215,0.6494),
(3207,'XAG','USD',27.965,26.93,'2024-08-12','2024-08-12 16:30:00',1.035,3.7011,'2024-09-14 00:22:54','2024-09-14 00:22:54',0.8991,0.8242,0.7867,0.7492,0.6743),
(3208,'XAG','USD',27.695,27.965,'2024-08-13','2024-08-13 16:30:00',-0.27,-0.9749,'2024-09-14 00:22:54','2024-09-14 00:22:54',0.8904,0.8162,0.7791,0.742,0.6678),
(3241,'XAU','USD',2587.45,2571.35,'2024-09-16','2024-09-16 16:30:00',16.1,0.6222,'2024-09-22 23:41:39','2024-09-22 23:41:39',83.1884,76.2561,72.7899,69.3237,62.3913),
(3242,'XAU','USD',2575.5,2587.45,'2024-09-17','2024-09-17 16:30:00',-11.95,-0.464,'2024-09-22 23:41:39','2024-09-22 23:41:39',82.8042,75.9039,72.4537,69.0035,62.1032),
(3243,'XAU','USD',2568.35,2575.5,'2024-09-18','2024-09-18 16:30:00',-7.15,-0.2784,'2024-09-22 23:41:39','2024-09-22 23:41:39',82.5744,75.6932,72.2526,68.812,61.9308),
(3244,'XAU','USD',2590.6,2568.35,'2024-09-19','2024-09-19 16:30:00',22.25,0.8589,'2024-09-22 23:41:39','2024-09-22 23:41:39',83.2897,76.3489,72.8785,69.4081,62.4673),
(3245,'XAU','USD',2606.45,2590.6,'2024-09-20','2024-09-20 16:30:00',15.85,0.6081,'2024-09-22 23:41:39','2024-09-22 23:41:39',83.7993,76.816,73.3244,69.8328,62.8495),
(3246,'XAG','USD',30.91,29.965,'2024-09-16','2024-09-16 16:30:00',0.945,3.0573,'2024-09-22 23:42:13','2024-09-22 23:42:13',0.9938,0.911,0.8696,0.8281,0.7453),
(3247,'XAG','USD',30.68,30.91,'2024-09-17','2024-09-17 16:30:00',-0.23,-0.7497,'2024-09-22 23:42:13','2024-09-22 23:42:13',0.9864,0.9042,0.8631,0.822,0.7398),
(3248,'XAG','USD',30.59,30.68,'2024-09-18','2024-09-18 16:30:00',-0.09,-0.2942,'2024-09-22 23:42:13','2024-09-22 23:42:13',0.9835,0.9015,0.8606,0.8196,0.7376),
(3249,'XAG','USD',31.16,30.59,'2024-09-19','2024-09-19 16:30:00',0.57,1.8293,'2024-09-22 23:42:13','2024-09-22 23:42:13',1.0018,0.9183,0.8766,0.8348,0.7514),
(3250,'XAG','USD',31.315,31.16,'2024-09-20','2024-09-20 16:30:00',0.155,0.495,'2024-09-22 23:42:13','2024-09-22 23:42:13',1.0068,0.9229,0.881,0.839,0.7551),
(3251,'XAU','USD',2472,2460.55,'2024-08-14','2024-08-14 16:30:00',11.45,0.4632,'2024-09-23 02:00:50','2024-09-23 02:00:50',79.4766,72.8536,69.5421,66.2305,59.6075),
(3252,'XAU','USD',2456.25,2472,'2024-08-15','2024-08-15 16:30:00',-15.75,-0.6412,'2024-09-23 02:00:50','2024-09-23 02:00:50',78.9703,72.3894,69.099,65.8086,59.2277),
(3253,'XAU','USD',2462.15,2456.25,'2024-08-16','2024-08-16 16:30:00',5.9,0.2396,'2024-09-23 02:00:50','2024-09-23 02:00:50',79.16,72.5633,69.265,65.9666,59.37),
(3254,'XAU','USD',2500.05,2462.15,'2024-08-19','2024-08-19 16:30:00',37.9,1.516,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.3785,73.6803,70.3312,66.9821,60.2839),
(3255,'XAU','USD',2521.55,2500.05,'2024-08-20','2024-08-20 16:30:00',21.5,0.8527,'2024-09-23 02:00:50','2024-09-23 02:00:50',81.0697,74.3139,70.936,67.5581,60.8023),
(3256,'XAU','USD',2507.65,2521.55,'2024-08-21','2024-08-21 16:30:00',-13.9,-0.5543,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.6228,73.9043,70.545,67.1857,60.4671),
(3257,'XAU','USD',2505.1,2507.65,'2024-08-22','2024-08-22 16:30:00',-2.55,-0.1018,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.5408,73.8291,70.4732,67.1174,60.4056),
(3258,'XAU','USD',2500.3,2505.1,'2024-08-23','2024-08-23 16:30:00',-4.8,-0.192,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.3865,73.6876,70.3382,66.9888,60.2899),
(3259,'XAU','USD',2500.3,2500.3,'2024-08-26','2024-08-26 16:30:00',0,0,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.3865,73.6876,70.3382,66.9888,60.2899),
(3260,'XAU','USD',2510.3,2500.3,'2024-08-27','2024-08-27 16:30:00',10,0.3984,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.708,73.9824,70.6195,67.2567,60.531),
(3261,'XAU','USD',2509.55,2510.3,'2024-08-28','2024-08-28 16:30:00',-0.75,-0.0299,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.6839,73.9602,70.5984,67.2366,60.5129),
(3262,'XAU','USD',2517.05,2509.55,'2024-08-29','2024-08-29 16:30:00',7.5,0.298,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.925,74.1813,70.8094,67.4375,60.6938),
(3263,'XAU','USD',2524.15,2517.05,'2024-08-30','2024-08-30 16:30:00',7.1,0.2813,'2024-09-23 02:00:50','2024-09-23 02:00:50',81.1533,74.3905,71.0091,67.6278,60.865),
(3264,'XAU','USD',2503.25,2502,'2024-09-03','2024-09-03 16:30:00',1.25,0.0499,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.4814,73.7746,70.4212,67.0678,60.361),
(3265,'XAU','USD',2474.45,2503.25,'2024-09-04','2024-09-04 16:30:00',-28.8,-1.1639,'2024-09-23 02:00:50','2024-09-23 02:00:50',79.5554,72.9258,69.611,66.2962,59.6666),
(3266,'XAU','USD',2516.85,2474.45,'2024-09-05','2024-09-05 16:30:00',42.4,1.6846,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.9186,74.1754,70.8038,67.4322,60.689),
(3267,'XAU','USD',2517.7,2516.85,'2024-09-06','2024-09-06 16:30:00',0.85,0.0338,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.9459,74.2004,70.8277,67.4549,60.7095),
(3268,'XAU','USD',2496.65,2517.7,'2024-09-09','2024-09-09 16:30:00',-21.05,-0.8431,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.2692,73.5801,70.2355,66.891,60.2019),
(3269,'XAU','USD',2502.35,2496.65,'2024-09-10','2024-09-10 16:30:00',5.7,0.2278,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.4524,73.7481,70.3959,67.0437,60.3393),
(3270,'XAU','USD',2521.9,2502.35,'2024-09-11','2024-09-11 16:30:00',19.55,0.7752,'2024-09-23 02:00:50','2024-09-23 02:00:50',81.081,74.3242,70.9458,67.5675,60.8107),
(3271,'XAU','USD',2516.55,2521.9,'2024-09-12','2024-09-12 16:30:00',-5.35,-0.2126,'2024-09-23 02:00:50','2024-09-23 02:00:50',80.909,74.1665,70.7953,67.4241,60.6817),
(3272,'XAU','USD',2571.35,2516.55,'2024-09-13','2024-09-13 16:30:00',54.8,2.1312,'2024-09-23 02:00:50','2024-09-23 02:00:50',82.6708,75.7816,72.337,68.8924,62.0031),
(3273,'XAG','USD',27.945,27.695,'2024-08-14','2024-08-14 16:30:00',0.25,0.8946,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.8985,0.8236,0.7861,0.7487,0.6738),
(3274,'XAG','USD',28.05,27.945,'2024-08-15','2024-08-15 16:30:00',0.105,0.3743,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9018,0.8267,0.7891,0.7515,0.6764),
(3275,'XAG','USD',28.135,28.05,'2024-08-16','2024-08-16 16:30:00',0.085,0.3021,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9046,0.8292,0.7915,0.7538,0.6784),
(3276,'XAG','USD',28.83,28.135,'2024-08-19','2024-08-19 16:30:00',0.695,2.4107,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9269,0.8497,0.811,0.7724,0.6952),
(3277,'XAG','USD',29.77,28.83,'2024-08-20','2024-08-20 16:30:00',0.94,3.1575,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9571,0.8774,0.8375,0.7976,0.7178),
(3278,'XAG','USD',29.56,29.77,'2024-08-21','2024-08-21 16:30:00',-0.21,-0.7104,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9504,0.8712,0.8316,0.792,0.7128),
(3279,'XAG','USD',29.565,29.56,'2024-08-22','2024-08-22 16:30:00',0.005,0.0169,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9505,0.8713,0.8317,0.7921,0.7129),
(3280,'XAG','USD',29.435,29.565,'2024-08-23','2024-08-23 16:30:00',-0.13,-0.4417,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9464,0.8675,0.8281,0.7886,0.7098),
(3281,'XAG','USD',29.435,29.435,'2024-08-26','2024-08-26 16:30:00',0,0,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9464,0.8675,0.8281,0.7886,0.7098),
(3282,'XAG','USD',29.9,29.435,'2024-08-27','2024-08-27 16:30:00',0.465,1.5552,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9613,0.8812,0.8411,0.8011,0.721),
(3283,'XAG','USD',29.435,29.9,'2024-08-28','2024-08-28 16:30:00',-0.465,-1.5798,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9464,0.8675,0.8281,0.7886,0.7098),
(3284,'XAG','USD',29.49,29.435,'2024-08-29','2024-08-29 16:30:00',0.055,0.1865,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9481,0.8691,0.8296,0.7901,0.7111),
(3285,'XAG','USD',29.47,29.49,'2024-08-30','2024-08-30 16:30:00',-0.02,-0.0679,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9475,0.8685,0.829,0.7896,0.7106),
(3286,'XAG','USD',28.315,28.62,'2024-09-03','2024-09-03 16:30:00',-0.305,-1.0772,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9103,0.8345,0.7966,0.7586,0.6828),
(3287,'XAG','USD',28.08,28.315,'2024-09-04','2024-09-04 16:30:00',-0.235,-0.8369,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9028,0.8276,0.7899,0.7523,0.6771),
(3288,'XAG','USD',28.72,28.08,'2024-09-05','2024-09-05 16:30:00',0.64,2.2284,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9234,0.8464,0.8079,0.7695,0.6925),
(3289,'XAG','USD',28.84,28.72,'2024-09-06','2024-09-06 16:30:00',0.12,0.4161,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9272,0.85,0.8113,0.7727,0.6954),
(3290,'XAG','USD',28.13,28.84,'2024-09-09','2024-09-09 16:30:00',-0.71,-2.524,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9044,0.829,0.7914,0.7537,0.6783),
(3291,'XAG','USD',28.435,28.13,'2024-09-10','2024-09-10 16:30:00',0.305,1.0726,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9142,0.838,0.7999,0.7618,0.6857),
(3292,'XAG','USD',28.82,28.435,'2024-09-11','2024-09-11 16:30:00',0.385,1.3359,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9266,0.8494,0.8108,0.7722,0.6949),
(3293,'XAG','USD',28.765,28.82,'2024-09-12','2024-09-12 16:30:00',-0.055,-0.1912,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9248,0.8477,0.8092,0.7707,0.6936),
(3294,'XAG','USD',29.965,28.765,'2024-09-13','2024-09-13 16:30:00',1.2,4.0047,'2024-09-23 02:02:03','2024-09-23 02:02:03',0.9634,0.8831,0.843,0.8028,0.7225),
(3309,'XAU','USD',2360.85,2332.25,'2024-06-06','2024-06-06 16:30:00',28.6,1.2114,'2024-09-23 02:10:02','2024-09-23 02:10:02',75.9031,69.5778,66.4152,63.2526,56.9273),
(3310,'XAG','USD',29.38,29.245,'2024-06-12','2024-06-12 16:30:00',0.135,0.4595,'2024-09-23 02:10:54','2024-09-23 02:10:54',0.9446,0.8659,0.8265,0.7872,0.7084),
(3311,'XAG','USD',29.235,29.21,'2024-06-17','2024-06-17 16:30:00',0.025,0.0855,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9399,0.8616,0.8224,0.7833,0.7049),
(3312,'XAG','USD',29.13,29.235,'2024-06-18','2024-06-18 16:30:00',-0.105,-0.3605,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9366,0.8585,0.8195,0.7805,0.7024),
(3313,'XAG','USD',30.23,29.475,'2024-06-20','2024-06-20 16:30:00',0.755,2.4975,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9719,0.8909,0.8504,0.8099,0.7289),
(3314,'XAG','USD',30.435,30.23,'2024-06-21','2024-06-21 16:30:00',0.205,0.6736,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9785,0.897,0.8562,0.8154,0.7339),
(3315,'XAG','USD',29.56,30.435,'2024-06-24','2024-06-24 16:30:00',-0.875,-2.9601,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9504,0.8712,0.8316,0.792,0.7128),
(3316,'XAG','USD',29.56,29.56,'2024-06-25','2024-06-25 16:30:00',0,0,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9504,0.8712,0.8316,0.792,0.7128),
(3317,'XAG','USD',28.835,29.56,'2024-06-26','2024-06-26 16:30:00',-0.725,-2.5143,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9271,0.8498,0.8112,0.7726,0.6953),
(3318,'XAG','USD',28.87,28.835,'2024-06-27','2024-06-27 16:30:00',0.035,0.1212,'2024-09-23 02:12:17','2024-09-23 02:12:17',0.9282,0.8508,0.8122,0.7735,0.6961),
(3320,'XAU','USD',2320.7,2316.9,'2024-06-17','2024-06-17 16:30:00',3.8,0.1637,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.6122,68.3946,65.2857,62.1769,55.9592),
(3321,'XAU','USD',2312.05,2320.7,'2024-06-18','2024-06-18 16:30:00',-8.65,-0.3741,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.3341,68.1396,65.0424,61.9451,55.7506),
(3322,'XAU','USD',2332.95,2328.6,'2024-06-20','2024-06-20 16:30:00',4.35,0.1865,'2024-09-23 02:12:54','2024-09-23 02:12:54',75.0061,68.7556,65.6303,62.5051,56.2546),
(3323,'XAU','USD',2364,2332.95,'2024-06-21','2024-06-21 16:30:00',31.05,1.3135,'2024-09-23 02:12:54','2024-09-23 02:12:54',76.0044,69.6707,66.5038,63.337,57.0033),
(3324,'XAU','USD',2327.2,2364,'2024-06-24','2024-06-24 16:30:00',-36.8,-1.5813,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.8212,68.5861,65.4686,62.351,56.1159),
(3325,'XAU','USD',2332.4,2327.2,'2024-06-25','2024-06-25 16:30:00',5.2,0.2229,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.9884,68.7394,65.6149,62.4903,56.2413),
(3326,'XAU','USD',2316.1,2332.4,'2024-06-26','2024-06-26 16:30:00',-16.3,-0.7038,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.4643,68.259,65.1563,62.0536,55.8483),
(3327,'XAU','USD',2310.55,2316.1,'2024-06-27','2024-06-27 16:30:00',-5.55,-0.2402,'2024-09-23 02:12:54','2024-09-23 02:12:54',74.2859,68.0954,65.0002,61.9049,55.7144),
(3329,'XAU','USD',2288.5,2314.8,'2024-05-01','2024-05-01 16:30:00',-26.3,-1.1492,'2024-09-23 02:14:41','2024-09-23 02:14:41',73.577,67.4456,64.3799,61.3142,55.1827),
(3330,'XAU','USD',2300.55,2288.5,'2024-05-02','2024-05-02 16:30:00',12.05,0.5238,'2024-09-23 02:14:41','2024-09-23 02:14:41',73.9644,67.8007,64.7189,61.637,55.4733),
(3331,'XAU','USD',2301.1,2300.55,'2024-05-03','2024-05-03 16:30:00',0.55,0.0239,'2024-09-23 02:14:41','2024-09-23 02:14:41',73.9821,67.8169,64.7343,61.6517,55.4866),
(3332,'XAU','USD',2301.1,2301.1,'2024-05-06','2024-05-06 16:30:00',0,0,'2024-09-23 02:14:41','2024-09-23 02:14:41',73.9821,67.8169,64.7343,61.6517,55.4866),
(3333,'XAU','USD',2315,2301.1,'2024-05-07','2024-05-07 16:30:00',13.9,0.6004,'2024-09-23 02:14:41','2024-09-23 02:14:41',74.429,68.2266,65.1254,62.0241,55.8217),
(3334,'XAU','USD',2308.55,2315,'2024-05-08','2024-05-08 16:30:00',-6.45,-0.2794,'2024-09-23 02:14:41','2024-09-23 02:14:41',74.2216,68.0365,64.9439,61.8513,55.6662),
(3335,'XAU','USD',2308.7,2308.55,'2024-05-09','2024-05-09 16:30:00',0.15,0.0065,'2024-09-23 02:14:41','2024-09-23 02:14:41',74.2264,68.0409,64.9481,61.8554,55.6698),
(3336,'XAU','USD',2371.05,2308.7,'2024-05-10','2024-05-10 16:30:00',62.35,2.6296,'2024-09-23 02:14:41','2024-09-23 02:14:41',76.231,69.8784,66.7021,63.5259,57.1733),
(3337,'XAU','USD',2340.3,2371.05,'2024-05-13','2024-05-13 16:30:00',-30.75,-1.3139,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.2424,68.9722,65.8371,62.702,56.4318),
(3338,'XAU','USD',2347.4,2340.3,'2024-05-14','2024-05-14 16:30:00',7.1,0.3025,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.4707,69.1814,66.0368,62.8922,56.603),
(3339,'XAU','USD',2371.8,2347.4,'2024-05-15','2024-05-15 16:30:00',24.4,1.0288,'2024-09-23 02:14:41','2024-09-23 02:14:41',76.2551,69.9005,66.7232,63.546,57.1914),
(3340,'XAU','USD',2383.65,2371.8,'2024-05-16','2024-05-16 16:30:00',11.85,0.4971,'2024-09-23 02:14:41','2024-09-23 02:14:41',76.6361,70.2498,67.0566,63.8634,57.4771),
(3341,'XAU','USD',2381.75,2383.65,'2024-05-17','2024-05-17 16:30:00',-1.9,-0.0798,'2024-09-23 02:14:41','2024-09-23 02:14:41',76.575,70.1938,67.0032,63.8125,57.4313),
(3342,'XAU','USD',2444.35,2381.75,'2024-05-20','2024-05-20 16:30:00',62.6,2.561,'2024-09-23 02:14:41','2024-09-23 02:14:41',78.5877,72.0387,68.7642,65.4897,58.9408),
(3343,'XAU','USD',2417.05,2444.35,'2024-05-21','2024-05-21 16:30:00',-27.3,-1.1295,'2024-09-23 02:14:41','2024-09-23 02:14:41',77.71,71.2341,67.9962,64.7583,58.2825),
(3344,'XAU','USD',2414.25,2417.05,'2024-05-22','2024-05-22 16:30:00',-2.8,-0.116,'2024-09-23 02:14:41','2024-09-23 02:14:41',77.6199,71.1516,67.9174,64.6833,58.215),
(3345,'XAU','USD',2361.8,2414.25,'2024-05-23','2024-05-23 16:30:00',-52.45,-2.2208,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.9336,69.6058,66.4419,63.278,56.9502),
(3346,'XAU','USD',2339.75,2361.8,'2024-05-24','2024-05-24 16:30:00',-22.05,-0.9424,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.2247,68.956,65.8216,62.6873,56.4185),
(3347,'XAU','USD',2344.7,2339.75,'2024-05-28','2024-05-28 16:30:00',4.95,0.2111,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.3839,69.1019,65.9609,62.8199,56.5379),
(3348,'XAU','USD',2340.9,2344.7,'2024-05-29','2024-05-29 16:30:00',-3.8,-0.1623,'2024-09-23 02:14:41','2024-09-23 02:14:41',75.2617,68.9899,65.854,62.7181,56.4463),
(3349,'XAG','USD',26.48,26.655,'2024-05-01','2024-05-01 16:30:00',-0.175,-0.6609,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.8514,0.7804,0.7449,0.7095,0.6385),
(3350,'XAG','USD',26.235,26.48,'2024-05-02','2024-05-02 16:30:00',-0.245,-0.9339,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.8435,0.7732,0.738,0.7029,0.6326),
(3351,'XAG','USD',26.5,26.235,'2024-05-03','2024-05-03 16:30:00',0.265,1,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.852,0.781,0.7455,0.71,0.639),
(3352,'XAG','USD',26.5,26.5,'2024-05-06','2024-05-06 16:30:00',0,0,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.852,0.781,0.7455,0.71,0.639),
(3353,'XAG','USD',27.26,26.5,'2024-05-07','2024-05-07 16:30:00',0.76,2.788,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.8764,0.8034,0.7669,0.7304,0.6573),
(3354,'XAG','USD',27.235,27.26,'2024-05-08','2024-05-08 16:30:00',-0.025,-0.0918,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.8756,0.8027,0.7662,0.7297,0.6567),
(3355,'XAG','USD',27.625,27.235,'2024-05-09','2024-05-09 16:30:00',0.39,1.4118,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.8882,0.8142,0.7771,0.7401,0.6661),
(3356,'XAG','USD',28.64,27.625,'2024-05-10','2024-05-10 16:30:00',1.015,3.544,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9208,0.8441,0.8057,0.7673,0.6906),
(3357,'XAG','USD',28.125,28.64,'2024-05-13','2024-05-13 16:30:00',-0.515,-1.8311,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9042,0.8289,0.7912,0.7535,0.6782),
(3358,'XAG','USD',28.43,28.125,'2024-05-14','2024-05-14 16:30:00',0.305,1.0728,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.914,0.8379,0.7998,0.7617,0.6855),
(3359,'XAG','USD',28.815,28.43,'2024-05-15','2024-05-15 16:30:00',0.385,1.3361,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9264,0.8492,0.8106,0.772,0.6948),
(3360,'XAG','USD',29.67,28.815,'2024-05-16','2024-05-16 16:30:00',0.855,2.8817,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9539,0.8744,0.8347,0.7949,0.7154),
(3361,'XAG','USD',29.68,29.67,'2024-05-17','2024-05-17 16:30:00',0.01,0.0337,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9542,0.8747,0.835,0.7952,0.7157),
(3362,'XAG','USD',31.795,29.68,'2024-05-20','2024-05-20 16:30:00',2.115,6.652,'2024-09-23 02:15:29','2024-09-23 02:15:29',1.0222,0.937,0.8945,0.8519,0.7667),
(3363,'XAG','USD',31.635,31.795,'2024-05-21','2024-05-21 16:30:00',-0.16,-0.5058,'2024-09-23 02:15:29','2024-09-23 02:15:29',1.0171,0.9323,0.89,0.8476,0.7628),
(3364,'XAG','USD',31.815,31.635,'2024-05-22','2024-05-22 16:30:00',0.18,0.5658,'2024-09-23 02:15:29','2024-09-23 02:15:29',1.0229,0.9376,0.895,0.8524,0.7672),
(3365,'XAG','USD',30.54,31.815,'2024-05-23','2024-05-23 16:30:00',-1.275,-4.1749,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9819,0.9001,0.8591,0.8182,0.7364),
(3366,'XAG','USD',30.59,30.54,'2024-05-24','2024-05-24 16:30:00',0.05,0.1635,'2024-09-23 02:15:29','2024-09-23 02:15:29',0.9835,0.9015,0.8606,0.8196,0.7376),
(3367,'XAG','USD',31.555,30.59,'2024-05-28','2024-05-28 16:30:00',0.965,3.0582,'2024-09-23 02:15:29','2024-09-23 02:15:29',1.0145,0.93,0.8877,0.8454,0.7609),
(3368,'XAG','USD',32.01,31.555,'2024-05-29','2024-05-29 16:30:00',0.455,1.4214,'2024-09-23 02:15:29','2024-09-23 02:15:29',1.0291,0.9434,0.9005,0.8576,0.7719),
(3369,'XAG','USD',27.735,28.24,'2024-04-22','2024-04-22 16:30:00',-0.505,-1.8208,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8917,0.8174,0.7802,0.7431,0.6688),
(3370,'XAG','USD',26.915,27.735,'2024-04-23','2024-04-23 16:30:00',-0.82,-3.0466,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8653,0.7932,0.7572,0.7211,0.649),
(3371,'XAG','USD',27.12,26.915,'2024-04-24','2024-04-24 16:30:00',0.205,0.7559,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8719,0.7993,0.7629,0.7266,0.6539),
(3372,'XAG','USD',27.365,27.12,'2024-04-25','2024-04-25 16:30:00',0.245,0.8953,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8798,0.8065,0.7698,0.7332,0.6599),
(3373,'XAG','USD',27.365,27.365,'2024-04-26','2024-04-26 16:30:00',0,0,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8798,0.8065,0.7698,0.7332,0.6599),
(3374,'XAG','USD',27.38,27.365,'2024-04-29','2024-04-29 16:30:00',0.015,0.0548,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.8803,0.8069,0.7703,0.7336,0.6602),
(3375,'XAG','USD',26.655,27.38,'2024-04-30','2024-04-30 16:30:00',-0.725,-2.7199,'2024-09-23 02:16:59','2024-09-23 02:16:59',0.857,0.7856,0.7499,0.7141,0.6427),
(3376,'XAU','USD',2361.45,2381.8,'2024-04-22','2024-04-22 16:30:00',-20.35,-0.8618,'2024-09-23 02:17:36','2024-09-23 02:17:36',75.9224,69.5955,66.4321,63.2687,56.9418),
(3377,'XAU','USD',2298.15,2361.45,'2024-04-23','2024-04-23 16:30:00',-63.3,-2.7544,'2024-09-23 02:17:36','2024-09-23 02:17:36',73.8872,67.73,64.6513,61.5727,55.4154),
(3378,'XAU','USD',2312.3,2298.15,'2024-04-24','2024-04-24 16:30:00',14.15,0.6119,'2024-09-23 02:17:36','2024-09-23 02:17:36',74.3422,68.147,65.0494,61.9518,55.7566),
(3379,'XAU','USD',2325.65,2312.3,'2024-04-25','2024-04-25 16:30:00',13.35,0.574,'2024-09-23 02:17:36','2024-09-23 02:17:36',74.7714,68.5404,65.425,62.3095,56.0785),
(3380,'XAU','USD',2325.65,2325.65,'2024-04-26','2024-04-26 16:30:00',0,0,'2024-09-23 02:17:36','2024-09-23 02:17:36',74.7714,68.5404,65.425,62.3095,56.0785),
(3381,'XAU','USD',2337.6,2325.65,'2024-04-29','2024-04-29 16:30:00',11.95,0.5112,'2024-09-23 02:17:36','2024-09-23 02:17:36',75.1556,68.8926,65.7611,62.6297,56.3667),
(3382,'XAU','USD',2314.8,2337.6,'2024-04-30','2024-04-30 16:30:00',-22.8,-0.985,'2024-09-23 02:17:36','2024-09-23 02:17:36',74.4225,68.2207,65.1197,62.0188,55.8169),
(3383,'XAU','USD',2207,2207,'2024-04-01','2024-04-01 16:30:00',0,0,'2024-09-23 02:19:08','2024-09-23 02:19:08',70.9567,65.0436,62.0871,59.1306,53.2175),
(3384,'XAU','USD',2264.55,2207,'2024-04-02','2024-04-02 16:30:00',57.55,2.5413,'2024-09-23 02:19:08','2024-09-23 02:19:08',72.807,66.7397,63.7061,60.6725,54.6052),
(3385,'XAU','USD',2270.75,2264.55,'2024-04-03','2024-04-03 16:30:00',6.2,0.273,'2024-09-23 02:19:08','2024-09-23 02:19:08',73.0063,66.9224,63.8805,60.8386,54.7547),
(3386,'XAU','USD',2292.5,2270.75,'2024-04-04','2024-04-04 16:30:00',21.75,0.9487,'2024-09-23 02:19:08','2024-09-23 02:19:08',73.7056,67.5635,64.4924,61.4213,55.2792),
(3387,'XAU','USD',2288.45,2292.5,'2024-04-05','2024-04-05 16:30:00',-4.05,-0.177,'2024-09-23 02:19:08','2024-09-23 02:19:08',73.5754,67.4441,64.3785,61.3128,55.1815),
(3388,'XAU','USD',2336.9,2288.45,'2024-04-08','2024-04-08 16:30:00',48.45,2.0733,'2024-09-23 02:19:08','2024-09-23 02:19:08',75.1331,68.872,65.7414,62.6109,56.3498),
(3389,'XAU','USD',2364.2,2336.9,'2024-04-09','2024-04-09 16:30:00',27.3,1.1547,'2024-09-23 02:19:08','2024-09-23 02:19:08',76.0108,69.6766,66.5094,63.3423,57.0081),
(3390,'XAU','USD',2346.85,2364.2,'2024-04-10','2024-04-10 16:30:00',-17.35,-0.7393,'2024-09-23 02:19:08','2024-09-23 02:19:08',75.453,69.1652,66.0214,62.8775,56.5897),
(3391,'XAU','USD',2331.75,2346.85,'2024-04-11','2024-04-11 16:30:00',-15.1,-0.6476,'2024-09-23 02:19:08','2024-09-23 02:19:08',74.9675,68.7202,65.5966,62.4729,56.2256),
(3392,'XAG','USD',24.54,24.54,'2024-04-01','2024-04-01 16:30:00',0,0,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.789,0.7232,0.6904,0.6575,0.5917),
(3393,'XAG','USD',25.65,24.54,'2024-04-02','2024-04-02 16:30:00',1.11,4.3275,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.8247,0.7559,0.7216,0.6872,0.6185),
(3394,'XAG','USD',26.245,25.65,'2024-04-03','2024-04-03 16:30:00',0.595,2.2671,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.8438,0.7735,0.7383,0.7032,0.6328),
(3395,'XAG','USD',27,26.245,'2024-04-04','2024-04-04 16:30:00',0.755,2.7963,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.8681,0.7957,0.7596,0.7234,0.6511),
(3396,'XAG','USD',26.78,27,'2024-04-05','2024-04-05 16:30:00',-0.22,-0.8215,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.861,0.7892,0.7534,0.7175,0.6457),
(3397,'XAG','USD',27.825,26.78,'2024-04-08','2024-04-08 16:30:00',1.045,3.7556,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.8946,0.82,0.7828,0.7455,0.6709),
(3398,'XAG','USD',27.965,27.825,'2024-04-09','2024-04-09 16:30:00',0.14,0.5006,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.8991,0.8242,0.7867,0.7492,0.6743),
(3399,'XAG','USD',28.075,27.965,'2024-04-10','2024-04-10 16:30:00',0.11,0.3918,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.9026,0.8274,0.7898,0.7522,0.677),
(3400,'XAG','USD',28.015,28.075,'2024-04-11','2024-04-11 16:30:00',-0.06,-0.2142,'2024-09-23 02:19:41','2024-09-23 02:19:41',0.9007,0.8256,0.7881,0.7506,0.6755),
(3401,'XAU','USD',2617.25,2606.45,'2024-09-23','2024-09-23 16:30:00',10.8,0.4126,'2024-10-07 12:34:56','2024-10-07 12:34:56',84.1465,77.1343,73.6282,70.1221,63.1099),
(3402,'XAU','USD',2628.55,2617.25,'2024-09-24','2024-09-24 16:30:00',11.3,0.4299,'2024-10-07 12:34:56','2024-10-07 12:34:56',84.5098,77.4674,73.9461,70.4249,63.3824),
(3403,'XAU','USD',2653.8,2628.55,'2024-09-25','2024-09-25 16:30:00',25.25,0.9515,'2024-10-07 12:34:56','2024-10-07 12:34:56',85.3217,78.2115,74.6564,71.1014,63.9912),
(3404,'XAU','USD',2668.9,2653.8,'2024-09-26','2024-09-26 16:30:00',15.1,0.5658,'2024-10-07 12:34:56','2024-10-07 12:34:56',85.8071,78.6565,75.0812,71.5059,64.3553),
(3405,'XAU','USD',2660.55,2668.9,'2024-09-27','2024-09-27 16:30:00',-8.35,-0.3138,'2024-10-07 12:34:57','2024-10-07 12:34:57',85.5387,78.4104,74.8463,71.2822,64.154),
(3406,'XAU','USD',2650.15,2660.55,'2024-09-30','2024-09-30 16:30:00',-10.4,-0.3924,'2024-10-07 12:34:57','2024-10-07 12:34:57',85.2043,78.1039,74.5538,71.0036,63.9032),
(3407,'XAU','USD',2648.85,2650.15,'2024-10-01','2024-10-01 16:30:00',-1.3,-0.0491,'2024-10-07 12:34:57','2024-10-07 12:34:57',85.1625,78.0656,74.5172,70.9688,63.8719),
(3408,'XAU','USD',2655.1,2648.85,'2024-10-02','2024-10-02 16:30:00',6.25,0.2354,'2024-10-07 12:34:57','2024-10-07 12:34:57',85.3634,78.2498,74.693,71.1362,64.0226),
(3409,'XAU','USD',2644,2655.1,'2024-10-03','2024-10-03 16:30:00',-11.1,-0.4198,'2024-10-07 12:34:58','2024-10-07 12:34:58',85.0066,77.9227,74.3808,70.8388,63.7549),
(3410,'XAU','USD',2657.5,2644,'2024-10-04','2024-10-04 16:30:00',13.5,0.508,'2024-10-07 12:34:58','2024-10-07 12:34:58',85.4406,78.3206,74.7605,71.2005,64.0805),
(3421,'XAU','USD',2651.6,2657.5,'2024-10-07','2024-10-07 16:30:00',-5.9,-0.2225,'2024-10-15 08:07:26','2024-10-15 08:07:26',85.2509,78.1467,74.5946,71.0424,63.9382),
(3422,'XAU','USD',2639.55,2651.6,'2024-10-08','2024-10-08 16:30:00',-12.05,-0.4565,'2024-10-15 08:07:26','2024-10-15 08:07:26',84.8635,77.7915,74.2556,70.7196,63.6476),
(3423,'XAU','USD',2617.55,2639.55,'2024-10-09','2024-10-09 16:30:00',-22,-0.8405,'2024-10-15 08:07:26','2024-10-15 08:07:26',84.1562,77.1432,73.6367,70.1302,63.1171),
(3424,'XAU','USD',2617.25,2617.55,'2024-10-10','2024-10-10 16:30:00',-0.3,-0.0115,'2024-10-15 08:07:26','2024-10-15 08:07:26',84.1465,77.1343,73.6282,70.1221,63.1099),
(3425,'XAU','USD',2637.05,2617.25,'2024-10-11','2024-10-11 16:30:00',19.8,0.7508,'2024-10-15 08:07:26','2024-10-15 08:07:26',84.7831,77.7179,74.1852,70.6526,63.5873),
(3426,'XAG','USD',31.88,32.06,'2024-10-07','2024-10-07 16:30:00',-0.18,-0.5646,'2024-10-15 08:07:44','2024-10-15 08:07:44',1.025,0.9396,0.8968,0.8541,0.7687),
(3427,'XAG','USD',31.28,31.88,'2024-10-08','2024-10-08 16:30:00',-0.6,-1.9182,'2024-10-15 08:07:44','2024-10-15 08:07:44',1.0057,0.9219,0.88,0.8381,0.7543),
(3428,'XAG','USD',30.685,31.28,'2024-10-09','2024-10-09 16:30:00',-0.595,-1.9391,'2024-10-15 08:07:44','2024-10-15 08:07:44',0.9865,0.9043,0.8632,0.8221,0.7399),
(3429,'XAG','USD',30.67,30.685,'2024-10-10','2024-10-10 16:30:00',-0.015,-0.0489,'2024-10-15 08:07:44','2024-10-15 08:07:44',0.9861,0.9039,0.8628,0.8217,0.7395),
(3430,'XAG','USD',31.195,30.67,'2024-10-11','2024-10-11 16:30:00',0.525,1.683,'2024-10-15 08:07:44','2024-10-15 08:07:44',1.0029,0.9194,0.8776,0.8358,0.7522),
(3431,'XAG','USD',31.16,31.25,'2024-10-15','2024-10-15 16:30:00',-0.09,-0.2888,'2024-10-21 00:30:59','2024-10-21 00:30:59',1.0018,0.9183,0.8766,0.8348,0.7514),
(3432,'XAG','USD',31.795,31.16,'2024-10-16','2024-10-16 16:30:00',0.635,1.9972,'2024-10-21 00:30:59','2024-10-21 00:30:59',1.0222,0.937,0.8945,0.8519,0.7667),
(3433,'XAG','USD',31.81,31.795,'2024-10-17','2024-10-17 16:30:00',0.015,0.0472,'2024-10-21 00:30:59','2024-10-21 00:30:59',1.0227,0.9375,0.8949,0.8523,0.767),
(3434,'XAG','USD',32.125,31.81,'2024-10-18','2024-10-18 16:30:00',0.315,0.9805,'2024-10-21 00:30:59','2024-10-21 00:30:59',1.0328,0.9468,0.9037,0.8607,0.7746),
(3435,'XAU','USD',2653.25,2659,'2024-10-15','2024-10-15 16:30:00',-5.75,-0.2167,'2024-10-21 00:31:13','2024-10-21 00:31:13',85.304,78.1953,74.641,71.0866,63.978),
(3436,'XAU','USD',2679.4,2653.25,'2024-10-16','2024-10-16 16:30:00',26.15,0.976,'2024-10-21 00:31:13','2024-10-21 00:31:13',86.1447,78.966,75.3766,71.7873,64.6085),
(3437,'XAU','USD',2678.45,2679.4,'2024-10-17','2024-10-17 16:30:00',-0.95,-0.0355,'2024-10-21 00:31:13','2024-10-21 00:31:13',86.1142,78.938,75.3499,71.7618,64.5856),
(3438,'XAU','USD',2711.6,2678.45,'2024-10-18','2024-10-18 16:30:00',33.15,1.2225,'2024-10-21 00:31:13','2024-10-21 00:31:13',87.18,79.915,76.2825,72.65,65.385),
(3439,'XAU','USD',2730.4,2719.25,'2024-10-28','2024-10-28 17:30:00',11.15,0.4084,'2024-11-05 22:05:50','2024-11-05 22:05:50',87.7844,80.469,76.8113,73.1537,65.8383),
(3440,'XAU','USD',2749.15,2730.4,'2024-10-29','2024-10-29 17:30:00',18.75,0.682,'2024-11-05 22:05:50','2024-11-05 22:05:50',88.3872,81.0216,77.3388,73.656,66.2904),
(3441,'XAU','USD',2783.95,2749.15,'2024-10-30','2024-10-30 17:30:00',34.8,1.25,'2024-11-05 22:05:50','2024-11-05 22:05:50',89.5061,82.0472,78.3178,74.5884,67.1296),
(3442,'XAU','USD',2779.4,2783.95,'2024-10-31','2024-10-31 17:30:00',-4.55,-0.1637,'2024-11-05 22:05:50','2024-11-05 22:05:50',89.3598,81.9131,78.1898,74.4665,67.0198),
(3443,'XAU','USD',2747.35,2779.4,'2024-11-01','2024-11-01 17:30:00',-32.05,-1.1666,'2024-11-05 22:05:50','2024-11-05 22:05:50',88.3294,80.9686,77.2882,73.6078,66.247),
(3444,'XAG','USD',33.385,33.15,'2024-10-28','2024-10-28 17:30:00',0.235,0.7039,'2024-11-05 22:06:12','2024-11-05 22:06:12',1.0734,0.9839,0.9392,0.8945,0.805),
(3445,'XAG','USD',34.145,33.385,'2024-10-29','2024-10-29 17:30:00',0.76,2.2258,'2024-11-05 22:06:12','2024-11-05 22:06:12',1.0978,1.0063,0.9606,0.9148,0.8233),
(3446,'XAG','USD',34.03,34.145,'2024-10-30','2024-10-30 17:30:00',-0.115,-0.3379,'2024-11-05 22:06:12','2024-11-05 22:06:12',1.0941,1.0029,0.9573,0.9117,0.8206),
(3447,'XAG','USD',33.59,34.03,'2024-10-31','2024-10-31 17:30:00',-0.44,-1.3099,'2024-11-05 22:06:12','2024-11-05 22:06:12',1.0799,0.9899,0.945,0.9,0.81),
(3448,'XAG','USD',32.8,33.59,'2024-11-01','2024-11-01 17:30:00',-0.79,-2.4085,'2024-11-05 22:06:12','2024-11-05 22:06:12',1.0545,0.9667,0.9227,0.8788,0.7909),
(3449,'XAG','USD',32.84,32.8,'2024-11-04','2024-11-04 17:30:00',0.04,0.1218,'2024-11-12 23:22:12','2024-11-12 23:22:12',1.0558,0.9678,0.9239,0.8799,0.7919),
(3450,'XAG','USD',32.65,32.84,'2024-11-05','2024-11-05 17:30:00',-0.19,-0.5819,'2024-11-12 23:22:12','2024-11-12 23:22:12',1.0497,0.9622,0.9185,0.8748,0.7873),
(3451,'XAG','USD',31.8,32.65,'2024-11-06','2024-11-06 17:30:00',-0.85,-2.673,'2024-11-12 23:22:12','2024-11-12 23:22:12',1.0224,0.9372,0.8946,0.852,0.7668),
(3452,'XAG','USD',31.105,31.8,'2024-11-07','2024-11-07 17:30:00',-0.695,-2.2344,'2024-11-12 23:22:12','2024-11-12 23:22:12',1,0.9167,0.875,0.8334,0.75),
(3453,'XAG','USD',31.55,31.105,'2024-11-08','2024-11-08 17:30:00',0.445,1.4105,'2024-11-12 23:22:12','2024-11-12 23:22:12',1.0144,0.9298,0.8876,0.8453,0.7608),
(3454,'XAU','USD',2741.35,2747.35,'2024-11-04','2024-11-04 17:30:00',-6,-0.2189,'2024-11-12 23:22:29','2024-11-12 23:22:29',88.1364,80.7917,77.1194,73.447,66.1023),
(3455,'XAU','USD',2738.75,2741.35,'2024-11-05','2024-11-05 17:30:00',-2.6,-0.0949,'2024-11-12 23:22:29','2024-11-12 23:22:29',88.0529,80.7151,77.0463,73.3774,66.0396),
(3456,'XAU','USD',2726.2,2738.75,'2024-11-06','2024-11-06 17:30:00',-12.55,-0.4603,'2024-11-12 23:22:29','2024-11-12 23:22:29',87.6494,80.3453,76.6932,73.0411,65.737),
(3457,'XAU','USD',2667.05,2726.2,'2024-11-07','2024-11-07 17:30:00',-59.15,-2.2178,'2024-11-12 23:22:29','2024-11-12 23:22:29',85.7476,78.602,75.0292,71.4564,64.3107),
(3458,'XAU','USD',2685.2,2667.05,'2024-11-08','2024-11-08 17:30:00',18.15,0.6759,'2024-11-12 23:22:29','2024-11-12 23:22:29',86.3312,79.1369,75.5398,71.9427,64.7484),
(3459,'XAU','USD',2734.3,2711.6,'2024-10-21','2024-10-21 16:30:00',22.7,0.8302,'2024-11-14 07:10:28','2024-11-14 07:10:28',87.9098,80.584,76.9211,73.2582,65.9323),
(3460,'XAU','USD',2733.55,2734.3,'2024-10-22','2024-10-22 16:30:00',-0.75,-0.0274,'2024-11-14 07:10:28','2024-11-14 07:10:28',87.8857,80.5619,76.9,73.2381,65.9143),
(3461,'XAU','USD',2751,2733.55,'2024-10-23','2024-10-23 16:30:00',17.45,0.6343,'2024-11-14 07:10:28','2024-11-14 07:10:28',88.4467,81.0761,77.3909,73.7056,66.335),
(3462,'XAU','USD',2740,2751,'2024-10-24','2024-10-24 16:30:00',-11,-0.4015,'2024-11-14 07:10:28','2024-11-14 07:10:28',88.093,80.752,77.0814,73.4109,66.0698),
(3463,'XAU','USD',2719.25,2740,'2024-10-25','2024-10-25 16:30:00',-20.75,-0.7631,'2024-11-14 07:10:28','2024-11-14 07:10:28',87.4259,80.1404,76.4977,72.8549,65.5694),
(3464,'XAG','USD',34,32.125,'2024-10-21','2024-10-21 16:30:00',1.875,5.5147,'2024-11-14 07:10:46','2024-11-14 07:10:46',1.0931,1.002,0.9565,0.9109,0.8198),
(3465,'XAG','USD',34.425,34,'2024-10-22','2024-10-22 16:30:00',0.425,1.2346,'2024-11-14 07:10:46','2024-11-14 07:10:46',1.1068,1.0146,0.9684,0.9223,0.8301),
(3466,'XAG','USD',34.51,34.425,'2024-10-23','2024-10-23 16:30:00',0.085,0.2463,'2024-11-14 07:10:46','2024-11-14 07:10:46',1.1095,1.0171,0.9708,0.9246,0.8321),
(3467,'XAG','USD',34.135,34.51,'2024-10-24','2024-10-24 16:30:00',-0.375,-1.0986,'2024-11-14 07:10:46','2024-11-14 07:10:46',1.0975,1.006,0.9603,0.9146,0.8231),
(3468,'XAG','USD',33.15,34.135,'2024-10-25','2024-10-25 16:30:00',-0.985,-2.9713,'2024-11-14 07:10:46','2024-11-14 07:10:46',1.0658,0.977,0.9326,0.8882,0.7993),
(3469,'XAU','USD',2590.75,2670.55,'2024-11-12','2024-11-12 17:30:00',-79.8,-3.0802,'2024-11-20 23:04:44','2024-11-20 23:04:44',83.2945,76.3533,72.8827,69.4121,62.4709),
(3470,'XAU','USD',2609.75,2590.75,'2024-11-13','2024-11-13 17:30:00',19,0.728,'2024-11-20 23:04:44','2024-11-20 23:04:44',83.9054,76.9133,73.4172,69.9212,62.9291),
(3471,'XAU','USD',2548.45,2609.75,'2024-11-14','2024-11-14 17:30:00',-61.3,-2.4054,'2024-11-20 23:04:44','2024-11-20 23:04:44',81.9346,75.1067,71.6927,68.2788,61.4509),
(3472,'XAU','USD',2566.7,2548.45,'2024-11-15','2024-11-15 17:30:00',18.25,0.711,'2024-11-20 23:04:44','2024-11-20 23:04:44',82.5213,75.6445,72.2062,68.7678,61.891),
(3473,'XAU','USD',2590.1,2566.7,'2024-11-18','2024-11-18 17:30:00',23.4,0.9034,'2024-11-20 23:04:44','2024-11-20 23:04:44',83.2736,76.3342,72.8644,69.3947,62.4552),
(3474,'XAU','USD',2635.95,2590.1,'2024-11-19','2024-11-19 17:30:00',45.85,1.7394,'2024-11-20 23:04:44','2024-11-20 23:04:44',84.7478,77.6854,74.1543,70.6231,63.5608),
(3475,'XAG','USD',30.405,31.315,'2024-11-12','2024-11-12 17:30:00',-0.91,-2.9929,'2024-11-20 23:04:59','2024-11-20 23:04:59',0.9775,0.8961,0.8554,0.8146,0.7332),
(3476,'XAG','USD',30.91,30.405,'2024-11-13','2024-11-13 17:30:00',0.505,1.6338,'2024-11-20 23:04:59','2024-11-20 23:04:59',0.9938,0.911,0.8696,0.8281,0.7453),
(3477,'XAG','USD',29.99,30.91,'2024-11-14','2024-11-14 17:30:00',-0.92,-3.0677,'2024-11-20 23:04:59','2024-11-20 23:04:59',0.9642,0.8839,0.8437,0.8035,0.7232),
(3478,'XAG','USD',30.66,29.99,'2024-11-15','2024-11-15 17:30:00',0.67,2.1853,'2024-11-20 23:04:59','2024-11-20 23:04:59',0.9857,0.9036,0.8625,0.8215,0.7393),
(3479,'XAG','USD',30.74,30.66,'2024-11-18','2024-11-18 17:30:00',0.08,0.2602,'2024-11-20 23:04:59','2024-11-20 23:04:59',0.9883,0.906,0.8648,0.8236,0.7412),
(3480,'XAG','USD',31.285,30.74,'2024-11-19','2024-11-19 17:30:00',0.545,1.742,'2024-11-20 23:04:59','2024-11-20 23:04:59',1.0058,0.922,0.8801,0.8382,0.7544),
(3481,'XAG','USD',30.87,31.285,'2024-11-20','2024-11-20 17:30:00',-0.415,-1.3443,'2024-12-19 04:41:44','2024-12-19 04:41:44',0.9925,0.9098,0.8684,0.8271,0.7444),
(3482,'XAG','USD',31.065,30.87,'2024-11-21','2024-11-21 17:30:00',0.195,0.6277,'2024-12-19 04:41:44','2024-12-19 04:41:44',0.9988,0.9155,0.8739,0.8323,0.7491),
(3483,'XAG','USD',31.255,31.065,'2024-11-22','2024-11-22 17:30:00',0.19,0.6079,'2024-12-19 04:41:44','2024-12-19 04:41:44',1.0049,0.9211,0.8793,0.8374,0.7537),
(3484,'XAG','USD',30.79,31.255,'2024-11-25','2024-11-25 17:30:00',-0.465,-1.5102,'2024-12-19 04:41:44','2024-12-19 04:41:44',0.9899,0.9074,0.8662,0.8249,0.7424),
(3485,'XAG','USD',30.54,30.79,'2024-11-26','2024-11-26 17:30:00',-0.25,-0.8186,'2024-12-19 04:41:44','2024-12-19 04:41:44',0.9819,0.9001,0.8591,0.8182,0.7364),
(3486,'XAG','USD',30.49,30.54,'2024-11-27','2024-11-27 17:30:00',-0.05,-0.164,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9803,0.8986,0.8577,0.8169,0.7352),
(3487,'XAG','USD',30.7,30.065,'2024-11-29','2024-11-29 17:30:00',0.635,2.0684,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.987,0.9048,0.8636,0.8225,0.7403),
(3488,'XAG','USD',30.455,30.7,'2024-12-02','2024-12-02 17:30:00',-0.245,-0.8045,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9792,0.8976,0.8568,0.816,0.7344),
(3489,'XAG','USD',30.905,30.455,'2024-12-03','2024-12-03 17:30:00',0.45,1.4561,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9936,0.9108,0.8694,0.828,0.7452),
(3490,'XAG','USD',30.835,30.905,'2024-12-04','2024-12-04 17:30:00',-0.07,-0.227,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9914,0.9088,0.8674,0.8261,0.7435),
(3491,'XAG','USD',31.345,30.835,'2024-12-05','2024-12-05 17:30:00',0.51,1.6271,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.0078,0.9238,0.8818,0.8398,0.7558),
(3492,'XAG','USD',31.11,31.345,'2024-12-06','2024-12-06 17:30:00',-0.235,-0.7554,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.0002,0.9169,0.8752,0.8335,0.7502),
(3493,'XAG','USD',31.63,31.11,'2024-12-09','2024-12-09 17:30:00',0.52,1.644,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.0169,0.9322,0.8898,0.8474,0.7627),
(3494,'XAG','USD',31.9,31.63,'2024-12-10','2024-12-10 17:30:00',0.27,0.8464,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.0256,0.9401,0.8974,0.8547,0.7692),
(3495,'XAG','USD',31.7,31.9,'2024-12-11','2024-12-11 17:30:00',-0.2,-0.6309,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.0192,0.9342,0.8918,0.8493,0.7644),
(3496,'XAG','USD',31.88,31.7,'2024-12-12','2024-12-12 17:30:00',0.18,0.5646,'2024-12-19 04:41:45','2024-12-19 04:41:45',1.025,0.9396,0.8968,0.8541,0.7687),
(3497,'XAG','USD',30.735,31.88,'2024-12-13','2024-12-13 17:30:00',-1.145,-3.7254,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9882,0.9058,0.8646,0.8235,0.7411),
(3498,'XAG','USD',30.655,30.735,'2024-12-16','2024-12-16 17:30:00',-0.08,-0.261,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9856,0.9034,0.8624,0.8213,0.7392),
(3499,'XAG','USD',30.31,30.655,'2024-12-17','2024-12-17 17:30:00',-0.345,-1.1382,'2024-12-19 04:41:45','2024-12-19 04:41:45',0.9745,0.8933,0.8527,0.8121,0.7309),
(3500,'XAU','USD',2624.3,2635.95,'2024-11-20','2024-11-20 17:30:00',-11.65,-0.4439,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.3732,77.3421,73.8266,70.311,63.2799),
(3501,'XAU','USD',2669.7,2624.3,'2024-11-21','2024-11-21 17:30:00',45.4,1.7006,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.8328,78.6801,75.1037,71.5274,64.3746),
(3502,'XAU','USD',2706.25,2669.7,'2024-11-22','2024-11-22 17:30:00',36.55,1.3506,'2024-12-19 04:42:14','2024-12-19 04:42:14',87.008,79.7573,76.132,72.5066,65.256),
(3503,'XAU','USD',2670.4,2706.25,'2024-11-25','2024-11-25 17:30:00',-35.85,-1.3425,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.8554,78.7007,75.1234,71.5461,64.3915),
(3504,'XAU','USD',2630.3,2670.4,'2024-11-26','2024-11-26 17:30:00',-40.1,-1.5245,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.5661,77.5189,73.9953,70.4718,63.4246),
(3505,'XAU','USD',2648,2630.3,'2024-11-27','2024-11-27 17:30:00',17.7,0.6684,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.1352,78.0406,74.4933,70.946,63.8514),
(3506,'XAU','USD',2664.3,2646.4,'2024-11-29','2024-11-29 17:30:00',17.9,0.6718,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.6592,78.521,74.9518,71.3827,64.2444),
(3507,'XAU','USD',2637.25,2664.3,'2024-12-02','2024-12-02 17:30:00',-27.05,-1.0257,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.7896,77.7238,74.1909,70.658,63.5922),
(3508,'XAU','USD',2645.35,2637.25,'2024-12-03','2024-12-03 17:30:00',8.1,0.3062,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.05,77.9625,74.4187,70.875,63.7875),
(3509,'XAU','USD',2642.05,2645.35,'2024-12-04','2024-12-04 17:30:00',-3.3,-0.1249,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.9439,77.8652,74.3259,70.7866,63.7079),
(3510,'XAU','USD',2649.15,2642.05,'2024-12-05','2024-12-05 17:30:00',7.1,0.268,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.1722,78.0745,74.5256,70.9768,63.8791),
(3511,'XAU','USD',2636.5,2649.15,'2024-12-06','2024-12-06 17:30:00',-12.65,-0.4798,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.7654,77.7017,74.1698,70.6379,63.5741),
(3512,'XAU','USD',2655.85,2636.5,'2024-12-09','2024-12-09 17:30:00',19.35,0.7286,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.3876,78.2719,74.7141,71.1563,64.0407),
(3513,'XAU','USD',2670.45,2655.85,'2024-12-10','2024-12-10 17:30:00',14.6,0.5467,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.857,78.7022,75.1248,71.5475,64.3927),
(3514,'XAU','USD',2697.45,2670.45,'2024-12-11','2024-12-11 17:30:00',27,1.0009,'2024-12-19 04:42:14','2024-12-19 04:42:14',86.725,79.4979,75.8844,72.2709,65.0438),
(3515,'XAU','USD',2713.6,2697.45,'2024-12-12','2024-12-12 17:30:00',16.15,0.5952,'2024-12-19 04:42:14','2024-12-19 04:42:14',87.2443,79.9739,76.3387,72.7036,65.4332),
(3516,'XAU','USD',2669.55,2713.6,'2024-12-13','2024-12-13 17:30:00',-44.05,-1.6501,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.828,78.6757,75.0995,71.5234,64.371),
(3517,'XAU','USD',2660.95,2669.55,'2024-12-16','2024-12-16 17:30:00',-8.6,-0.3232,'2024-12-19 04:42:14','2024-12-19 04:42:14',85.5515,78.4222,74.8576,71.2929,64.1636),
(3518,'XAU','USD',2641.6,2660.95,'2024-12-17','2024-12-17 17:30:00',-19.35,-0.7325,'2024-12-19 04:42:14','2024-12-19 04:42:14',84.9294,77.852,74.3132,70.7745,63.6971),
(3519,'XAG','USD',30.63,31.315,'2024-09-23','2024-09-23 16:30:00',-0.685,-2.2364,'2024-12-24 05:27:08','2024-12-24 05:27:08',0.9848,0.9027,0.8617,0.8206,0.7386),
(3520,'XAG','USD',30.875,30.63,'2024-09-24','2024-09-24 16:30:00',0.245,0.7935,'2024-12-24 05:27:08','2024-12-24 05:27:08',0.9927,0.9099,0.8686,0.8272,0.7445),
(3521,'XAG','USD',31.845,30.875,'2024-09-25','2024-09-25 16:30:00',0.97,3.046,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0238,0.9385,0.8959,0.8532,0.7679),
(3522,'XAG','USD',32.48,31.845,'2024-09-26','2024-09-26 16:30:00',0.635,1.955,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0443,0.9572,0.9137,0.8702,0.7832),
(3523,'XAG','USD',31.915,32.48,'2024-09-27','2024-09-27 16:30:00',-0.565,-1.7703,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0261,0.9406,0.8978,0.8551,0.7696),
(3524,'XAG','USD',31.075,31.915,'2024-09-30','2024-09-30 16:30:00',-0.84,-2.7031,'2024-12-24 05:27:08','2024-12-24 05:27:08',0.9991,0.9158,0.8742,0.8326,0.7493),
(3525,'XAG','USD',31.355,31.075,'2024-10-01','2024-10-01 16:30:00',0.28,0.893,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0081,0.9241,0.8821,0.8401,0.7561),
(3526,'XAG','USD',31.39,31.355,'2024-10-02','2024-10-02 16:30:00',0.035,0.1115,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0092,0.9251,0.8831,0.841,0.7569),
(3527,'XAG','USD',31.5,31.39,'2024-10-03','2024-10-03 16:30:00',0.11,0.3492,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0127,0.9284,0.8862,0.844,0.7596),
(3528,'XAG','USD',32.06,31.5,'2024-10-04','2024-10-04 16:30:00',0.56,1.7467,'2024-12-24 05:27:08','2024-12-24 05:27:08',1.0308,0.9449,0.9019,0.859,0.7731),
(3530,'XAG','USD',23.835,23.53,'2023-11-22','2023-11-22 17:30:00',0.305,1.2796,'2024-12-24 05:28:13','2024-12-24 05:28:13',0.7663,0.7025,0.6705,0.6386,0.5747),
(3531,'XAG','USD',24.225,25.01,'2023-07-28','2023-07-28 16:30:00',-0.785,-3.2405,'2024-12-24 05:28:26','2024-12-24 05:28:26',0.7789,0.7139,0.6815,0.649,0.5841),
(3532,'XAG','USD',24.815,24.755,'2022-03-31','2022-03-31 16:30:00',0.06,0.2418,'2024-12-24 05:28:56','2024-12-24 05:28:56',0.7978,0.7313,0.6981,0.6649,0.5984),
(3533,'XAU','USD',2648.35,2641.6,'2024-12-18','2024-12-18 17:30:00',6.75,0.2549,'2024-12-24 18:07:28','2024-12-24 18:07:28',85.1464,78.0509,74.5031,70.9554,63.8598),
(3534,'XAU','USD',2621.3,2648.35,'2024-12-19','2024-12-19 17:30:00',-27.05,-1.0319,'2024-12-24 18:07:28','2024-12-24 18:07:28',84.2768,77.2537,73.7422,70.2306,63.2076),
(3535,'XAU','USD',2606.15,2621.3,'2024-12-20','2024-12-20 17:30:00',-15.15,-0.5813,'2024-12-24 18:07:28','2024-12-24 18:07:28',83.7897,76.8072,73.316,69.8247,62.8423),
(3536,'XAU','USD',2620.55,2606.15,'2024-12-23','2024-12-23 17:30:00',14.4,0.5495,'2024-12-24 18:07:28','2024-12-24 18:07:28',84.2526,77.2316,73.7211,70.2105,63.1895),
(3537,'XAG','USD',30.355,30.31,'2024-12-18','2024-12-18 17:30:00',0.045,0.1482,'2024-12-24 18:07:50','2024-12-24 18:07:50',0.9759,0.8946,0.8539,0.8133,0.732),
(3538,'XAG','USD',29.49,30.355,'2024-12-19','2024-12-19 17:30:00',-0.865,-2.9332,'2024-12-24 18:07:50','2024-12-24 18:07:50',0.9481,0.8691,0.8296,0.7901,0.7111),
(3539,'XAG','USD',28.795,29.49,'2024-12-20','2024-12-20 17:30:00',-0.695,-2.4136,'2024-12-24 18:07:50','2024-12-24 18:07:50',0.9258,0.8486,0.8101,0.7715,0.6943),
(3540,'XAG','USD',29.605,28.795,'2024-12-23','2024-12-23 17:30:00',0.81,2.736,'2024-12-24 18:07:50','2024-12-24 18:07:50',0.9518,0.8725,0.8328,0.7932,0.7139),
(3541,'XAU','USD',2613.75,2620.55,'2024-12-24','2024-12-24 17:30:00',-6.8,-0.2602,'2025-01-01 22:05:05','2025-01-01 22:05:05',84.034,77.0312,73.5298,70.0283,63.0255),
(3542,'XAU','USD',2613.75,2613.75,'2024-12-26','2024-12-26 17:30:00',0,0,'2025-01-01 22:05:05','2025-01-01 22:05:05',84.034,77.0312,73.5298,70.0283,63.0255),
(3543,'XAU','USD',2625.55,2613.75,'2024-12-27','2024-12-27 17:30:00',11.8,0.4494,'2025-01-01 22:05:05','2025-01-01 22:05:05',84.4134,77.3789,73.8617,70.3445,63.31),
(3544,'XAU','USD',2610.3,2625.55,'2024-12-30','2024-12-30 17:30:00',-15.25,-0.5842,'2025-01-01 22:05:05','2025-01-01 22:05:05',83.9231,76.9295,73.4327,69.9359,62.9423),
(3545,'XAU','USD',2610.85,2610.3,'2024-12-31','2024-12-31 17:30:00',0.55,0.0211,'2025-01-01 22:05:05','2025-01-01 22:05:05',83.9408,76.9457,73.4482,69.9506,62.9556),
(3546,'XAG','USD',29.605,29.605,'2024-12-24','2024-12-24 17:30:00',0,0,'2025-01-01 22:05:22','2025-01-01 22:05:22',0.9518,0.8725,0.8328,0.7932,0.7139),
(3547,'XAG','USD',29.605,29.605,'2024-12-26','2024-12-26 17:30:00',0,0,'2025-01-01 22:05:22','2025-01-01 22:05:22',0.9518,0.8725,0.8328,0.7932,0.7139),
(3548,'XAG','USD',29.645,29.605,'2024-12-27','2024-12-27 17:30:00',0.04,0.1349,'2025-01-01 22:05:22','2025-01-01 22:05:22',0.9531,0.8737,0.834,0.7943,0.7148),
(3549,'XAG','USD',29.46,29.645,'2024-12-30','2024-12-30 17:30:00',-0.185,-0.628,'2025-01-01 22:05:22','2025-01-01 22:05:22',0.9472,0.8682,0.8288,0.7893,0.7104),
(3550,'XAG','USD',29.46,29.46,'2024-12-31','2024-12-31 17:30:00',0,0,'2025-01-01 22:05:22','2025-01-01 22:05:22',0.9472,0.8682,0.8288,0.7893,0.7104),
(3551,'XAU','USD',2644.6,2610.85,'2025-01-02','2025-01-02 17:30:00',33.75,1.2762,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.0259,77.9404,74.3976,70.8549,63.7694),
(3552,'XAU','USD',2654.3,2644.6,'2025-01-03','2025-01-03 17:30:00',9.7,0.3654,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.3377,78.2262,74.6705,71.1148,64.0033),
(3553,'XAU','USD',2631.8,2654.3,'2025-01-06','2025-01-06 17:30:00',-22.5,-0.8549,'2025-01-16 20:28:30','2025-01-16 20:28:30',84.6143,77.5631,74.0375,70.5119,63.4608),
(3554,'XAU','USD',2644.4,2631.8,'2025-01-07','2025-01-07 17:30:00',12.6,0.4765,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.0194,77.9345,74.392,70.8495,63.7646),
(3555,'XAU','USD',2653.45,2644.4,'2025-01-08','2025-01-08 17:30:00',9.05,0.3411,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.3104,78.2012,74.6466,71.092,63.9828),
(3556,'XAU','USD',2666.35,2653.45,'2025-01-09','2025-01-09 17:30:00',12.9,0.4838,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.7251,78.5814,75.0095,71.4376,64.2939),
(3557,'XAU','USD',2679.45,2666.35,'2025-01-10','2025-01-10 17:30:00',13.1,0.4889,'2025-01-16 20:28:30','2025-01-16 20:28:30',86.1463,78.9675,75.378,71.7886,64.6097),
(3558,'XAU','USD',2679.8,2679.45,'2025-01-13','2025-01-13 17:30:00',0.35,0.0131,'2025-01-16 20:28:30','2025-01-16 20:28:30',86.1576,78.9778,75.3879,71.798,64.6182),
(3559,'XAU','USD',2666.4,2679.8,'2025-01-14','2025-01-14 17:30:00',-13.4,-0.5026,'2025-01-16 20:28:30','2025-01-16 20:28:30',85.7268,78.5829,75.0109,71.439,64.2951),
(3560,'XAU','USD',2686.6,2666.4,'2025-01-15','2025-01-15 17:30:00',20.2,0.7519,'2025-01-16 20:28:30','2025-01-16 20:28:30',86.3762,79.1782,75.5792,71.9802,64.7821),
(3561,'XAG','USD',29.405,29.46,'2025-01-02','2025-01-02 17:30:00',-0.055,-0.187,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9454,0.8666,0.8272,0.7878,0.709),
(3562,'XAG','USD',29.815,29.405,'2025-01-03','2025-01-03 17:30:00',0.41,1.3751,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9586,0.8787,0.8388,0.7988,0.7189),
(3563,'XAG','USD',30.27,29.815,'2025-01-06','2025-01-06 17:30:00',0.455,1.5031,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9732,0.8921,0.8516,0.811,0.7299),
(3564,'XAG','USD',30.235,30.27,'2025-01-07','2025-01-07 17:30:00',-0.035,-0.1158,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9721,0.8911,0.8506,0.8101,0.7291),
(3565,'XAG','USD',30.14,30.235,'2025-01-08','2025-01-08 17:30:00',-0.095,-0.3152,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.969,0.8883,0.8479,0.8075,0.7268),
(3566,'XAG','USD',30.285,30.14,'2025-01-09','2025-01-09 17:30:00',0.145,0.4788,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9737,0.8925,0.852,0.8114,0.7303),
(3567,'XAG','USD',30.355,30.285,'2025-01-10','2025-01-10 17:30:00',0.07,0.2306,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9759,0.8946,0.8539,0.8133,0.732),
(3568,'XAG','USD',29.88,30.355,'2025-01-13','2025-01-13 17:30:00',-0.475,-1.5897,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9607,0.8806,0.8406,0.8006,0.7205),
(3569,'XAG','USD',29.735,29.88,'2025-01-14','2025-01-14 17:30:00',-0.145,-0.4876,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.956,0.8763,0.8365,0.7967,0.717),
(3570,'XAG','USD',29.99,29.735,'2025-01-15','2025-01-15 17:30:00',0.255,0.8503,'2025-01-16 20:28:58','2025-01-16 20:28:58',0.9642,0.8839,0.8437,0.8035,0.7232),
(3691,'XAU','USD',2707.45,2686.6,'2025-01-16','2025-01-16 17:30:00',20.85,0.7701,'2025-01-29 00:53:07','2025-01-29 00:53:07',87.0465,79.7927,76.1657,72.5388,65.2849),
(3692,'XAU','USD',2705.1,2707.45,'2025-01-17','2025-01-17 17:30:00',-2.35,-0.0869,'2025-01-29 00:53:07','2025-01-29 00:53:07',86.971,79.7234,76.0996,72.4758,65.2282),
(3693,'XAU','USD',2721.4,2707.5,'2025-01-21','2025-01-21 17:30:00',13.9,0.5108,'2025-01-29 00:53:07','2025-01-29 00:53:07',87.495,80.2038,76.5582,72.9125,65.6213),
(3694,'XAU','USD',2760.15,2721.4,'2025-01-22','2025-01-22 17:30:00',38.75,1.4039,'2025-01-29 00:53:07','2025-01-29 00:53:07',88.7409,81.3458,77.6483,73.9507,66.5557),
(3695,'XAU','USD',2747.2,2760.15,'2025-01-23','2025-01-23 17:30:00',-12.95,-0.4714,'2025-01-29 00:53:07','2025-01-29 00:53:07',88.3245,80.9642,77.284,73.6038,66.2434),
(3696,'XAU','USD',2771.05,2747.2,'2025-01-24','2025-01-24 17:30:00',23.85,0.8607,'2025-01-29 00:53:07','2025-01-29 00:53:07',89.0913,81.667,77.9549,74.2428,66.8185),
(3697,'XAU','USD',2767.1,2771.05,'2025-01-27','2025-01-27 17:30:00',-3.95,-0.1427,'2025-01-29 00:53:07','2025-01-29 00:53:07',88.9643,81.5506,77.8438,74.1369,66.7232),
(3698,'XAG','USD',30.705,29.99,'2025-01-16','2025-01-16 17:30:00',0.715,2.3286,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9872,0.9049,0.8638,0.8227,0.7404),
(3699,'XAG','USD',30.63,30.705,'2025-01-17','2025-01-17 17:30:00',-0.075,-0.2449,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9848,0.9027,0.8617,0.8206,0.7386),
(3700,'XAG','USD',30.485,30.255,'2025-01-21','2025-01-21 17:30:00',0.23,0.7545,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9801,0.8984,0.8576,0.8168,0.7351),
(3701,'XAG','USD',30.795,30.485,'2025-01-22','2025-01-22 17:30:00',0.31,1.0067,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9901,0.9076,0.8663,0.8251,0.7426),
(3702,'XAG','USD',30.475,30.795,'2025-01-23','2025-01-23 17:30:00',-0.32,-1.05,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9798,0.8981,0.8573,0.8165,0.7348),
(3703,'XAG','USD',30.84,30.475,'2025-01-24','2025-01-24 17:30:00',0.365,1.1835,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9915,0.9089,0.8676,0.8263,0.7436),
(3704,'XAG','USD',30.58,30.84,'2025-01-27','2025-01-27 17:30:00',-0.26,-0.8502,'2025-01-29 00:53:22','2025-01-29 00:53:22',0.9832,0.9012,0.8603,0.8193,0.7374),
(3705,'XAU','USD',2743.7,2767.1,'2025-01-28','2025-01-28 17:30:00',-23.4,-0.8529,'2025-02-01 14:42:48','2025-02-01 14:42:48',88.212,80.861,77.1855,73.51,66.159),
(3706,'XAU','USD',2759.4,2743.7,'2025-01-29','2025-01-29 17:30:00',15.7,0.569,'2025-02-01 14:42:48','2025-02-01 14:42:48',88.7168,81.3237,77.6272,73.9306,66.5376),
(3707,'XAU','USD',2778.15,2759.4,'2025-01-30','2025-01-30 17:30:00',18.75,0.6749,'2025-02-01 14:42:48','2025-02-01 14:42:48',89.3196,81.8763,78.1546,74.433,66.9897),
(3708,'XAU','USD',2791.5,2778.15,'2025-01-31','2025-01-31 17:30:00',13.35,0.4782,'2025-02-01 14:42:48','2025-02-01 14:42:48',89.7488,82.2697,78.5302,74.7907,67.3116),
(3709,'XAG','USD',30.15,30.58,'2025-01-28','2025-01-28 17:30:00',-0.43,-1.4262,'2025-02-01 14:43:10','2025-02-01 14:43:10',0.9693,0.8886,0.8482,0.8078,0.727),
(3710,'XAG','USD',30.44,30.15,'2025-01-29','2025-01-29 17:30:00',0.29,0.9527,'2025-02-01 14:43:10','2025-02-01 14:43:10',0.9787,0.8971,0.8563,0.8156,0.734),
(3711,'XAG','USD',30.995,30.44,'2025-01-30','2025-01-30 17:30:00',0.555,1.7906,'2025-02-01 14:43:10','2025-02-01 14:43:10',0.9965,0.9135,0.8719,0.8304,0.7474),
(3712,'XAG','USD',31.605,30.995,'2025-01-31','2025-01-31 17:30:00',0.61,1.9301,'2025-02-01 14:43:10','2025-02-01 14:43:10',1.0161,0.9314,0.8891,0.8468,0.7621);
/*!40000 ALTER TABLE `metalprices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-06-17 20:17:23
